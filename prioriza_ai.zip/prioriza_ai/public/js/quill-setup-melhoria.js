/**
 * Configuração dos editores Quill para o modal de edição de melhoria
 * Este arquivo inicializa os editores rich text para os campos:
 * - Escopo da Demanda
 * - MVP
 * - Pessoas Envolvidas
 */

let quillEscopo, quillMvp, quillPessoasEnvolvidas;

// Configuração da toolbar do Quill
const toolbarOptions = [
    ['bold', 'italic', 'underline'],
    [{ 'list': 'ordered'}, { 'list': 'bullet' }],
    ['link'],

    [{ 'color': [] }, { 'background': [] }], // cores

    ['clean']  // limpar formatações   
];

// Inicializar editores quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    // Esperar o Quill estar disponível
    if (typeof Quill === 'undefined') {
        console.error('Quill não está carregado. Verifique se o CDN está correto.');
        return;
    }

    // Inicializar editores apenas se os elementos existirem
    const escopoEditor = document.getElementById('escopo-melhoria-editor');
    const mvpEditor = document.getElementById('mvp-melhoria-editor');
    const pessoasEditor = document.getElementById('pessoas-envolvidas-melhoria-editor');

    if (escopoEditor) {
        quillEscopo = new Quill('#escopo-melhoria-editor', {
            theme: 'snow',
            modules: { toolbar: toolbarOptions },
            placeholder: 'Descreva o escopo da demanda...'
        });

        // Atualizar campo hidden quando o conteúdo mudar
        quillEscopo.on('text-change', function() {
            const html = quillEscopo.root.innerHTML;
            document.getElementById('escopo-melhoria').value = html === '<p><br></p>' ? '' : html;
        });
    }

    if (mvpEditor) {
        quillMvp = new Quill('#mvp-melhoria-editor', {
            theme: 'snow',
            modules: { toolbar: toolbarOptions },
            placeholder: 'Descreva o MVP...'
        });

        quillMvp.on('text-change', function() {
            const html = quillMvp.root.innerHTML;
            document.getElementById('mvp-melhoria').value = html === '<p><br></p>' ? '' : html;
        });
    }

    if (pessoasEditor) {
        quillPessoasEnvolvidas = new Quill('#pessoas-envolvidas-melhoria-editor', {
            theme: 'snow',
            modules: { toolbar: toolbarOptions },
            placeholder: 'Liste as pessoas envolvidas...'
        });

        quillPessoasEnvolvidas.on('text-change', function() {
            const html = quillPessoasEnvolvidas.root.innerHTML;
            document.getElementById('pessoas-envolvidas-melhoria').value = html === '<p><br></p>' ? '' : html;
        });
    }
});

// Funções auxiliares para setar/limpar conteúdo dos editores
window.setQuillContent = function(editor, content) {
    if (!editor) return;
    if (content && content !== '<p><br></p>') {
        editor.root.innerHTML = content;
    } else {
        editor.setText('');
    }
};

window.clearQuillEditors = function() {
    if (quillEscopo) quillEscopo.setText('');
    if (quillMvp) quillMvp.setText('');
    if (quillPessoasEnvolvidas) quillPessoasEnvolvidas.setText('');
};

window.getQuillEditors = function() {
    return {
        escopo: quillEscopo,
        mvp: quillMvp,
        pessoasEnvolvidas: quillPessoasEnvolvidas
    };
};
