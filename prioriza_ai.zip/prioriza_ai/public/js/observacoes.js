/**
 * @file public/js/observacoes.js
 * @description Script para gerenciar o modal de observações das demandas
 */

let currentDemandaId = null;
let modalObservacoesInstance = null;

/**
 * Inicializa as instâncias dos modais
 */
function initializeModals() {
    const modalObservacoes = document.getElementById('modal-observacoes');
    
    if (window.Modal && modalObservacoes) {
        modalObservacoesInstance = new Modal(modalObservacoes);
    }
}

/**
 * Função para mostrar mensagens no modal de observações
 */
function showMessageObservacoes(message, type, containerId = 'message-container-observacoes') {
    const messageContainer = document.getElementById(containerId);
    if (!messageContainer) return;
    
    const bgColor = type === 'success' ? 'bg-green-100 text-green-700 border-green-300' : 
                   type === 'warning' ? 'bg-yellow-100 text-yellow-700 border-yellow-300' :
                   'bg-red-100 text-red-700 border-red-300';
    const icon = type === 'success' ? 'fas fa-check-circle' : 
                type === 'warning' ? 'fas fa-exclamation-triangle' :
                'fas fa-exclamation-circle';

    messageContainer.innerHTML = `
        <div class="p-3 border rounded-lg ${bgColor}">
            <i class="${icon} mr-2"></i>
            ${message}
        </div>
    `;
    messageContainer.classList.remove('hidden');
}

/**
 * Função para esconder mensagens do modal de observações
 */
function hideMessageObservacoes(containerId = 'message-container-observacoes') {
    const messageContainer = document.getElementById(containerId);
    if (!messageContainer) return;
    messageContainer.classList.add('hidden');
    messageContainer.innerHTML = '';
}

/**
 * Abre o modal de observações para uma demanda específica
 * @param {string} idDemanda - ID da demanda
 */
async function abrirObservacoes(idDemanda) {
    currentDemandaId = idDemanda;
    
    try {
        // Limpar mensagens anteriores
        hideMessageObservacoes();
        hideMessageObservacoes('message-container-nova-observacao');
        
        // Buscar observações da demanda
        const response = await fetch(`/demanda/observacoes/${idDemanda}`);
        const data = await response.json();
        
        if (data.success) {
            // Atualizar o ID da demanda no formulário
            document.getElementById('input-id-demanda').value = idDemanda;
            
            // Carregar as observações na lista
            carregarObservacoes(data.observacoes);
            
            // Limpar o formulário de nova observação
            document.getElementById('textarea-nova-observacao').value = '';
            
            // Atualizar o subtítulo com informações da demanda
            document.getElementById('modal-observacoes-subtitle').textContent = 
                `Demanda: ${idDemanda} - Histórico de observações`;
                
            // Abrir o modal
            if (modalObservacoesInstance) {
                modalObservacoesInstance.show();
            }
                
        } else {
            showMessageObservacoes('Erro ao carregar observações: ' + data.message, 'error');
        }
        
    } catch (error) {
        console.error('Erro ao buscar observações:', error);
        showMessageObservacoes('Erro ao carregar observações', 'error');
    }
}

/**
 * Carrega as observações na lista do modal
 * @param {Array} observacoes - Array de observações
 */
function carregarObservacoes(observacoes) {
    const listaContainer = document.getElementById('lista-observacoes');
    const template = document.getElementById('template-observacao-item');
    
    // Limpar lista atual
    listaContainer.innerHTML = '';
    
    if (!observacoes || observacoes.length === 0) {
        listaContainer.innerHTML = `
            <div class=" overflow-y-auto flex flex-col text-center py-8 text-gray-500 dark:text-gray-400">
                <svg class="w-12 h-12 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>
                </svg>
                <p>Nenhuma observação encontrada</p>
                <p class="text-sm">Seja o primeiro a adicionar uma observação!</p>
            </div>
        `;
        return;
    }
    
    // Criar itens de observação
    observacoes.forEach(obs => {
        const clone = template.content.cloneNode(true);
        const item = clone.querySelector('.observacao-item');
        
        // Definir o ID da observação
        item.setAttribute('data-observacao-id', obs.id);
        
        // Preencher dados
        clone.querySelector('.observacao-usuario').textContent = obs.usuario || 'Usuário';
        clone.querySelector('.observacao-data').textContent = formatarData(obs.data);
        clone.querySelector('.observacao-conteudo p').textContent = obs.observacao;
        
        const imagem = clone.querySelector('.observacao-imagem');
        if (obs.matricula) {
            imagem.src = `https://humanograma.intranet.bb.com.br/avatar/${obs.matricula}`;}

        listaContainer.appendChild(clone);
    });
}

/**
 * Formata a data para exibição
 * @param {string} dataString - Data em formato string
 * @returns {string} Data formatada
 */
function formatarData(dataString) {
    const data = new Date(dataString);
    return data.toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: '2-digit', 
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

/**
 * Adiciona uma nova observação
 */
async function adicionarObservacao(event) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    const btnAdicionar = document.getElementById('btn-adicionar-observacao');
    
    const observacao = formData.get('observacao');
    
    // Limpar mensagens anteriores
    hideMessageObservacoes('message-container-nova-observacao');
    
    if (!observacao || observacao.trim().length === 0) {
        showMessageObservacoes('Por favor, digite uma observação', 'warning', 'message-container-nova-observacao');
        return;
    }
    
    // Desabilitar botão durante o envio
    if (btnAdicionar) {
        btnAdicionar.disabled = true;
        btnAdicionar.innerHTML = '<svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>Adicionando...';
    }
    
    try {
        const response = await fetch('/demanda/observacoes/inserir', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                idDemanda: currentDemandaId,
                observacao: observacao.trim()
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showMessageObservacoes('Observação adicionada com sucesso', 'success', 'message-container-nova-observacao');
            // Limpar formulário
            form.reset();
            // Recarregar observações
            setTimeout(() => {
                abrirObservacoes(currentDemandaId);
            }, 100);
        } else {
            showMessageObservacoes('Erro ao adicionar observação: ' + data.message, 'error', 'message-container-nova-observacao');
        }
        
    } catch (error) {
        console.error('Erro ao adicionar observação:', error);
        showMessageObservacoes('Erro ao adicionar observação', 'error', 'message-container-nova-observacao');
    } finally {
        // Reabilitar botão
        if (btnAdicionar) {
            btnAdicionar.disabled = false;
            btnAdicionar.innerHTML = 'Adicionar Observação';
        }
    }
}

// Event Listeners
document.addEventListener('DOMContentLoaded', function() {
    // Inicializar modais
    initializeModals();
    
    // Formulário de adicionar observação
    const formAdicionar = document.getElementById('form-adicionar-observacao');
    if (formAdicionar) {
        formAdicionar.addEventListener('submit', adicionarObservacao);
    }
});