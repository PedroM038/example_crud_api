/* 
    * @file public/js/sidebar.js
    * Este arquivo contém o código JavaScript para a funcionalidade da sidebar.
    * Fica aqui de exemplo de como implementar uma sidebar responsiva com toggle e fechamento.
    * Você pode personalizar a sidebar conforme necessário.
*/

document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.getElementById('default-sidebar');
    const mainContent = document.getElementById('main-content');
    const toggleButton = document.querySelector('[data-drawer-toggle="default-sidebar"]');
    const closeButton = document.querySelector('[data-drawer-hide="default-sidebar"]');
    const overlay = document.getElementById('sidebar-overlay');

    function toggleSidebar() {
        const isOpen = !sidebar.classList.contains('-translate-x-full');
        
        if (isOpen) {
            // Fechar sidebar
            sidebar.classList.add('-translate-x-full');
            mainContent.classList.remove('ml-64');
            overlay.classList.add('hidden');
        } else {
            // Abrir sidebar
            sidebar.classList.remove('-translate-x-full');
            mainContent.classList.add('ml-64');
            overlay.classList.remove('hidden');
        }
    }

    function closeSidebar() {
        sidebar.classList.add('-translate-x-full');
        mainContent.classList.remove('ml-64');
        overlay.classList.add('hidden');
    }

    if (toggleButton) {
        toggleButton.addEventListener('click', toggleSidebar);
    }

    if (closeButton) {
        closeButton.addEventListener('click', closeSidebar);
    }

    if (overlay) {
        overlay.addEventListener('click', closeSidebar);
    }

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeSidebar();
        }
    });

    const sidebarLinks = sidebar.querySelectorAll('a');
    sidebarLinks.forEach(link => {
        link.addEventListener('click', function() {
            if (window.innerWidth < 1024) {
                closeSidebar();
            }
        });
    });
});