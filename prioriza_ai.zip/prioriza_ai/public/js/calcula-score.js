let dadosMatrizGlobal = {};
let tipScoresGlobal = [];

// Função para inicializar o cálculo do score (GLOBAL)
function inicializarCalculoScore(dadosMatriz, tipScores) {
    dadosMatrizGlobal = dadosMatriz;
    tipScoresGlobal = tipScores;
    adicionarListenersMatriz();
}

// Função para calcular o score da matriz GUTHIE (GLOBAL)
function calcularScore() {
    const gravidade = document.getElementById('gravidade-melhoria').value;
    const urgencia = document.getElementById('urgencia-melhoria').value;
    const tendencia = document.getElementById('tendencia-melhoria').value;
    const horas = document.getElementById('horas-economia-melhoria').value;
    const impacto = document.getElementById('impacto-matriz-melhoria').value;
    const experiencia = document.getElementById('exp-cliente-melhoria').value;

    // Verificar se todos os campos estão preenchidos
    if (!gravidade || !urgencia || !tendencia || !horas || !impacto || !experiencia) {
        // Limpar o score se algum campo estiver vazio
        const scoreElement = document.getElementById('score-valor-melhoria');
        const legendaElement = document.getElementById('score-legenda-melhoria');
        if (scoreElement) scoreElement.textContent = '--';
        if (legendaElement) legendaElement.textContent = '--';
        return;
    }

    try {
        // Encontrar os dados correspondentes aos valores selecionados
        const dadosGravidade = dadosMatrizGlobal.gravidades.find(g => g.id == gravidade);
        const dadosUrgencia = dadosMatrizGlobal.urgencia.find(u => u.id == urgencia);
        const dadosTendencia = dadosMatrizGlobal.tendencias.find(t => t.id == tendencia);
        const dadosHoras = dadosMatrizGlobal.horas.find(h => h.id == horas);
        const dadosImpacto = dadosMatrizGlobal.impactos.find(i => i.id == impacto);
        const dadosExperiencia = dadosMatrizGlobal.experiencias.find(e => e.id == experiencia);

        // Verificar se todos os dados foram encontrados
        if (!dadosGravidade || !dadosUrgencia || !dadosTendencia || !dadosHoras || !dadosImpacto || !dadosExperiencia) {
            console.error('Erro: Nem todos os dados da matriz foram encontrados');
            return;
        }

        // Calcular o score
        const score = (
            (dadosGravidade.pontos * dadosGravidade.peso) +
            (dadosUrgencia.pontos * dadosUrgencia.peso) +
            (dadosTendencia.pontos * dadosTendencia.peso) +
            (dadosHoras.pontos * dadosHoras.peso) +
            (dadosImpacto.pontos * dadosImpacto.peso) +
            (dadosExperiencia.pontos * dadosExperiencia.peso)
        ) / 15;

        // Atualizar o elemento do score na interface
        const scoreElement = document.getElementById('score-valor-melhoria');
        const legendaElement = document.getElementById('score-legenda-melhoria');

        if (scoreElement) {
            scoreElement.textContent = score.toFixed(2);
        }

        let legenda = '--';
        for (const item of tipScoresGlobal) {
            const min = parseFloat(item.score_minimo);
            const max = parseFloat(item.score_maximo);
            if (score >= min && score <= max) {
                legenda = item.classificacao;
                break;
            }
        }

        if (legendaElement) legendaElement.textContent = legenda;

    } catch (error) {
        console.error('Erro ao calcular score:', error);
    }
}

// Função para adicionar event listeners aos campos da matriz (GLOBAL)
function adicionarListenersMatriz() {
    const campos = ['gravidade-melhoria', 'urgencia-melhoria', 'tendencia-melhoria', 'horas-economia-melhoria', 'impacto-matriz-melhoria', 'exp-cliente-melhoria'];

    campos.forEach(campo => {
        const element = document.getElementById(campo);
        if (element) {
            element.addEventListener('change', calcularScore);
        }
    });
}