// Inicialização da tabela de dados com filtros e paginação
if (document.getElementById("tabela-demandas") && typeof simpleDatatables.DataTable !== 'undefined') {
    let dataTable;

    // Adicionar um pequeno delay para garantir que a tabela seja renderizada primeiro
    setTimeout(() => {
        // Esconder o loading e mostrar a tabela quando estiver pronta
        const loadingElement = document.getElementById('table-loading');
        const tableContainer = document.getElementById('table-container');
        
        dataTable = new simpleDatatables.DataTable("#tabela-demandas", {
            perPage: 10,
            labels: {
                placeholder: "Pesquisar...",
                perPage: "por página",
                noRows: "Nenhum registro encontrado",
                info: "Mostrando {start} a {end} de {rows} registros"
            },
            columns: [
                {
                    select: 0, // Primeira coluna (Ações)
                    sortable: false,
                    searchable: false
                },
            ],
            layout: {
                top: "",
                bottom: "{info}{select}{pager}"
            },
            tableRender: (_data, table, type) => {
                if (type === "print") {
                    return table
                }

                // Adicionar atributos para responsividade usando a estrutura correta
                table.attributes = {
                    ...table.attributes,
                    style: 'width: 100%; table-layout: auto;'
                };

                const tHead = table.childNodes[0]
                const filterHeaders = {
                    nodeName: "TR",
                    attributes: {
                        class: "search-filtering-row"
                    },
                    childNodes: tHead.childNodes[0].childNodes.map(
                        (_th, index) => ({
                            nodeName: "TH",
                            attributes: {
                                style: "padding: 0.5rem; vertical-align: top;"
                            },
                            childNodes: index === 0 ? [] : [ // Não adicionar filtro na coluna de ações
                                {
                                    nodeName: "INPUT",
                                    attributes: {
                                        class: "datatable-input form-control form-control-sm",
                                        type: "search",
                                        "data-columns": "[" + index + "]",
                                        style: "width: 100%; min-width: 80px; font-size: 0.875rem;",
                                        placeholder: "Filtrar..."
                                    }
                                }
                            ]
                        })
                    )
                }
                tHead.childNodes.push(filterHeaders)
                return table
            }
        });

        // Exportar a tabela para uso posterior
        window.dataTable = dataTable;

        // Adicionar estilos CSS dinamicamente para responsividade
        const style = document.createElement('style');
        style.textContent = `
            .dataTable-wrapper {
                overflow-x: auto;
            }
            
            .dataTable-table {
                width: 100% !important;
                table-layout: auto !important;
                min-width: 600px;
            }
            
            .dataTable-table th,
            .dataTable-table td {
                overflow: hidden;
                text-overflow: ellipsis;
                max-width: none;
                min-width: 80px;
            }
            
            .search-filtering-row th {
                padding: 0.5rem !important;
                border-bottom: 1px solid #dee2e6;
            }
            
            .datatable-input {
                border: 1px solid #ced4da;
                border-radius: 0.375rem;
                padding: 0.25rem 0.5rem;
                font-size: 0.875rem;
                transition: border-color 0.15s ease-in-out;
                box-sizing: border-box;
            }
            
            .datatable-input:focus {
                border-color: #80bdff;
                outline: 0;
                box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
            }
            
            /* Responsividade automática das colunas */
            .dataTable-table {
                table-layout: auto !important;
            }
            
            .dataTable-table th,
            .dataTable-table td {
                width: auto !important;
                min-width: 120px;
            }
            
            /* Coluna do número GD (terceira coluna) - manter número e estrela na mesma linha */
            .dataTable-table th:nth-child(3),
            .dataTable-table td:nth-child(3) {
                white-space: nowrap !important;
                width: auto !important;
            }
            
            /* Coluna do nome da demanda (quarta coluna) - permitir quebra de linha */
            .dataTable-table th:nth-child(4),
            .dataTable-table td:nth-child(4) {
                white-space: normal;
                max-width: 300px;
            }
            
            /* Coluna de ações com largura fixa */
            .dataTable-table th:first-child,
            .dataTable-table td:first-child {
                width: 200px !important;
                min-width: 200px !important;
                max-width: 200px !important;
            }

            /* Estilos para badges de prioridade */
            .dataTable-table .priority-badge {
                display: inline-block;
                white-space: nowrap;
                max-width: 100%;
            }
            
            .dataTable-table td {
                vertical-align: middle;
            }

             /* Classes para prioridades */
            .bg-green-100 { background-color: #dcfce7; }
            .text-green-800 { color: #166534; }
            .border-green-200 { border-color: #bbf7d0; }

            .bg-blue-50 { background-color: #eff6ff; }
            .text-blue-700 { color: #1d4ed8; }
            .border-blue-100 { border-color: #dbeafe; }

            .bg-blue-100 { background-color: #dbeafe; }
            .text-blue-800 { color: #1e40af; }
            .border-blue-200 { border-color: #bfdbfe; }

            .bg-blue-200 { background-color: #bfdbfe; }
            .text-blue-900 { color: #1e3a8a; }
            .border-blue-300 { border-color: #93c5fd; }

            .bg-blue-300 { background-color: #93c5fd; }
            
            .bg-yellow-100 { background-color: #fef3c7; }
            .text-yellow-800 { color: #92400e; }
            .border-yellow-200 { border-color: #fde68a; }
            
            .bg-orange-100 { background-color: #fed7aa; }
            .text-orange-800 { color: #9a3412; }
            .border-orange-200 { border-color: #fecaca; }
            
            .bg-red-100 { background-color: #fee2e2; }
            .text-red-800 { color: #991b1b; }
            .border-red-200 { border-color: #fecaca; }
            
            .bg-gray-100 { background-color: #f3f4f6; }
            .text-gray-800 { color: #1f2937; }
            .text-gray-600 { color: #4b5563; }
            .border-gray-200 { border-color: #e5e7eb; }

            .bg-rose-300 { background-color: #ffa1ad; }
            .bg-rose-100 { background-color: #ffe4e6; }
            .bg-rose-200 { background-color: #ffccd3; }
            .text-rose-900 { color: #881337; }
            .text-rose-700 { color: #b91c1c; }
            .text-rose-800 { color: #9f1d3a; }
            .border-rose-400 { border-color: #ff7f9c; }
            
            @media (max-width: 768px) {
                .dataTable-table th,
                .dataTable-table td {
                    min-width: 100px;
                    font-size: 0.8rem;
                }
                
                .dataTable-table th:first-child,
                .dataTable-table td:first-child {
                    width: 180px !important;
                    min-width: 180px !important;
                }
                
                .datatable-input {
                    font-size: 0.75rem;
                    padding: 0.2rem 0.4rem;
                }
            }
            
            @media (max-width: 576px) {
                .dataTable-table th,
                .dataTable-table td {
                    min-width: 80px;
                    font-size: 0.75rem;
                }
                
                .dataTable-table th:first-child,
                .dataTable-table td:first-child {
                    width: 160px !important;
                    min-width: 160px !important;
                }
            }
            
            .datatable-wrapper .datatable-bottom .datatable-pagination .datatable-pagination-list-item.datatable-active .datatable-pagination-list-item-link {
                background-color: #e5e7eb;  
                color: blue;
            }
        `;
        document.head.appendChild(style);

        // Aguardar a tabela ser renderizada antes de aplicar redimensionamento
        setTimeout(() => {
            // Adicionar event listener para o redimensionamento da janela
            window.addEventListener('resize', () => {
                if (dataTable && dataTable.wrapper) {
                    dataTable.refresh();
                }
            });

            // Esconder o loading e mostrar a tabela após a inicialização completa
            if (loadingElement) {
                loadingElement.style.display = 'none';
            }
            if (tableContainer) {
                tableContainer.classList.remove('hidden');
                // Adicionar animação suave de entrada
                tableContainer.style.opacity = '0';
                setTimeout(() => {
                    tableContainer.style.transition = 'opacity 0.3s ease-in-out';
                    tableContainer.style.opacity = '1';
                }, 10);
            }
        }, 200);

    }, 50);
}