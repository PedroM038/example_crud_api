/**
 * @file public/js/andamento-melhoria.js
 * @description Gerencia o step de andamento no modal de edição de demanda melhoria.
 * Renderiza checkboxes agrupados por etapa e sincroniza com o backend.
 */

const AndamentoManager = (function () {
    let fasesEtapasDisponiveis = {};
    let fasesEtapasMarcadas = [];
    let idDemandaAtual = null;
    let progressoAtual = 0;

    const containerId = 'andamento-container-melhoria';
    const progressoBarId = 'progresso-bar-melhoria';
    const progressoTextoId = 'progresso-texto-melhoria';

    /**
     * Inicializa o gerenciador de andamento
     * @param {object} fasesEtapas - Objeto com fases agrupadas por etapa
     * @param {array} marcados - Array de IDs das fases já marcadas
     * @param {number} idDemanda - ID da demanda atual
     * @param {number} progresso - Progresso atual em percentual
     */
    function inicializar(fasesEtapas, marcados, idDemanda, progresso = 0) {
        fasesEtapasDisponiveis = fasesEtapas || {};
        fasesEtapasMarcadas = marcados || [];
        idDemandaAtual = idDemanda;
        progressoAtual = progresso;

        renderizar();
        atualizarProgresso();
    }

    /**
     * Renderiza os checkboxes agrupados por etapa
     */
    function renderizar() {
        const container = document.getElementById(containerId);
        if (!container) return;

        container.innerHTML = '';

        const etapas = Object.keys(fasesEtapasDisponiveis);

        if (etapas.length === 0) {
            container.innerHTML = `
                <div class="text-center text-gray-500 py-8">
                    <i class="fas fa-info-circle text-2xl mb-2"></i>
                    <p>Nenhuma fase/etapa cadastrada no sistema.</p>
                </div>
            `;
            return;
        }

        // Mesmo estilo para todas as etapas
        const estilo = {
            bg: 'bg-white',
            border: 'border-gray-200',
            header: 'bg-gray-50',
            text: 'text-gray-700',
            check: 'text-blue-600',
            progress: 'bg-blue-500',
            badge: 'bg-gray-100 text-gray-600 border-gray-300'
        };

        const grid = document.createElement('div');
        grid.className = 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4';

        // para cada etapa do objeto, adiciona headers e body
        etapas.forEach((etapa) => {
            const fases = fasesEtapasDisponiveis[etapa];

            const etapaCard = document.createElement('div');
            etapaCard.className = `${estilo.bg} ${estilo.border} border rounded-lg overflow-hidden shadow-sm`;

            // Header da etapa com progresso
            const header = document.createElement('div');
            header.className = `${estilo.header} px-4 py-3 border-b ${estilo.border}`;
            header.innerHTML = `
                <div class="flex items-center justify-between mb-2">
                    <h6 class="text-sm font-semibold ${estilo.text} flex items-center gap-2">
                        <i class="fas fa-layer-group text-blue-500"></i>
                        ${etapa}
                    </h6>
                    <button type="button" class="btn-marcar-todas text-xs text-blue-600 hover:text-blue-800 hover:underline" data-etapa="${etapa}">
                        Marcar todas
                    </button>
                </div>
                <div class="flex items-center gap-2">
                    <div class="flex-1 bg-gray-200 rounded-full h-2 overflow-hidden">
                        <div class="progresso-etapa h-full ${estilo.progress} rounded-full transition-all duration-300" 
                            data-etapa="${etapa}" style="width: 0%"></div>
                    </div>
                    <span class="progresso-etapa-texto text-xs font-semibold text-blue-600" data-etapa="${etapa}">0%</span>
                </div>
            `;

            // Body com checkboxes
            const body = document.createElement('div');
            body.className = 'p-3 space-y-2';

            // para cada fase naquela etapa, adiciona a porcentagem e monta a div
            fases.forEach(fase => {
                const isChecked = fasesEtapasMarcadas.includes(fase.id);
                // Converter decimal para porcentagem (0.25 -> 25)
                const percentualExibicao = (parseFloat(fase.percentual) * 100).toFixed(0);
                
                const checkboxDiv = document.createElement('div');
                checkboxDiv.className = 'flex items-center justify-between py-1';

                checkboxDiv.innerHTML = `
                    <label class="flex items-center cursor-pointer group">
                        <input type="checkbox" 
                            name="fase_etapa" 
                            value="${fase.id}" 
                            data-percentual="${fase.percentual}"
                            data-etapa="${etapa}"
                            ${isChecked ? 'checked' : ''}
                            class="w-4 h-4 ${estilo.check} bg-gray-100 border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:ring-offset-0 cursor-pointer">
                        <span class="ml-2 text-sm text-gray-600 group-hover:text-gray-900">${fase.fase}</span>
                    </label>
                    <span class="text-xs font-medium ${estilo.badge} px-2 py-0.5 rounded-full border">
                        ${percentualExibicao}%
                    </span>
                `;

                body.appendChild(checkboxDiv);
            });

            etapaCard.appendChild(header);
            etapaCard.appendChild(body);
            grid.appendChild(etapaCard);
        });

        container.appendChild(grid);

        // Event listeners
        adicionarEventListeners();
        
        // Atualizar progresso inicial de cada etapa
        atualizarProgressoPorEtapa();
    }

    /**
     * Adiciona event listeners aos checkboxes e botões
     */
    function adicionarEventListeners() {
        const container = document.getElementById(containerId);
        if (!container) return;

        // Checkboxes
        container.querySelectorAll('input[name="fase_etapa"]').forEach(checkbox => {
            checkbox.addEventListener('change', function () {
                const id = parseInt(this.value);
                if (this.checked) {
                    if (!fasesEtapasMarcadas.includes(id)) {
                        fasesEtapasMarcadas.push(id);
                    }
                } else {
                    fasesEtapasMarcadas = fasesEtapasMarcadas.filter(m => m !== id);
                }
                atualizarProgressoPorEtapa();
            });
        });

        // Botões "Marcar todas"
        container.querySelectorAll('.btn-marcar-todas').forEach(btn => {
            btn.addEventListener('click', function () {
                const etapa = this.dataset.etapa;
                const checkboxes = container.querySelectorAll(`input[data-etapa="${etapa}"]`);
                const todosChecked = Array.from(checkboxes).every(cb => cb.checked);

                checkboxes.forEach(cb => {
                    cb.checked = !todosChecked;
                    const id = parseInt(cb.value);
                    if (!todosChecked) {
                        if (!fasesEtapasMarcadas.includes(id)) {
                            fasesEtapasMarcadas.push(id);
                        }
                    } else {
                        fasesEtapasMarcadas = fasesEtapasMarcadas.filter(m => m !== id);
                    }
                });

                // Atualizar texto do botão
                this.textContent = todosChecked ? 'Marcar todas' : 'Desmarcar todas';

                atualizarProgressoPorEtapa();
            });
        });
    }

    /**
     * Calcula e atualiza a barra de progresso de cada etapa
     */
    function atualizarProgressoPorEtapa() {
        const container = document.getElementById(containerId);
        if (!container) return;

        // Agrupar checkboxes por etapa
        const etapas = Object.keys(fasesEtapasDisponiveis);

        etapas.forEach(etapa => {
            const checkboxes = container.querySelectorAll(`input[data-etapa="${etapa}"]`);
            let totalPercentual = 0;

            checkboxes.forEach(cb => {
                if (cb.checked) {
                    // Percentual já está em decimal (0.25), multiplicar por 100
                    totalPercentual += parseFloat(cb.dataset.percentual) * 100 || 0;
                }
            });

            // Limita a 100%
            totalPercentual = Math.min(totalPercentual, 100);

            // Atualiza barra de progresso da etapa
            const progressoBar = container.querySelector(`.progresso-etapa[data-etapa="${etapa}"]`);
            const progressoTexto = container.querySelector(`.progresso-etapa-texto[data-etapa="${etapa}"]`);

            if (progressoBar) {
                progressoBar.style.width = `${totalPercentual}%`;
            }

            if (progressoTexto) {
                progressoTexto.textContent = `${totalPercentual.toFixed(0)}%`;
            }
        });
    }

    /**
     * Calcula e atualiza a barra de progresso (mantido para compatibilidade)
     */
    function atualizarProgresso() {
        atualizarProgressoPorEtapa();
    }

    /**
     * Retorna os IDs das fases/etapas marcadas
     * @returns {array} Array de IDs
     */
    function getMarcados() {
        return [...fasesEtapasMarcadas];
    }

    /**
     * Retorna o progresso atual
     * @returns {number} Percentual de progresso
     */
    function getProgresso() {
        return progressoAtual;
    }

    /**
     * Sincroniza os andamentos com o backend
     * @returns {Promise} Resultado da sincronização
     */
    async function sincronizar() {
        if (!idDemandaAtual) {
            console.error('ID da demanda não definido');
            return { success: false, message: 'ID da demanda não definido' };
        }

        try {
            const response = await fetch(`/demanda/andamento/${idDemandaAtual}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ fasesEtapasMarcadas: fasesEtapasMarcadas })
            });

            const result = await response.json();

            if (result.success && result.progresso !== undefined) {
                progressoAtual = result.progresso;
                atualizarProgressoUI(result.progresso);
            }

            return result;
        } catch (error) {
            console.error('Erro ao sincronizar andamentos:', error);
            return { success: false, message: 'Erro ao sincronizar andamentos' };
        }
    }

    /**
     * Atualiza apenas a UI do progresso (sem recalcular)
     * @param {number} progresso - Percentual de progresso
     */
    function atualizarProgressoUI(progresso) {
        progressoAtual = progresso;
        const progressoBar = document.getElementById(progressoBarId);
        const progressoTexto = document.getElementById(progressoTextoId);

        if (progressoBar) {
            progressoBar.style.width = `${progresso}%`;
        }
        if (progressoTexto) {
            progressoTexto.textContent = `${progresso.toFixed(1)}%`;
        }
    }

    /**
     * Limpa o estado do gerenciador
     */
    function limpar() {
        fasesEtapasDisponiveis = {};
        fasesEtapasMarcadas = [];
        idDemandaAtual = null;
        progressoAtual = 0;

        const container = document.getElementById(containerId);
        if (container) container.innerHTML = '';

        atualizarProgressoUI(0);
    }

    /**
     * Define o ID da demanda atual
     * @param {number} id - ID da demanda
     */
    function setIdDemanda(id) {
        idDemandaAtual = id;
    }

    return {
        inicializar,
        getMarcados,
        getProgresso,
        sincronizar,
        limpar,
        setIdDemanda,
        atualizarProgresso
    };
})();
