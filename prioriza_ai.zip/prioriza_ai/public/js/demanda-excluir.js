let idDemandaParaExcluir = null;

// Declarar o messageContainer
const messageContainer = document.getElementById('message-container');

function excluirDemanda(id) {
    idDemandaParaExcluir = id;

    // Usar Flowbite para abrir o modal
    const modal = FlowbiteInstances.getInstance('Modal', 'modal-excluir-demanda');
    if (modal) {
        modal.show();
    } else {
        // Se não existir, criar a instância
        const modalElement = document.getElementById('modal-excluir-demanda');
        const modal = new Modal(modalElement);
        modal.show();
    }
}

// Função para mostrar mensagens no modal
function showMessage(message, type) {
    const bgColor = type === 'success' ? 'bg-green-100 text-green-700 border-green-300' : 'bg-red-100 text-red-700 border-red-300';
    const icon = type === 'success' ? 'fas fa-check-circle' : 'fas fa-exclamation-circle';

    messageContainer.innerHTML = `
        <div class="p-3 border rounded-lg ${bgColor}">
            <i class="${icon} mr-2"></i>
            ${message}
        </div>
    `;
    messageContainer.classList.remove('hidden');
}

// Função para esconder mensagens do modal
function hideMessage() {
    messageContainer.classList.add('hidden');
    messageContainer.innerHTML = '';
}

document.getElementById("button-demanda-excluir").addEventListener("click", async function () {
    if (!idDemandaParaExcluir) return;
    let result = null;

    try {
        const response = await fetch(`/excluir-demanda/${idDemandaParaExcluir}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ id: idDemandaParaExcluir })
        });

        result = await response.json();

        if (result.success) {
            showMessage(result.message, 'success');
            setTimeout(() => {
                window.location.reload();
            }, 100);
        } else {
            showMessage(result.message, 'error');
        }

    } catch (error) {
        console.error("Erro na requisição:", error);
        showMessage("Erro ao excluir a demanda.", 'error');
    }

    // Fechar o modal após a operação (apenas se sucesso)
    if (result) {
        const modal = FlowbiteInstances.getInstance('Modal', 'modal-excluir-demanda');
        if (modal) {
            modal.hide();
        }
    }
});