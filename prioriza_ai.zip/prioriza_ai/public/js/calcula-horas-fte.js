// Variável para armazenar dados do cálculo do fte e horas ano
let dadosCalculoGlobal = {
    tempos: [],
    repeticoes: []
}

// Função para inicializar o cálculo de FTE e Horas/Ano (GLOBAL)
function inicializarCalculoFteHoras(dadosCalculo, sufixo = 'melhoria') {
    dadosCalculoGlobal = dadosCalculo;
    adicionarListenersCalculoFteHoras(sufixo);
}

// Função para calcular horas_ano e fte (GLOBAL)
function calcularHorasAnoEFte(sufixo = 'melhoria') {
    const qtdFuncionarios = document.getElementById(`quantidade-funci-${sufixo}`).value;
    const qtdFrequencia = document.getElementById(`quantidade-frequencia-${sufixo}`).value;
    const tempoId = document.getElementById('tp-tmp-atividade').value;
    const frequenciaId = document.getElementById(`tp-freq-${sufixo}`).value;
    const qtdTempo = document.getElementById(`quantidade-tempo-${sufixo}`).value;

    // Verificar se todos os campos estão preenchidos
    if (!qtdFuncionarios || !qtdFrequencia || !tempoId || !frequenciaId || !qtdTempo) {
        // Limpar os valores se algum campo estiver vazio
        const horasAnoElement = document.getElementById(`horas-ano-valor-${sufixo}`);
        const fteElement = document.getElementById(`fte-ano-valor-${sufixo}`);

        if (horasAnoElement) horasAnoElement.textContent = '--';
        if (fteElement) fteElement.textContent = '--';
        return;
    }

    try {
        // Encontrar os dados correspondentes aos valores selecionados
        const dadosTempo = dadosCalculoGlobal.tempos.find(t => t.id == tempoId);
        const dadosRepeticao = dadosCalculoGlobal.repeticoes.find(r => r.id == frequenciaId);

        // Verificar se os dados foram encontrados
        if (!dadosTempo || !dadosRepeticao) {
            console.error('Erro: Dados de tempo ou repetição não encontrados');
            return;
        }

        // Converter valores para números
        const nrExecutantes = parseFloat(qtdFuncionarios);
        const nrRepeticoes = parseFloat(qtdFrequencia);
        const calcRepeticao = parseFloat(dadosRepeticao.calc_repeticao);
        const tempoTarefa = parseFloat(qtdTempo);
        const calcTempo = parseFloat(dadosTempo.calc_tempo);

        // Calcular horas_ano
        const horasAno = Math.round((nrExecutantes * (nrRepeticoes * calcRepeticao) * (tempoTarefa / calcTempo)) * 100) / 100;

        // Calcular fte
        const fte = Math.round(((nrExecutantes * (nrRepeticoes * calcRepeticao) * (tempoTarefa / calcTempo)) / (6 * 22 * 12 * 0.85)) * 100) / 100;

        // Atualizar os elementos na interface
        const horasAnoElement = document.getElementById(`horas-ano-valor-${sufixo}`);
        const fteElement = document.getElementById(`fte-ano-valor-${sufixo}`);

        if (horasAnoElement) {
            horasAnoElement.textContent = horasAno.toFixed(2);
        }

        if (fteElement) {
            fteElement.textContent = fte.toFixed(2);
        }

    } catch (error) {
        console.error('Erro ao calcular horas_ano e fte:', error);
    }
}

// Função para adicionar event listeners aos campos de cálculo (GLOBAL)
function adicionarListenersCalculoFteHoras(sufixo = 'melhoria') {
    const campos = [
        `quantidade-funci-${sufixo}`,
        `quantidade-frequencia-${sufixo}`,
        'tp-tmp-atividade',
        `tp-freq-${sufixo}`,
        `quantidade-tempo-${sufixo}`
    ];

    campos.forEach(campo => {
        const element = document.getElementById(campo);
        if (element) {
            element.addEventListener('change', () => calcularHorasAnoEFte(sufixo));
            element.addEventListener('input', () => calcularHorasAnoEFte(sufixo));
        }
    });

    // Adicionar listeners específicos para os botões de incremento/decremento
    const botoesIncremento = [
        `increment-button-funci-${sufixo}`,
        `decrement-button-funci-${sufixo}`,
        `increment-button-freq-${sufixo}`,
        `decrement-button-freq-${sufixo}`,
        `increment-button-tempo-${sufixo}`,
        `decrement-button-tempo-${sufixo}`
    ];

    botoesIncremento.forEach(botaoId => {
        const botao = document.getElementById(botaoId);
        if (botao) {
            botao.addEventListener('click', () => calcularHorasAnoEFte(sufixo));
        }
    });
}