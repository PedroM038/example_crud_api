// Nota: Podemos jogar os helpers em um arquivo separado se necessário no futuro
// O arquivo original tinha muitas linhas. Por esse motivo, tomei a liberdade de
// reorganizar algumas partes do código para otimização e clareza, sem alterar a lógica original.
document.addEventListener('DOMContentLoaded', function () {
    // preguiça de digitar document.getElementById várias vezes
    const $ = id => document.getElementById(id);

    // elementos
    const modalEditarDemanda = $('modal-editar-melhoria');
    const formEditarDemanda = $('form-editar-melhoria');
    const messageContainerEditar = $('message-container-editar-melhoria');
    const btnSalvarEdicao = $('btn-salvar-edicao-melhoria');
    let demandaEditandoId = null;
    let demandaOriginal = null; // Armazena dados originais da demanda
    let modalInstance = null;

    // Status que removem a demanda da tabela principal
    const STATUS_FINALIZACAO = ['Entregue', 'Cancelado'];

    if (modalEditarDemanda && typeof Modal !== 'undefined') {
        modalInstance = new Modal(modalEditarDemanda, {
            placement: 'center',
            backdrop: 'dynamic',
            backdropClasses: 'bg-gray-900/50 dark:bg-gray-900/80 fixed inset-0 z-40',
            closable: true
        });
    }

    // --- Helpers ---
    function createOption(value, text) {
        const opt = document.createElement('option');
        opt.value = value ?? '';
        opt.textContent = text ?? '';
        return opt;
    }

    function setOptions(select, items, valueFn, textFn, placeholder = 'Selecione') {
        if (!select) return;
        select.innerHTML = '';
        const frag = document.createDocumentFragment();
        frag.appendChild(createOption('', placeholder));
        if (Array.isArray(items)) {
            items.forEach(item => {
                frag.appendChild(createOption(valueFn(item), textFn(item)));
            });
        }
        select.appendChild(frag);
    }

    function setOptionsByConfig(selectId, sourceArr, config) {
        const select = $(selectId);
        if (!select) return;
        setOptions(select, sourceArr, config.valueFn, config.textFn, config.placeholder);
    }

    function triggerChange(el) {
        if (!el) return;
        el.dispatchEvent(new Event('change', { bubbles: true }));
    }

    function setSelectValue(selectId, value, dispatch = false) {
        const s = $(selectId);
        if (!s) return;
        if (value === null || value === undefined || value === '') {
            s.value = '';
            return;
        }
        // somente setar se realmente diferente (evita disparos desnecessários)
        if (s.value !== String(value)) {
            s.value = String(value);
            if (dispatch) triggerChange(s);
        }
    }

    // configuração centralizada para popular selects
    const SELECT_CONFIGS = [
        { id: 'area-melhoria', src: 'areas', valueFn: i => i.id, textFn: i => i.area, placeholder: 'Selecione a Área' },
        { id: 'indicador-melhoria', src: 'indicadores', valueFn: i => i.id, textFn: i => i.indicador, placeholder: 'Selecione' },
        { id: 'inviabilidade-melhoria', src: 'inviabilidades', valueFn: i => i.id, textFn: i => i.inviabilidade },
        { id: 'status-demanda-melhoria', src: 'status', valueFn: i => i.id, textFn: i => i.status },
        { id: 'tp-tmp-atividade', src: 'tempos', valueFn: i => i.id, textFn: i => i.tempo },
        { id: 'tp-freq-melhoria', src: 'repeticoes', valueFn: i => i.id, textFn: i => i.repeticao },

        // formatados "id - legenda"
        { id: 'gravidade-melhoria', src: 'gravidades', valueFn: i => i.id, textFn: i => `${i.id} - ${i.legenda}` },
        { id: 'urgencia-melhoria', src: 'urgencias', valueFn: i => i.id, textFn: i => `${i.id} - ${i.legenda}` },
        { id: 'tendencia-melhoria', src: 'tendencias', valueFn: i => i.id, textFn: i => `${i.id} - ${i.legenda}` },
        { id: 'horas-economia-melhoria', src: 'horasEconomizadas', valueFn: i => i.id, textFn: i => `${i.id} - ${i.legenda}` },
        { id: 'impacto-matriz-melhoria', src: 'impactos', valueFn: i => i.id, textFn: i => `${i.id} - ${i.legenda}` },
        { id: 'exp-cliente-melhoria', src: 'experiencias', valueFn: i => i.id, textFn: i => `${i.id} - ${i.legenda}` },

        // funcionários (value = nome, text = "nome (matricula)")
        { id: 'design-resp-melhoria', src: 'funcionariosDesign', valueFn: i => i.nome, textFn: i => `${i.nome} (${i.matricula})` },
        { id: 'design-aux-melhoria', src: 'funcionariosDesign', valueFn: i => i.nome, textFn: i => `${i.nome} (${i.matricula})` },
        { id: 'dev-responsavel-melhoria', src: 'funcionariosAtan', valueFn: i => i.nome, textFn: i => `${i.nome} (${i.matricula})` },
        { id: 'dev-aux-melhoria', src: 'funcionariosAtan', valueFn: i => i.nome, textFn: i => `${i.nome} (${i.matricula})` },

        // estagiários (value = id)
        { id: 'estagiario-design-melhoria', src: 'estagiariosDesign', valueFn: i => i.id, textFn: i => `${i.nome} (${i.matricula})` },
        { id: 'estagiario-design-aux-melhoria', src: 'estagiariosDesign', valueFn: i => i.id, textFn: i => `${i.nome} (${i.matricula})` },
        { id: 'estagiario-dev-melhoria', src: 'estagiariosAtan', valueFn: i => i.id, textFn: i => `${i.nome} (${i.matricula})` },
        { id: 'estagiario-dev-aux-melhoria', src: 'estagiariosAtan', valueFn: i => i.id, textFn: i => `${i.nome} (${i.matricula})` },

        // precificação (legenda - quant_sprints sprints)
        { id: 'precificacao-dev-melhoria', src: 'precificacoesDev', valueFn: i => i.id, textFn: i => `${i.legenda} - ${i.quant_sprints} sprint${i.quant_sprints > 1 ? 's' : ''}` },
        { id: 'precificacao-design-melhoria', src: 'precificacoesDesign', valueFn: i => i.id, textFn: i => `${i.legenda} - ${i.quant_sprints} sprint${i.quant_sprints > 1 ? 's' : ''}` }
    ];

    // --- Limpeza de formulário ---
    function limparFormulario() {
        if (formEditarDemanda) formEditarDemanda.reset();

        ['tipologia-melhoria', 'numero-gd-melhoria', 'nome-demanda-melhoria']
            .forEach(id => { const el = $(id); if (el) el.textContent = ''; });

        // reset de selects: coloca apenas placeholder
        SELECT_CONFIGS.forEach(cfg => {
            const sel = $(cfg.id);
            if (sel) sel.innerHTML = `<option value="">Selecione</option>`;
        });

        // campos texto/textarea
        ['auditoria-melhoria', 'quantidade-funci-melhoria',
            'quantidade-tempo-melhoria', 'quantidade-frequencia-melhoria',
            'texto-qnt-funci-melhoria', 'texto-freq-melhoria', 'horas-previstas-melhoria',
            'horas-validadas-melhoria'
        ].forEach(id => { const f = $(id); if (f) f.value = ''; });
        
        // Limpar editores Quill
        if (typeof clearQuillEditors === 'function') clearQuillEditors();
        
        // limpar radio buttons de horas-bb
        const radioHorasBb = document.querySelectorAll('input[name="horas-bb-melhoria"]');
        radioHorasBb.forEach(radio => radio.checked = false);

        // limpar radio buttons de projeto
        const radioProjeto = document.querySelectorAll('input[name="projeto-melhoria"]');
        radioProjeto.forEach(radio => radio.checked = false);

        // limpar radio buttons de ferramenta
        const radioFerramenta = document.querySelectorAll('input[name="ferramenta-melhoria"]');
        radioFerramenta.forEach(radio => radio.checked = false);

        // valores calculados
        ['score-valor-melhoria', 'fte-ano-valor-melhoria', 'horas-ano-valor-melhoria', 'score-legenda-melhoria']
            .forEach(id => { const e = $(id); if (e) e.textContent = '--'; });

        // Limpar tags
        if (typeof TagsManager !== 'undefined') TagsManager.limpar();

        // Limpar andamento
        if (typeof AndamentoManager !== 'undefined') AndamentoManager.limpar();

        hideMessageEditar();
    }

    // --- Popular todos selects a partir do objeto data retornado ---
    function popularTodosSelects(data) {
        if (!data) return;
        SELECT_CONFIGS.forEach(cfg => {
            setOptionsByConfig(cfg.id, data[cfg.src], cfg);
        });
    }

    // --- Preencher campos com dados atuais ---
    function preencherCamposComDadosAtuais(data) {
        const demanda = data.demanda || {};

        // Preencher editores Quill
        const editors = typeof getQuillEditors === 'function' ? getQuillEditors() : {};
        if (editors.escopo && demanda.escopo) {
            setQuillContent(editors.escopo, demanda.escopo);
        }
        if (editors.mvp && demanda.mvp) {
            setQuillContent(editors.mvp, demanda.mvp);
        }
        if (editors.pessoasEnvolvidas && demanda.pessoas_envolvidas) {
            setQuillContent(editors.pessoasEnvolvidas, demanda.pessoas_envolvidas);
        }
        
        if ($('auditoria-melhoria') && demanda.auditoria) $('auditoria-melhoria').value = demanda.auditoria;
        
        if (demanda.horas_bb) {
            const radioHorasBb = document.querySelector(`input[name="horas-bb-melhoria"][value="${demanda.horas_bb}"]`);
            if (radioHorasBb) radioHorasBb.checked = true;
        }
        
        if ($('horas-previstas-melhoria') && demanda.horas_previstas) $('horas-previstas-melhoria').value = demanda.horas_previstas;
        if ($('horas-validadas-melhoria') && demanda.horas_validadas) $('horas-validadas-melhoria').value = demanda.horas_validadas;

        if (demanda.projeto) {
            const radioProjeto = document.querySelector(`input[name="projeto-melhoria"][value="${demanda.projeto}"]`);
            if (radioProjeto) radioProjeto.checked = true;
        }

        if (demanda.ferramenta) {
            const radioFerramenta = document.querySelector(`input[name="ferramenta-melhoria"][value="${demanda.ferramenta}"]`);
            if (radioFerramenta) radioFerramenta.checked = true;
        }

        if (demanda.fte) {
            if ($('quantidade-funci-melhoria') && demanda.fte.quantidade_funcionario) $('quantidade-funci-melhoria').value = demanda.fte.quantidade_funcionario;
            if ($('quantidade-tempo-melhoria') && demanda.fte.quantidade_tempo) $('quantidade-tempo-melhoria').value = demanda.fte.quantidade_tempo;
            if ($('quantidade-frequencia-melhoria') && demanda.fte.quantidade_repeticao) $('quantidade-frequencia-melhoria').value = demanda.fte.quantidade_repeticao;
            setSelectValue('tp-tmp-atividade', demanda.fte.unidade_tempo);
            setSelectValue('tp-freq-melhoria', demanda.fte.unidade_repeticao);
            if ($('fte-ano-valor-melhoria') && demanda.fte.fte_ano) $('fte-ano-valor-melhoria').textContent = demanda.fte.fte_ano;
            if ($('horas-ano-valor-melhoria') && demanda.fte.horas_ano) $('horas-ano-valor-melhoria').textContent = demanda.fte.horas_ano;
        }

        if (demanda.guthie) {
            setSelectValue('gravidade-melhoria', demanda.guthie.gravidade, true);
            setSelectValue('urgencia-melhoria', demanda.guthie.urgencia, true);
            setSelectValue('tendencia-melhoria', demanda.guthie.tendencia, true);
            setSelectValue('horas-economia-melhoria', demanda.guthie.horas_economizadas, true);
            setSelectValue('impacto-matriz-melhoria', demanda.guthie.impacto, true);
            setSelectValue('exp-cliente-melhoria', demanda.guthie.experiencia, true);
            if ($('score-valor-melhoria') && demanda.guthie.score) $('score-valor-melhoria').textContent = demanda.guthie.score;
            if ($('score-legenda-melhoria') && demanda.guthie.priorizacao_guthie) $('score-legenda-melhoria').textContent = demanda.guthie.priorizacao_guthie;
        }



        setSelectValue('area-melhoria', demanda.area_id);
        setSelectValue('indicador-melhoria', demanda.vinculo_indicador_id);
        setSelectValue('semestre-melhoria', demanda.semestre);
        setSelectValue('ano-melhoria', demanda.ano);
        setSelectValue('inviabilidade-melhoria', demanda.inviabilidade_id);
        setSelectValue('status-demanda-melhoria', demanda.status_id);

        // responsáveis (funcionários por nome)
        setSelectValue('design-resp-melhoria', demanda.funci_design);
        setSelectValue('design-aux-melhoria', demanda.funci_design_aux);
        setSelectValue('dev-responsavel-melhoria', demanda.funci_atan);
        setSelectValue('dev-aux-melhoria', demanda.funci_atan_aux);

        // estagiários por id
        setSelectValue('estagiario-design-melhoria', demanda.estagiario_design_id);
        setSelectValue('estagiario-design-aux-melhoria', demanda.estagiario_design_aux_id);
        setSelectValue('estagiario-dev-melhoria', demanda.estagiario_atan_id);
        setSelectValue('estagiario-dev-aux-melhoria', demanda.estagiario_atan_aux_id);

        if ($('priorizacao-melhoria') && demanda.priorizacao_comite) $('priorizacao-melhoria').value = demanda.priorizacao_comite;

        // precificação
        if (demanda.precificacao) {
            setSelectValue('precificacao-dev-melhoria', demanda.precificacao.precificacao_dev_id);
            setSelectValue('precificacao-design-melhoria', demanda.precificacao.precificacao_design_id);
        }
    }

    function showMessageEditar(message, type) {
        if (!messageContainerEditar) return;
        const bgColor = type === 'success' ? 'bg-green-100 text-green-700 border-green-300' : 'bg-red-100 text-red-700 border-red-300';
        const icon = type === 'success' ? 'fas fa-check-circle' : 'fas fa-exclamation-circle';
        messageContainerEditar.innerHTML = `<div class="p-3 border rounded-lg ${bgColor}"><i class="${icon} mr-2"></i>${message}</div>`;
        messageContainerEditar.classList.remove('hidden');
    }
    function hideMessageEditar() { if (!messageContainerEditar) return; messageContainerEditar.classList.add('hidden'); messageContainerEditar.innerHTML = ''; }

    /**
     * Verifica se a demanda é do período atual (ano e semestre)
     */
    function ehPeriodoAtual(ano, semestre) {
        const dataAtual = new Date();
        const anoAtual = dataAtual.getFullYear();
        const semestreAtual = dataAtual.getMonth() < 6 ? 1 : 2;
        return parseInt(ano) === anoAtual && parseInt(semestre) === semestreAtual;
    }

    /**
     * Retorna o texto do status selecionado no select
     */
    function getStatusTextoSelecionado() {
        const selectStatus = $('status-demanda-melhoria');
        if (!selectStatus || !selectStatus.selectedIndex) return null;
        return selectStatus.options[selectStatus.selectedIndex]?.text || null;
    }

    /**
     * Verifica se precisa confirmar a alteração de status
     * Retorna true se a demanda não é do período atual e o status é de finalização
     */
    function precisaConfirmarStatus() {
        const statusTexto = getStatusTextoSelecionado();
        // Usar os valores dos campos do formulário, não os valores originais
        const anoSelecionado = $('ano-melhoria')?.value;
        const semestreSelecionado = $('semestre-melhoria')?.value;
        
        if (!anoSelecionado || !semestreSelecionado) return false;
        
        const isPeriodoAtual = ehPeriodoAtual(anoSelecionado, semestreSelecionado);
        return !isPeriodoAtual && STATUS_FINALIZACAO.includes(statusTexto);
    }

    /**
     * Exibe modal de confirmação para alteração de status
     */
    function confirmarAlteracaoStatus() {
        return new Promise((resolve) => {
            const statusTexto = getStatusTextoSelecionado();
            const modalId = 'modal-confirmar-status-melhoria';
            
            // Usar os valores dos campos do formulário para exibir na mensagem
            const anoSelecionado = $('ano-melhoria')?.value;
            const semestreSelecionado = $('semestre-melhoria')?.value;
            
            // Remover modal anterior se existir
            const modalExistente = document.getElementById(modalId);
            if (modalExistente) modalExistente.remove();

            // Criar modal HTML
            const modalHTML = `
                <div id="${modalId}" tabindex="-1" 
                    class="overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 flex justify-center items-center w-full md:inset-0 h-full max-h-full bg-gray-900/50">
                    <div class="relative p-4 w-full max-w-md max-h-full">
                        <div class="relative bg-white rounded-lg shadow-sm">
                            <button type="button" id="btn-fechar-modal-status"
                                class="absolute top-3 end-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center">
                                <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                                </svg>
                                <span class="sr-only">Fechar</span>
                            </button>
                            <div class="p-4 md:p-5 text-center">
                                <svg class="mx-auto mb-4 text-yellow-500 w-12 h-12" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 11V6m0 8h.01M19 10a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                                </svg>
                                <h3 class="mb-2 text-lg font-semibold text-gray-700">Atenção!</h3>
                                <p class="mb-4 text-sm text-gray-500">
                                    Ao alterar o status para <strong>"${statusTexto}"</strong>, esta demanda não aparecerá mais na tabela principal, 
                                    pois pertence a um período anterior <strong>(${semestreSelecionado}S${anoSelecionado})</strong>.
                                </p>
                                <p class="mb-5 text-sm text-gray-500">
                                    A demanda continuará disponível nos relatórios.
                                </p>
                                <button id="btn-confirmar-status" type="button"
                                    class="text-white bg-yellow-500 hover:bg-yellow-600 focus:ring-4 focus:outline-none focus:ring-yellow-300 font-medium rounded-lg text-sm inline-flex items-center px-5 py-2.5 text-center">
                                    Sim, continuar!
                                </button>
                                <button id="btn-cancelar-status" type="button"
                                    class="py-2.5 px-5 ms-3 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100">
                                    Não, cancelar
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            `;

            // Adicionar modal ao DOM
            document.body.insertAdjacentHTML('beforeend', modalHTML);
            const modal = document.getElementById(modalId);

            // Função para fechar e limpar
            const fecharModal = (resultado) => {
                modal.remove();
                resolve(resultado);
            };

            // Event listeners
            document.getElementById('btn-confirmar-status').addEventListener('click', () => fecharModal(true));
            document.getElementById('btn-cancelar-status').addEventListener('click', () => fecharModal(false));
            document.getElementById('btn-fechar-modal-status').addEventListener('click', () => fecharModal(false));
            
            // Fechar ao clicar fora do modal
            modal.addEventListener('click', (e) => {
                if (e.target === modal) fecharModal(false);
            });

            // Fechar com ESC
            const handleEsc = (e) => {
                if (e.key === 'Escape') {
                    document.removeEventListener('keydown', handleEsc);
                    fecharModal(false);
                }
            };
            document.addEventListener('keydown', handleEsc);
        });
    }

    // form submit
    if (formEditarDemanda) {
        formEditarDemanda.addEventListener('submit', async function (e) {
            e.preventDefault();
            if (!demandaEditandoId) { showMessageEditar('Erro: ID da demanda não encontrado', 'error'); return; }

            // Verificar se precisa confirmar alteração de status
            if (precisaConfirmarStatus()) {
                const confirmado = await confirmarAlteracaoStatus();
                if (!confirmado) return;
            }

            if (btnSalvarEdicao) { btnSalvarEdicao.disabled = true; btnSalvarEdicao.innerHTML = '<svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>Salvando...'; }

            try {
                const formData = new FormData(formEditarDemanda);
                const dados = {
                    semestre: formData.get('semestre-melhoria'),
                    ano: formData.get('ano-melhoria'),
                    area: formData.get('area-melhoria'),
                    escopo: formData.get('escopo-melhoria'),
                    mvp: formData.get('mvp-melhoria'),
                    score: $('score-valor-melhoria') ? $('score-valor-melhoria').textContent : null,
                    gravidade: formData.get('gravidade-melhoria'),
                    urgencia: formData.get('urgencia-melhoria'),
                    tendencia: formData.get('tendencia-melhoria'),
                    horas_economizadas: formData.get('horas-economia-melhoria'),
                    impacto: formData.get('impacto-matriz-melhoria'),
                    experiencia: formData.get('exp-cliente-melhoria'),
                    priorizacao_guthie: $('score-legenda-melhoria') ? $('score-legenda-melhoria').textContent : null,
                    priorizacao_comite: formData.get('priorizacao-melhoria'),
                    pessoas_envolvidas: formData.get('pessoas-envolvidas-melhoria'),
                    vinculo_indicador_id: formData.get('indicador-melhoria'),
                    auditoria: formData.get('auditoria-melhoria'),
                    horas_bb: formData.get('horas-bb-melhoria'),
                    horas_previstas: formData.get('horas-previstas-melhoria') ? parseFloat(formData.get('horas-previstas-melhoria')) : null,
                    horas_validadas: formData.get('horas-validadas-melhoria') ? parseFloat(formData.get('horas-validadas-melhoria')) : null,
                    projeto: formData.get('projeto-melhoria'),
                    ferramenta: formData.get('ferramenta-melhoria'),
                    inviabilidade_id: formData.get('inviabilidade-melhoria'),
                    status_id: formData.get('status-demanda-melhoria'),
                    funci_design: formData.get('design-resp-melhoria'),
                    funci_design_aux: formData.get('design-aux-melhoria'),
                    estagiario_design_id: formData.get('estagiario-design-melhoria'),
                    estagiario_design_aux_id: formData.get('estagiario-design-aux-melhoria'),
                    funci_atan: formData.get('dev-responsavel-melhoria'),
                    funci_atan_aux: formData.get('dev-aux-melhoria'),
                    estagiario_atan_id: formData.get('estagiario-dev-melhoria'),
                    estagiario_atan_aux_id: formData.get('estagiario-dev-aux-melhoria'),
                    fte_ano: $('fte-ano-valor-melhoria') ? $('fte-ano-valor-melhoria').textContent : null,
                    horas_ano: $('horas-ano-valor-melhoria') ? $('horas-ano-valor-melhoria').textContent : null,
                    unidade_tempo: formData.get('tp-tmp-atividade'),
                    unidade_repeticao: formData.get('tp-freq-melhoria'),
                    quantidade_tempo: formData.get('quantidade-tempo-melhoria'),
                    quantidade_repeticao: formData.get('quantidade-frequencia-melhoria'),
                    quantidade_funcionario: formData.get('quantidade-funci-melhoria'),
                    precificacao_dev_id: formData.get('precificacao-dev-melhoria'),
                    precificacao_design_id: formData.get('precificacao-design-melhoria'),
                    tags: typeof TagsManager !== 'undefined' ? TagsManager.getTagsSelecionadas() : [],
                };

                // Sincronizar andamentos em paralelo com a edição da demanda
                const [responseResult, andamentoResult] = await Promise.allSettled([
                    fetch(`/demanda/editar-melhoria/${demandaEditandoId}`, {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(dados)
                    }),
                    typeof AndamentoManager !== 'undefined' 
                        ? AndamentoManager.sincronizar() 
                        : Promise.resolve({ success: true })
                ]);

                // Verificar se o fetch principal falhou
                if (responseResult.status === 'rejected') {
                    throw responseResult.reason;
                }

                const response = responseResult.value;
                const result = await response.json();

                if (result.success) {
                    
                    showMessageEditar('Demanda editada com sucesso!', 'success');
                    
                    // Verificar se a demanda deve ser removida da tabela
                    const deveRemoverDaTabela = precisaConfirmarStatus();
                    
                    // atualizar linha da tabela
                    const actionDiv = document.querySelector(`[data-id-demanda="${demandaEditandoId}"]`);
                    if (actionDiv) {
                        const tr = actionDiv.closest('tr');
                        
                        if (deveRemoverDaTabela && tr) {
                            // Remover a linha da tabela usando a API do simple-datatables
                            if (window.dataTable) {
                                // Encontrar o índice da linha no dataTable
                                const rowIndex = Array.from(tr.parentNode.children).indexOf(tr);
                                
                                // Adicionar animação de fade out antes de remover
                                tr.style.transition = 'opacity 0.3s ease-out, background-color 0.3s ease-out';
                                tr.style.backgroundColor = '#fef3c7'; // Amarelo suave para indicar remoção
                                tr.style.opacity = '0';
                                
                                setTimeout(() => {
                                    // Remover a linha usando a API do dataTable
                                    window.dataTable.rows.remove(rowIndex);
                                }, 300);
                            } else {
                                // Fallback: remover diretamente do DOM
                                tr.style.transition = 'opacity 0.3s ease-out';
                                tr.style.opacity = '0';
                                setTimeout(() => tr.remove(), 300);
                            }
                        } else if (tr && tr.cells) {
                            const numeroGdCell = tr.cells[2];
                            const periodoCell = tr.cells[4];
                            const scoreGuthie = tr.cells[5];
                            const prioridadeGuthie = tr.cells[6];
                            const statusCell = tr.cells[7];
                            const funciCell = tr.cells[8];
                            const funciDesignCell = tr.cells[9];

                            if (statusCell) statusCell.innerHTML = result.data?.status_nome || '';
                            if (funciCell) funciCell.innerHTML = result.data?.funci_atan || '';
                            if (funciDesignCell) funciDesignCell.innerHTML = result.data?.funci_design || '';
                            if (scoreGuthie) scoreGuthie.innerHTML = result.data?.score || '';
                            if (prioridadeGuthie && result.data?.prioridade_guthie) prioridadeGuthie.innerHTML = formatarPrioridadeGuthie(result.data.prioridade_guthie);
                            
                            // Atualizar período (Semestre + Ano)
                            if (periodoCell) {
                                const semestre = result.data?.semestre;
                                const ano = result.data?.ano;
                                periodoCell.innerHTML = semestre && ano ? `${semestre}S${ano}` : '-';
                            }
                            
                            // Atualizar número GD com estrela se priorizado
                            if (numeroGdCell && result.data?.numero_gd) {
                                const estrela = result.data?.prioridade_comite?.toLowerCase() === 'sim' 
                                    ? ' <svg class="w-5 h-5 text-yellow-400" style="display: inline; vertical-align: middle; margin-left: 4px; margin-bottom:4px;" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" title="Demanda priorizada"><path d="M13.849 4.22c-.684-1.626-3.014-1.626-3.698 0L8.397 8.387l-4.552.361c-1.775.14-2.495 2.331-1.142 3.477l3.468 2.937-1.06 4.392c-.413 1.713 1.472 3.067 2.992 2.149L12 19.35l3.897 2.354c1.52.918 3.405-.436 2.992-2.15l-1.06-4.39 3.468-2.938c1.353-1.146.633-3.336-1.142-3.477l-4.552-.36-1.754-4.17Z"/></svg>'
                                    : '';
                                numeroGdCell.innerHTML = `<span style="white-space: nowrap;">${result.data.numero_gd}${estrela}</span>`;
                            }
                        }
                    }

                    // Fechar modal após delay 
                    setTimeout(() => {
                        hideMessageEditar();
                        if (modalInstance) modalInstance.hide();
                    }, 500);
                } else {
                    showMessageEditar(result.message, 'error');
                }
            } catch (error) {
                console.error('Erro ao editar demanda:', error);
                showMessageEditar('Erro interno do servidor', 'error');
            } finally {
                if (btnSalvarEdicao) {
                    btnSalvarEdicao.disabled = false;
                    btnSalvarEdicao.innerHTML = '<i class="fas fa-save mr-2"></i>Salvar Alterações';
                }
            }
        });
    }

    // abrir modal (assincronia para await)
    window.editarDemandaMelhoria = async function (id) {
        limparFormulario();
        demandaOriginal = null; // Resetar dados originais
        try {
            demandaEditandoId = id;
            const response = await fetch(`/demanda/editar-melhoria/${id}`);
            const data = await response.json();

            if (!data.success) {
                alert('Erro ao carregar dados da demanda: ' + data.message);
                return;
            }

            // Armazenar dados originais da demanda para verificar mudança de status
            demandaOriginal = {
                ano: data.demanda.ano,
                semestre: data.demanda.semestre,
                status_id: data.demanda.status_id
            };

            // preencher cabeçalho informativo
            if ($('tipologia-melhoria')) $('tipologia-melhoria').textContent = data.demanda.tipologia || '';
            if ($('numero-gd-melhoria')) $('numero-gd-melhoria').textContent = data.demanda.numero_gd || '';
            if ($('nome-demanda-melhoria')) $('nome-demanda-melhoria').textContent = data.demanda.nome || '';

            // popular selects a partir do payload
            popularTodosSelects(data);

            // garantir que DOM atualizou as options antes de setar valores
            await new Promise(resolve => requestAnimationFrame(resolve));

            // setar valores atuais
            preencherCamposComDadosAtuais(data);

            // inicializar cálculos (para as funções globais)
            const dadosMatriz = {
                gravidades: data.gravidades || [],
                urgencia: data.urgencias || [],
                tendencias: data.tendencias || [],
                horas: data.horasEconomizadas || [],
                impactos: data.impactos || [],
                experiencias: data.experiencias || []
            };
            const dadosCalculo = { tempos: data.tempos || [], repeticoes: data.repeticoes || [] };
            const tipScores = data.score || [];

            if (typeof inicializarCalculoScore === 'function') inicializarCalculoScore(dadosMatriz, tipScores);
            if (typeof inicializarCalculoFteHoras === 'function') inicializarCalculoFteHoras(dadosCalculo);

            // Inicializar tags
            if (typeof TagsManager !== 'undefined') {
                const tagsDisponiveis = data.tags || [];
                const tagsSelecionadas = data.demanda.tags || [];
                TagsManager.inicializar(tagsDisponiveis, tagsSelecionadas);
            }

            // Inicializar andamento
            if (typeof AndamentoManager !== 'undefined') {
                const fasesEtapas = data.fasesEtapas || {};
                const andamentosMarcados = data.demanda.andamentos || [];
                const marcados = andamentosMarcados.map(a => a.fase_etapa);
                const progresso = data.demanda.progresso || 0;
                AndamentoManager.inicializar(fasesEtapas, marcados, id, progresso);
            }

            hideMessageEditar();
            if (modalInstance) modalInstance.show(); else if (modalEditarDemanda) modalEditarDemanda.classList.remove('hidden');

        } catch (error) {
            console.error('Erro ao carregar formulário de edição:', error);
            alert('Erro ao carregar formulário de edição');
        }
    };

    // form message helpers de formatação
    function formatarPrioridadeGuthie(prioridade) {
        if (!prioridade || prioridade === 'N/A') return '<span class="px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">N/A</span>';
        let classe = '';
        switch (prioridade) {
            case 'Baixa': classe = 'bg-gray-100 text-gray-800'; break;
            case 'Média': classe = 'bg-blue-100 text-blue-700'; break;
            case 'Alta': classe = 'bg-rose-100 text-rose-700'; break;
            case 'Muito Alta': classe = 'bg-rose-200 text-rose-800'; break;
            default: classe = 'bg-gray-100 text-gray-800';
        }
        return `<span class="px-2 py-1 rounded-full text-xs font-medium ${classe}">${prioridade}</span>`;
    }
    function formatarPrioridadeComite(prioridade) {
        if (!prioridade || prioridade === 'N/A') return '<span class="px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-600 border border-gray-200">N/A</span>';
        const classe = prioridade === 'Sim' ? 'bg-rose-200 text-rose-800 font-bold' : 'bg-gray-100 text-gray-600 border border-gray-200';
        const estrela = prioridade === 'Sim' 
            ? ' <svg class="w-5 h-5 text-yellow-400" style="display: inline; vertical-align: middle; margin-left: 4px; margin-bottom:4px;" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" title="Demanda priorizada"><path d="M13.849 4.22c-.684-1.626-3.014-1.626-3.698 0L8.397 8.387l-4.552.361c-1.775.14-2.495 2.331-1.142 3.477l3.468 2.937-1.06 4.392c-.413 1.713 1.472 3.067 2.992 2.149L12 19.35l3.897 2.354c1.52.918 3.405-.436 2.992-2.15l-1.06-4.39 3.468-2.938c1.353-1.146.633-3.336-1.142-3.477l-4.552-.36-1.754-4.17Z"/></svg>'
            : '';
        return `<span style="white-space: nowrap;"><span class="px-2 py-1 rounded-full text-xs font-medium ${classe}">${prioridade}</span>${estrela}</span>`;
    }

    window.fecharModalEditar = function () {
        if (modalInstance) modalInstance.hide(); else if (modalEditarDemanda) modalEditarDemanda.classList.add('hidden');
        limparFormulario();
    };

    if (modalEditarDemanda) {
        modalEditarDemanda.addEventListener('hidden.bs.modal', limparFormulario);
    }
});