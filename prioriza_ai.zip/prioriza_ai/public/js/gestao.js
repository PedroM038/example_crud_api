/**
 * @file public/js/gestao.js
 * @description Script para gerenciamento das tabelas auxiliares na página de gestão
 * Contém funções para CRUD de áreas, andamentos, estagiários, indicadores, 
 * inviabilidades, status e tags.
 */

// ==================== NAVEGAÇÃO DE TABS ====================

document.addEventListener('DOMContentLoaded', function() {
    // Configura navegação entre tabs
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');

            // Remove classes ativas de todos os botões
            tabButtons.forEach(btn => {
                btn.classList.remove('border-blue-600', 'text-blue-600');
                btn.classList.add('border-transparent');
            });

            // Adiciona classes ativas ao botão clicado
            this.classList.add('border-blue-600', 'text-blue-600');
            this.classList.remove('border-transparent');

            // Esconde todos os conteúdos
            tabContents.forEach(content => {
                content.classList.add('hidden');
                content.classList.remove('block');
            });

            // Mostra o conteúdo da tab selecionada
            const activeContent = document.getElementById(`${tabId}-content`);
            if (activeContent) {
                activeContent.classList.remove('hidden');
                activeContent.classList.add('block');
            }
        });
    });
});

// ==================== UTILITÁRIOS ====================

/**
 * Exibe um toast de notificação
 * @param {string} mensagem - Mensagem a ser exibida
 * @param {string} tipo - Tipo do toast: 'sucesso', 'erro', 'aviso'
 */
function mostrarToast(mensagem, tipo = 'sucesso') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    
    const cores = {
        sucesso: 'bg-green-500',
        erro: 'bg-red-500',
        aviso: 'bg-yellow-500'
    };

    const icones = {
        sucesso: 'fa-check-circle',
        erro: 'fa-times-circle',
        aviso: 'fa-exclamation-circle'
    };

    toast.className = `${cores[tipo]} text-white px-6 py-3 rounded-lg shadow-lg flex items-center gap-3 mb-2 transform transition-all duration-300 translate-x-full`;
    toast.innerHTML = `
        <i class="fas ${icones[tipo]}"></i>
        <span>${mensagem}</span>
    `;

    container.appendChild(toast);

    // Anima entrada
    setTimeout(() => {
        toast.classList.remove('translate-x-full');
    }, 10);

    // Remove após 3 segundos
    setTimeout(() => {
        toast.classList.add('translate-x-full');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

/**
 * Abre um modal
 * @param {string} modalId - ID do modal a ser aberto
 */
function abrirModal(modalId) {
    document.getElementById(modalId).classList.remove('hidden');
}

/**
 * Fecha um modal
 * @param {string} modalId - ID do modal a ser fechado
 */
function fecharModal(modalId) {
    document.getElementById(modalId).classList.add('hidden');
}

/**
 * Mapeia entidade para o nome do campo no backend
 */
function getCampoEntidade(entidade) {
    const mapeamento = {
        'areas': 'area',
        'indicadores': 'indicador',
        'inviabilidades': 'inviabilidade',
        'status': 'status',
        'motivos': 'motivo',
        'tags': 'tag'
    };
    return mapeamento[entidade];
}

// ==================== CRUD SIMPLES (áreas, indicadores, inviabilidades, status, tags) ====================

/**
 * Abre modal para criar novo item simples
 * @param {string} entidade - Nome da entidade (areas, indicadores, etc.)
 * @param {string} label - Label amigável para exibição
 */
function abrirModalCriar(entidade, label) {
    document.getElementById('modal-simples-titulo').textContent = `Nova ${label}`;
    document.getElementById('simples-label').textContent = label;
    document.getElementById('simples-entidade').value = entidade;
    document.getElementById('simples-id').value = '';
    document.getElementById('simples-valor').value = '';
    abrirModal('modal-simples');
}

/**
 * Abre modal para editar item simples
 * @param {string} entidade - Nome da entidade
 * @param {string} label - Label amigável
 * @param {number} id - ID do item
 * @param {string} valor - Valor atual do item
 */
function abrirModalEditar(entidade, label, id, valor) {
    document.getElementById('modal-simples-titulo').textContent = `Editar ${label}`;
    document.getElementById('simples-label').textContent = label;
    document.getElementById('simples-entidade').value = entidade;
    document.getElementById('simples-id').value = id;
    document.getElementById('simples-valor').value = valor;
    abrirModal('modal-simples');
}

/**
 * Salva item simples (criar ou atualizar)
 * @param {Event} event - Evento do formulário
 */
async function salvarSimples(event) {
    event.preventDefault();

    const entidade = document.getElementById('simples-entidade').value;
    const id = document.getElementById('simples-id').value;
    const valor = document.getElementById('simples-valor').value.trim();
    const campo = getCampoEntidade(entidade);

    if (!valor) {
        mostrarToast('Preencha o campo obrigatório', 'erro');
        return;
    }

    const dados = { [campo]: valor };
    const metodo = id ? 'PUT' : 'POST';
    const url = id ? `/gestao/${entidade}/${id}` : `/gestao/${entidade}`;

    try {
        const response = await fetch(url, {
            method: metodo,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(dados)
        });

        const resultado = await response.json();

        if (response.ok) {
            mostrarToast(resultado.mensagem || 'Operação realizada com sucesso', 'sucesso');
            fecharModal('modal-simples');
            // Recarrega a página para atualizar a tabela
            setTimeout(() => location.reload(), 500);
        } else {
            mostrarToast(resultado.erro || 'Erro ao salvar', 'erro');
        }
    } catch (error) {
        console.error('Erro:', error);
        mostrarToast('Erro de conexão', 'erro');
    }
}

// ==================== CRUD ANDAMENTO (Fases/Etapas) ====================

/**
 * Abre modal para criar novo andamento
 */
function abrirModalCriarAndamento() {
    document.getElementById('modal-andamento-titulo').textContent = 'Nova Fase/Etapa';
    document.getElementById('andamento-id').value = '';
    document.getElementById('andamento-etapa').value = '';
    document.getElementById('andamento-fase').value = '';
    document.getElementById('andamento-percentual').value = '';
    abrirModal('modal-andamento');
}

/**
 * Abre modal para editar andamento
 */
function abrirModalEditarAndamento(id, etapa, fase, percentual) {
    document.getElementById('modal-andamento-titulo').textContent = 'Editar Fase/Etapa';
    document.getElementById('andamento-id').value = id;
    document.getElementById('andamento-etapa').value = etapa;
    document.getElementById('andamento-fase').value = fase;
    document.getElementById('andamento-percentual').value = percentual;
    abrirModal('modal-andamento');
}

/**
 * Salva andamento (criar ou atualizar)
 */
async function salvarAndamento(event) {
    event.preventDefault();

    const id = document.getElementById('andamento-id').value;
    const etapa = document.getElementById('andamento-etapa').value.trim();
    const fase = document.getElementById('andamento-fase').value.trim();
    const percentual = document.getElementById('andamento-percentual').value;

    if (!etapa || !fase || percentual === '') {
        mostrarToast('Preencha todos os campos obrigatórios', 'erro');
        return;
    }

    const dados = { etapa, fase, percentual: Number(percentual) };
    const metodo = id ? 'PUT' : 'POST';
    const url = id ? `/gestao/andamentos/${id}` : '/gestao/andamentos';

    try {
        const response = await fetch(url, {
            method: metodo,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(dados)
        });

        const resultado = await response.json();

        if (response.ok) {
            mostrarToast(resultado.mensagem || 'Operação realizada com sucesso', 'sucesso');
            fecharModal('modal-andamento');
            setTimeout(() => location.reload(), 500);
        } else {
            mostrarToast(resultado.erro || 'Erro ao salvar', 'erro');
        }
    } catch (error) {
        console.error('Erro:', error);
        mostrarToast('Erro de conexão', 'erro');
    }
}

// ==================== CRUD ESTAGIÁRIO ====================

/**
 * Abre modal para criar novo estagiário
 */
function abrirModalCriarEstagiario() {
    document.getElementById('modal-estagiario-titulo').textContent = 'Novo Estagiário';
    document.getElementById('estagiario-id').value = '';
    document.getElementById('estagiario-equipe').value = '';
    document.getElementById('estagiario-matricula').value = '';
    document.getElementById('estagiario-nome').value = '';
    abrirModal('modal-estagiario');
}

/**
 * Abre modal para editar estagiário
 */
function abrirModalEditarEstagiario(id, equipe, matricula, nome) {
    document.getElementById('modal-estagiario-titulo').textContent = 'Editar Estagiário';
    document.getElementById('estagiario-id').value = id;
    document.getElementById('estagiario-equipe').value = equipe;
    document.getElementById('estagiario-matricula').value = matricula;
    document.getElementById('estagiario-nome').value = nome;
    abrirModal('modal-estagiario');
}

/**
 * Salva estagiário (criar ou atualizar)
 */
async function salvarEstagiario(event) {
    event.preventDefault();

    const id = document.getElementById('estagiario-id').value;
    const equipe = document.getElementById('estagiario-equipe').value.trim();
    const matricula = document.getElementById('estagiario-matricula').value.trim();
    const nome = document.getElementById('estagiario-nome').value.trim();

    if (!equipe || !matricula || !nome) {
        mostrarToast('Preencha todos os campos obrigatórios', 'erro');
        return;
    }

    const dados = { equipe, matricula, nome };
    const metodo = id ? 'PUT' : 'POST';
    const url = id ? `/gestao/estagiarios/${id}` : '/gestao/estagiarios';

    try {
        const response = await fetch(url, {
            method: metodo,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(dados)
        });

        const resultado = await response.json();

        if (response.ok) {
            mostrarToast(resultado.mensagem || 'Operação realizada com sucesso', 'sucesso');
            fecharModal('modal-estagiario');
            setTimeout(() => location.reload(), 500);
        } else {
            mostrarToast(resultado.erro || 'Erro ao salvar', 'erro');
        }
    } catch (error) {
        console.error('Erro:', error);
        mostrarToast('Erro de conexão', 'erro');
    }
}

// ==================== EXCLUSÃO ====================

/**
 * Abre modal de confirmação de exclusão
 * @param {string} entidade - Nome da entidade
 * @param {string} label - Label amigável
 * @param {number} id - ID do item
 * @param {string} nome - Nome/valor do item para exibir na mensagem
 */
function confirmarExclusao(entidade, label, id, nome) {
    document.getElementById('excluir-entidade').value = entidade;
    document.getElementById('excluir-id').value = id;
    document.getElementById('modal-excluir-mensagem').textContent = 
        `Tem certeza que deseja excluir "${nome}"? Esta ação pode ser revertida posteriormente.`;
    abrirModal('modal-excluir');
}

/**
 * Executa a exclusão do item
 */
async function executarExclusao() {
    const entidade = document.getElementById('excluir-entidade').value;
    const id = document.getElementById('excluir-id').value;

    try {
        const response = await fetch(`/gestao/${entidade}/${id}`, {
            method: 'DELETE'
        });

        const resultado = await response.json();

        if (response.ok) {
            mostrarToast(resultado.message || 'Item excluído com sucesso', 'sucesso');
            fecharModal('modal-excluir');
            
            setTimeout(() => location.reload(), 500);
        } else {
            mostrarToast(resultado.erro || 'Erro ao excluir', 'erro');
        }
    } catch (error) {
        console.error('Erro:', error);
        mostrarToast('Erro de conexão', 'erro');
    }
}

// ==================== RESTAURAÇÃO ====================

/**
 * Restaura um item excluído
 * @param {string} entidade - Nome da entidade
 * @param {number} id - ID do item
 */
async function restaurarItem(entidade, id) {
    try {
        const response = await fetch(`/gestao/${entidade}/${id}/restaurar`, {
            method: 'PATCH'
        });

        const resultado = await response.json();

        if (response.ok) {
            mostrarToast(resultado.message || 'Item restaurado com sucesso', 'sucesso');
            setTimeout(() => location.reload(), 500);
        } else {
            mostrarToast(resultado.erro || 'Erro ao restaurar', 'erro');
        }
    } catch (error) {
        console.error('Erro:', error);
        mostrarToast('Erro de conexão', 'erro');
    }
}
