/**
 * @file public/js/tags.js
 * @description Gerencia a seleção múltipla de tags no modal de edição de melhoria.
 * Permite visualizar tags disponíveis e selecionar/desselecionar tags.
 */

const TagsManager = (function() {
    // Estado interno
    let tagsDisponiveis = [];
    let tagsSelecionadas = [];
    let containerId = 'tags-container-melhoria';
    let hiddenInputId = 'tags-melhoria';

    /**
     * Inicializa o gerenciador de tags
     * @param {Array} disponveis - Array de tags disponíveis [{id, tag}, ...]
     * @param {Array} selecionadas - Array de tags já selecionadas da demanda
     */
    function inicializar(disponiveis, selecionadas = []) {
        tagsDisponiveis = disponiveis || [];
        tagsSelecionadas = selecionadas.map(t => t.tag_id || t.id);
        renderizar();
    }

    /**
     * Renderiza as tags no container
     */
    function renderizar() {
        const container = document.getElementById(containerId);
        if (!container) return;

        container.innerHTML = '';

        if (tagsDisponiveis.length === 0) {
            container.innerHTML = '<span class="text-xs text-gray-500">Nenhuma tag disponível</span>';
            return;
        }

        const fragment = document.createDocumentFragment();

        tagsDisponiveis.forEach(tag => {
            const isSelected = tagsSelecionadas.includes(tag.id);
            const chip = criarChipTag(tag, isSelected);
            fragment.appendChild(chip);
        });

        container.appendChild(fragment);
        atualizarHiddenInput();
    }

    /**
     * Cria um elemento chip para a tag
     * @param {Object} tag - Objeto da tag {id, tag}
     * @param {boolean} isSelected - Se a tag está selecionada
     * @returns {HTMLElement} Elemento do chip
     */
    function criarChipTag(tag, isSelected) {
        const chip = document.createElement('button');
        chip.type = 'button';
        chip.dataset.tagId = tag.id;
        chip.dataset.tagNome = tag.tag;
        
        // Classes base
        const baseClasses = 'inline-flex items-center px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-200 cursor-pointer border mr-2 mb-2';
        
        // Classes para selecionado vs não selecionado
        const selectedClasses = 'bg-indigo-100 text-indigo-800 border-indigo-300 hover:bg-indigo-200';
        const unselectedClasses = 'bg-gray-100 text-gray-600 border-gray-200 hover:bg-gray-200 hover:border-gray-300';
        
        chip.className = `${baseClasses} ${isSelected ? selectedClasses : unselectedClasses}`;
        
        // Ícone de check para selecionados
        const checkIcon = isSelected 
            ? '<svg class="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path></svg>'
            : '';
        
        chip.innerHTML = `${checkIcon}<span>${tag.tag}</span>`;
        
        // Event listener para toggle
        chip.addEventListener('click', () => toggleTag(tag.id));
        
        return chip;
    }

    /**
     * Alterna a seleção de uma tag
     * @param {number} tagId - ID da tag
     */
    function toggleTag(tagId) {
        const index = tagsSelecionadas.indexOf(tagId);
        
        if (index === -1) {
            // Adicionar
            tagsSelecionadas.push(tagId);
        } else {
            // Remover
            tagsSelecionadas.splice(index, 1);
        }
        
        renderizar();
    }

    /**
     * Atualiza o input hidden com os IDs das tags selecionadas
     */
    function atualizarHiddenInput() {
        const hiddenInput = document.getElementById(hiddenInputId);
        if (hiddenInput) {
            hiddenInput.value = JSON.stringify(tagsSelecionadas);
        }
    }

    /**
     * Retorna os IDs das tags selecionadas
     * @returns {Array} Array de IDs
     */
    function getTagsSelecionadas() {
        return [...tagsSelecionadas];
    }

    /**
     * Define as tags selecionadas
     * @param {Array} tags - Array de tags selecionadas
     */
    function setTagsSelecionadas(tags) {
        tagsSelecionadas = tags.map(t => t.tag_id || t.id || t);
        renderizar();
    }

    /**
     * Limpa todas as seleções
     */
    function limpar() {
        tagsSelecionadas = [];
        tagsDisponiveis = [];
        const container = document.getElementById(containerId);
        if (container) container.innerHTML = '';
        atualizarHiddenInput();
    }

    /**
     * Retorna as tags disponíveis
     * @returns {Array} Array de tags disponíveis
     */
    function getTagsDisponiveis() {
        return [...tagsDisponiveis];
    }

    // API pública
    return {
        inicializar,
        renderizar,
        toggleTag,
        getTagsSelecionadas,
        setTagsSelecionadas,
        limpar,
        getTagsDisponiveis
    };
})();

// Expor globalmente para integração
window.TagsManager = TagsManager;
