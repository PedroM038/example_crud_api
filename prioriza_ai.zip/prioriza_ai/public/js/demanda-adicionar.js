/**
 * @file public/js/demanda-adicionar.js
 * @description Camada front de JavaScript referente à rota de 
 * adicionar demanda. Basicamente, aqui você deve encontrar validações
 * dos campos do modal de adicionar demanda e o envio de dados para o back-end.
 */

document.addEventListener('DOMContentLoaded', function () {

    // Elementos do DOM
    const btnAdicionarDemanda = document.getElementById('button-adicionar-demanda');
    const formNovaDemanda = document.getElementById('form-nova-demanda');
    const messageContainer = document.getElementById('message-container');
    const btnSalvar = document.getElementById('btn-salvar');
    const numeroGdInput = formNovaDemanda.querySelector('input[name="numeroGd"]');
    const modal = document.querySelector('[data-modal-target="crud-modal"]')?.closest('.modal') ||
        document.querySelector('#crud-modal') ||
        formNovaDemanda.closest('.modal');
    const selectTipologia = formNovaDemanda.querySelector('select[name="tipologia"]');

    // Variável para controlar se está processando
    let isProcessing = false;

    // Função para validar formato do número GD
    function validarNumeroGd(numeroGd) {
        const regex = /^DEMN\d{7}$/;
        return regex.test(numeroGd);
    }

    // Adicionar placeholder para orientar o usuário
    if (numeroGdInput) {
        numeroGdInput.placeholder = 'DEMN0000000';
    }

    function fecharModal() {
        if (modal) {
            modal.classList.add('hidden');
            formNovaDemanda.reset();
            hideMessage();
            isProcessing = false;
            // Limpa tipologias ao fechar (opcional)
            if (selectTipologia) {
                selectTipologia.innerHTML = '<option value="">Selecione...</option>';
            }
        }
    }

    // Event listener para teclas rápidas
    document.addEventListener('keydown', function (e) {
        // Verificar se o modal está visível
        const modalVisivel = modal && !modal.classList.contains('hidden');

        if (modalVisivel) {
            switch (e.key) {
                case 'Enter':
                    e.preventDefault();
                    if (!isProcessing) {
                        submitForm();
                    }
                    break;
                case 'Escape':
                    e.preventDefault();
                    fecharModal();
                    break;
            }
        }
    });

    // Prevenção de duplo clique no botão salvar
    btnSalvar.addEventListener('click', function (e) {
        if (isProcessing) {
            e.preventDefault();
            return false;
        }
    });

    // Função para processar o submit
    async function submitForm() {
        if (isProcessing) return;

        isProcessing = true;

        // Desabilitar botão durante o envio
        btnSalvar.disabled = true;
        btnSalvar.innerHTML = '<svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>Salvando...';

        const tipologiaSelecionada = selectTipologia.value;
        if (!tipologiaSelecionada) {
            showMessage('Selecione uma Tipologia.', 'error');
            resetButton();
            return;
        }

        // Validar formato do número GD
        const numeroGd = formNovaDemanda.querySelector('input[name="numeroGd"]').value;
        if (!validarNumeroGd(numeroGd)) {
            showMessage('Número GD deve estar no formato DEMN0000000 (DEMN seguido de 7 dígitos).', 'error');
            resetButton();
            return;
        }

        try {
            // Coletar dados do formulário
            const formData = new FormData(formNovaDemanda);
            // pega ano atual
            ano = new Date().getFullYear();
            //pega semestre atual
            const semestre = Math.ceil((new Date().getMonth() + 1) / 6);
           
            // Formata os dados para enviar
            const dados = {
                tipologia: tipologiaSelecionada,
                numeroGd: formData.get('numeroGd'),
                nomeDemanda: formData.get('nomeDemanda'),
                ano: ano,
                semestre: semestre
            };

            // Enviar dados
            const response = await fetch('/demanda/inserir', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(dados)
            });

            const result = await response.json();

            if (result.success) {
                showMessage(result.message, 'success');
                setTimeout(() => {
                    window.location.reload();
                }, 200);
            } else {
                showMessage(result.message, 'error');
                resetButton();
            }

        } catch (error) {
            console.error('Erro ao inserir demanda:', error);
            showMessage('Erro interno do servidor', 'error');
            resetButton();
        }
    }

    // Função para resetar o botão
    function resetButton() {
        isProcessing = false;
        btnSalvar.disabled = false;
        btnSalvar.innerHTML = '<svg class="me-1 -ms-1 w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clip-rule="evenodd"></path></svg>Adicionar Demanda';
    }

    // Event listener para abrir o modal de nova demanda
    btnAdicionarDemanda.addEventListener('click', async function () {
        try {
            hideMessage();
            formNovaDemanda.reset();

            // Carrega tipologias
            const response = await fetch('/demanda/nova');
            const data = await response.json();

            if (data.success && Array.isArray(data.tipologias)) {
                selectTipologia.innerHTML = '<option value="">Selecione...</option>';
                data.tipologias.forEach(t => {
                    const opt = document.createElement('option');
                    opt.value = t;
                    opt.textContent = t;
                    selectTipologia.appendChild(opt);
                });
                isProcessing = false;
            } else {
                showMessage('Erro ao carregar tipologias.', 'error');
            }
        } catch (e) {
            console.error('Erro ao carregar formulário:', e);
            showMessage('Erro ao carregar formulário', 'error');
        }
    });

    // Event listener para submit do formulário de nova demanda
    formNovaDemanda.addEventListener('submit', async function (e) {
        e.preventDefault();
        await submitForm();
    });

    // Função para mostrar mensagens no modal principal
    function showMessage(message, type) {
        const bgColor = type === 'success' ? 'bg-green-100 text-green-700 border-green-300' : 'bg-red-100 text-red-700 border-red-300';
        const icon = type === 'success' ? 'fas fa-check-circle' : 'fas fa-exclamation-circle';

        messageContainer.innerHTML = `
            <div class="p-3 border rounded-lg ${bgColor}">
                <i class="${icon} mr-2"></i>
                ${message}
            </div>
        `;
        messageContainer.classList.remove('hidden');
    }

    // Função para esconder mensagens do modal principal
    function hideMessage() {
        messageContainer.classList.add('hidden');
        messageContainer.innerHTML = '';
    }
});