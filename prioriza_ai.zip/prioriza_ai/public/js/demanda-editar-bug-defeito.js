/**
 * @file public/js/demanda-editar-bug-defeito.js
 * @description Script para gerenciar o modal de edição de demandas Bug/Defeito.
 * Inclui navegação por steps, gerenciamento de ferramentas via API CESUP em paralelo,
 * e processamento de dados de forma assíncrona.
 * @author Pedro e Rafaela
 */
document.addEventListener('DOMContentLoaded', function () {

    // ==================== Elementos do DOM ====================
    const modalEditarDemanda = document.getElementById('modal-editar-demanda-bug-defeito');
    const formEditarDemanda = document.getElementById('form-editar-demanda-bug-defeito');
    const messageContainerEditar = document.getElementById('message-container-editar-bug-defeito');
    const btnSalvarEdicao = document.getElementById('btn-salvar-edicao-bug-defeito');
    
    // ==================== Estado do Componente ====================
    let demandaEditandoId = null;
    let demandaOriginal = null;
    let modalInstance = null;
    let ferramentasCache = []; // Cache local das ferramentas da API

    // Status que removem a demanda da tabela principal
    const STATUS_FINALIZACAO = ['Entregue', 'Cancelado'];

    // ==================== Inicialização do Modal ====================
    if (modalEditarDemanda && typeof Modal !== 'undefined') {
        modalInstance = new Modal(modalEditarDemanda, {
            placement: 'center',
            backdrop: 'dynamic',
            backdropClasses: 'bg-gray-900/50 dark:bg-gray-900/80 fixed inset-0 z-40',
            closable: true
        });
    }

    // ==================== Gerenciador de Ferramentas ====================
    const FerramentaManager = {
        /**
         * Busca todas as ferramentas da API CESUP
         */
        async carregarFerramentas() {
            try {
                const response = await fetch('/api/ferramentas');
                const result = await response.json();
                
                if (result.success) {
                    ferramentasCache = result.data;
                    return result.data;
                }
                throw new Error(result.message || 'Erro ao carregar ferramentas');
            } catch (error) {
                console.error('Erro ao carregar ferramentas:', error);
                throw error;
            }
        },

        /**
         * Busca detalhes de uma ferramenta específica por ID
         */
        async buscarDetalhes(id) {
            if (!id) return null;
            
            // Primeiro tenta buscar do cache
            let ferramenta = ferramentasCache.find(f => f.id === parseInt(id));
            
            // Se não encontrar no cache, busca da API
            if (!ferramenta) {
                try {
                    const response = await fetch(`/api/ferramentas/${id}`);
                    const result = await response.json();
                    if (result.success) {
                        ferramenta = result.data;
                    }
                } catch (error) {
                    console.error('Erro ao buscar detalhes da ferramenta:', error);
                }
            }
            
            return ferramenta;
        },

        /**
         * Popula o select de ferramentas
         */
        popularSelect(ferramentas) {
            const select = document.getElementById('ferramenta-bug-defeito');
            if (!select) return;

            select.innerHTML = '<option value="">Selecione uma ferramenta</option>';
            
            if (Array.isArray(ferramentas)) {
                ferramentas.forEach(f => {
                    const option = document.createElement('option');
                    option.value = f.id;
                    option.textContent = f.ferramenta;
                    select.appendChild(option);
                });
            }
        },

        /**
         * Exibe os detalhes da ferramenta selecionada
         */
        exibirDetalhes(ferramenta) {
            const detalhesContainer = document.getElementById('ferramenta-detalhes');
            const placeholder = document.getElementById('ferramenta-placeholder');
            const loadingEl = document.getElementById('ferramenta-loading');
            const erroEl = document.getElementById('ferramenta-erro');

            // Esconde loading e erro
            if (loadingEl) loadingEl.classList.add('hidden');
            if (erroEl) erroEl.classList.add('hidden');

            if (!ferramenta) {
                if (detalhesContainer) detalhesContainer.classList.add('hidden');
                if (placeholder) placeholder.classList.remove('hidden');
                return;
            }

            // Preenche os campos
            const setTexto = (id, valor) => {
                const el = document.getElementById(id);
                if (el) el.textContent = valor || '-';
            };

            const setLink = (id, url) => {
                const el = document.getElementById(id);
                if (el) {
                    if (url) {
                        el.href = url;
                        el.textContent = url;
                        el.classList.remove('text-gray-400');
                    } else {
                        el.href = '#';
                        el.textContent = 'Não disponível';
                        el.classList.add('text-gray-400');
                    }
                }
            };

            setTexto('ferramenta-nome', ferramenta.ferramenta);
            setTexto('ferramenta-linguagem', ferramenta.linguagem);
            setTexto('ferramenta-dev-responsavel', ferramenta.devResponsavel);
            setTexto('ferramenta-servidor', ferramenta.servidorHospedagem);
            setLink('ferramenta-url', ferramenta.urlAplicacao);
            setLink('ferramenta-repositorio', ferramenta.urlRepositorio);

            // Mostra detalhes, esconde placeholder
            if (detalhesContainer) detalhesContainer.classList.remove('hidden');
            if (placeholder) placeholder.classList.add('hidden');
        },

        /**
         * Mostra estado de carregamento
         */
        mostrarLoading() {
            const loadingEl = document.getElementById('ferramenta-loading');
            const detalhesContainer = document.getElementById('ferramenta-detalhes');
            const placeholder = document.getElementById('ferramenta-placeholder');
            const erroEl = document.getElementById('ferramenta-erro');

            if (loadingEl) loadingEl.classList.remove('hidden');
            if (detalhesContainer) detalhesContainer.classList.add('hidden');
            if (placeholder) placeholder.classList.add('hidden');
            if (erroEl) erroEl.classList.add('hidden');
        },

        /**
         * Mostra estado de erro
         */
        mostrarErro(mensagem) {
            const loadingEl = document.getElementById('ferramenta-loading');
            const detalhesContainer = document.getElementById('ferramenta-detalhes');
            const placeholder = document.getElementById('ferramenta-placeholder');
            const erroEl = document.getElementById('ferramenta-erro');
            const erroMsg = document.getElementById('ferramenta-erro-msg');

            if (loadingEl) loadingEl.classList.add('hidden');
            if (detalhesContainer) detalhesContainer.classList.add('hidden');
            if (placeholder) placeholder.classList.add('hidden');
            if (erroEl) erroEl.classList.remove('hidden');
            if (erroMsg) erroMsg.textContent = mensagem;
        }
    };

    // ==================== Event Listener para Seleção de Ferramenta ====================
    const selectFerramenta = document.getElementById('ferramenta-bug-defeito');
    if (selectFerramenta) {
        selectFerramenta.addEventListener('change', async function() {
            const ferramentaId = this.value;
            
            if (!ferramentaId) {
                FerramentaManager.exibirDetalhes(null);
                return;
            }

            FerramentaManager.mostrarLoading();
            
            try {
                const ferramenta = await FerramentaManager.buscarDetalhes(ferramentaId);
                FerramentaManager.exibirDetalhes(ferramenta);
            } catch (error) {
                FerramentaManager.mostrarErro('Erro ao carregar detalhes da ferramenta');
            }
        });
    }

    // ==================== Helpers ====================
    function limparFormulario() {
        if (formEditarDemanda) {
            formEditarDemanda.reset();
        }
        
        // Limpar campos de exibição
        ['display-tipologia-bug-defeito', 'display-numero-gd-bug-defeito', 
         'display-nome-bug-defeito', 'display-score-bug-defeito'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.textContent = '';
        });

        // Limpar checkboxes de motivos
        const motivosCheckboxes = document.querySelectorAll('input[name="motivos-bug-defeito"]');
        motivosCheckboxes.forEach(cb => cb.checked = false);

        // Resetar detalhes da ferramenta
        FerramentaManager.exibirDetalhes(null);
        
        // Resetar step para o primeiro
        if (typeof window.resetStepBugDefeito === 'function') {
            window.resetStepBugDefeito();
        }

        hideMessageEditar();
    }

    function ehPeriodoAtual(ano, semestre) {
        const dataAtual = new Date();
        const anoAtual = dataAtual.getFullYear();
        const semestreAtual = dataAtual.getMonth() < 6 ? 1 : 2;
        return parseInt(ano) === anoAtual && parseInt(semestre) === semestreAtual;
    }

    function getStatusTextoSelecionado() {
        const selectStatus = document.getElementById('status-bug-defeito');
        if (!selectStatus || !selectStatus.selectedIndex) return null;
        return selectStatus.options[selectStatus.selectedIndex]?.text || null;
    }

    function precisaConfirmarStatus() {
        const statusTexto = getStatusTextoSelecionado();
        // Usar os valores dos campos do formulário, não os valores originais
        const anoSelecionado = document.getElementById('ano-bug-defeito')?.value;
        const semestreSelecionado = document.getElementById('semestre-bug-defeito')?.value;
        
        if (!anoSelecionado || !semestreSelecionado) return false;
        
        const isPeriodoAtual = ehPeriodoAtual(anoSelecionado, semestreSelecionado);
        return !isPeriodoAtual && STATUS_FINALIZACAO.includes(statusTexto);
    }

    function confirmarAlteracaoStatus() {
        return new Promise((resolve) => {
            const statusTexto = getStatusTextoSelecionado();
            const modalId = 'modal-confirmar-status-bug-defeito';
            
            // Usar os valores dos campos do formulário para exibir na mensagem
            const anoSelecionado = document.getElementById('ano-bug-defeito')?.value;
            const semestreSelecionado = document.getElementById('semestre-bug-defeito')?.value;
            
            const modalExistente = document.getElementById(modalId);
            if (modalExistente) modalExistente.remove();

            const modalHTML = `
                <div id="${modalId}" tabindex="-1" 
                    class="overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 flex justify-center items-center w-full md:inset-0 h-full max-h-full bg-gray-900/50">
                    <div class="relative p-4 w-full max-w-md max-h-full">
                        <div class="relative bg-white rounded-lg shadow-sm">
                            <button type="button" id="btn-fechar-modal-status"
                                class="absolute top-3 end-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center">
                                <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                                </svg>
                                <span class="sr-only">Fechar</span>
                            </button>
                            <div class="p-4 md:p-5 text-center">
                                <svg class="mx-auto mb-4 text-yellow-500 w-12 h-12" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 11V6m0 8h.01M19 10a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                                </svg>
                                <h3 class="mb-2 text-lg font-semibold text-gray-700">Atenção!</h3>
                                <p class="mb-4 text-sm text-gray-500">
                                    Ao alterar o status para <strong>"${statusTexto}"</strong>, esta demanda não aparecerá mais na tabela principal, 
                                    pois pertence a um período anterior <strong>(${semestreSelecionado}S${anoSelecionado})</strong>.
                                </p>
                                <p class="mb-5 text-sm text-gray-500">
                                    A demanda continuará disponível nos relatórios.
                                </p>
                                <button id="btn-confirmar-status" type="button"
                                    class="text-white bg-yellow-500 hover:bg-yellow-600 focus:ring-4 focus:outline-none focus:ring-yellow-300 font-medium rounded-lg text-sm inline-flex items-center px-5 py-2.5 text-center">
                                    Sim, continuar!
                                </button>
                                <button id="btn-cancelar-status" type="button"
                                    class="py-2.5 px-5 ms-3 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100">
                                    Não, cancelar
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            `;

            document.body.insertAdjacentHTML('beforeend', modalHTML);
            const modal = document.getElementById(modalId);

            const fecharModal = (resultado) => {
                modal.remove();
                resolve(resultado);
            };

            document.getElementById('btn-confirmar-status').addEventListener('click', () => fecharModal(true));
            document.getElementById('btn-cancelar-status').addEventListener('click', () => fecharModal(false));
            document.getElementById('btn-fechar-modal-status').addEventListener('click', () => fecharModal(false));
            
            modal.addEventListener('click', (e) => {
                if (e.target === modal) fecharModal(false);
            });

            const handleEsc = (e) => {
                if (e.key === 'Escape') {
                    document.removeEventListener('keydown', handleEsc);
                    fecharModal(false);
                }
            };
            document.addEventListener('keydown', handleEsc);
        });
    }

    function showMessageEditar(message, type) {
        if (!messageContainerEditar) return;

        const bgColor = type === 'success' 
            ? 'bg-green-100 text-green-700 border-green-300' 
            : 'bg-red-100 text-red-700 border-red-300';
        const icon = type === 'success' ? 'fas fa-check-circle' : 'fas fa-exclamation-circle';

        messageContainerEditar.innerHTML = `
            <div class="p-3 border rounded-lg ${bgColor}">
                <i class="${icon} mr-2"></i>${message}
            </div>
        `;
        messageContainerEditar.classList.remove('hidden');
    }

    function hideMessageEditar() {
        if (!messageContainerEditar) return;
        messageContainerEditar.classList.add('hidden');
        messageContainerEditar.innerHTML = '';
    }

    // ==================== Popular Selects ====================
    function popularSelectsComDados(data) {
        // Popular checkboxes de motivos
        const containerMotivos = document.getElementById('motivos-checkbox-container-bug-defeito');
        if (containerMotivos && data.motivos) {
            containerMotivos.innerHTML = '';
            
            if (data.motivos.length === 0) {
                containerMotivos.innerHTML = '<p class="text-sm text-gray-400 italic">Nenhum motivo disponível</p>';
            } else {
                data.motivos.forEach(motivo => {
                    const checkboxDiv = document.createElement('div');
                    checkboxDiv.className = 'flex items-center';
                    checkboxDiv.innerHTML = `
                        <input type="checkbox" 
                            id="motivo-checkbox-${motivo.id}" 
                            name="motivos-bug-defeito" 
                            value="${motivo.id}"
                            class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 focus:ring-2">
                        <label for="motivo-checkbox-${motivo.id}" class="ms-2 text-sm font-medium text-gray-900">
                            ${motivo.motivo}
                        </label>
                    `;
                    containerMotivos.appendChild(checkboxDiv);
                });
            }
        }

        // Popular select de status
        const selectStatus = document.getElementById('status-bug-defeito');
        if (selectStatus && data.status) {
            selectStatus.innerHTML = '<option value="">Selecione o status</option>';
            data.status.forEach(status => {
                const option = document.createElement('option');
                option.value = status.id;
                option.textContent = status.status;
                selectStatus.appendChild(option);
            });
        }

        // Popular select de funcionários
        const selectFuncionario = document.getElementById('funcionarioAtan-bug-defeito');
        if (selectFuncionario && data.funcionarios) {
            selectFuncionario.innerHTML = '<option value="">Selecione o funcionário</option>';
            data.funcionarios.forEach(funcionario => {
                const option = document.createElement('option');
                option.value = funcionario.nome;
                option.textContent = `${funcionario.nome} (${funcionario.matricula})`;
                selectFuncionario.appendChild(option);
            });
        }

        // Popular select de estagiários
        const selectEstagiario = document.getElementById('estagiario-bug-defeito');
        if (selectEstagiario && data.estagiarios) {
            selectEstagiario.innerHTML = '<option value="">Selecione o estagiário</option>';
            data.estagiarios.forEach(estagiario => {
                const option = document.createElement('option');
                option.value = estagiario.id;
                option.textContent = `${estagiario.nome} (${estagiario.matricula})`;
                selectEstagiario.appendChild(option);
            });
        }

        // Popular select de estagiários auxiliares
        const selectEstagiarioAux = document.getElementById('estagiarioAux-bug-defeito');
        if (selectEstagiarioAux && data.estagiarios) {
            selectEstagiarioAux.innerHTML = '<option value="">Selecione o estagiário auxiliar</option>';
            data.estagiarios.forEach(estagiario => {
                const option = document.createElement('option');
                option.value = estagiario.id;
                option.textContent = `${estagiario.nome} (${estagiario.matricula})`;
                selectEstagiarioAux.appendChild(option);
            });
        }

        // Popular select de precificação Dev
        const selectPrecificacaoDev = document.getElementById('precificacao-dev-bug-defeito');
        if (selectPrecificacaoDev && data.precificacoesDev) {
            selectPrecificacaoDev.innerHTML = '<option value="">Selecione</option>';
            data.precificacoesDev.forEach(prec => {
                const option = document.createElement('option');
                option.value = prec.id;
                option.textContent = `${prec.legenda} - ${prec.quant_sprints} sprint${prec.quant_sprints > 1 ? 's' : ''}`;
                selectPrecificacaoDev.appendChild(option);
            });
        }
    }

    // ==================== Preencher Campos ====================
    function preencherCamposComDadosAtuais(data) {
        const demanda = data.demanda;
        if (!demanda) return;

        // Campos de exibição (header e step 1)
        const displayFields = [
            { id: 'info-tipologia-bug-defeito', value: demanda.tipologia },
            { id: 'info-numero-gd-bug-defeito', value: demanda.numero_gd },
            { id: 'info-nome-demanda-bug-defeito', value: demanda.nome },
            { id: 'display-tipologia-bug-defeito', value: demanda.tipologia },
            { id: 'display-numero-gd-bug-defeito', value: demanda.numero_gd },
            { id: 'display-nome-bug-defeito', value: demanda.nome },
            { id: 'display-score-bug-defeito', value: `${demanda.score} - ${demanda.prioridade_guthie}` }
        ];

        displayFields.forEach(({ id, value }) => {
            const el = document.getElementById(id);
            if (el) el.textContent = value || '';
        });

        // Selects simples por valor
        const selectSemestre = document.getElementById('semestre-bug-defeito');
        if (selectSemestre && demanda.semestre) {
            selectSemestre.value = demanda.semestre;
        }

        const selectAno = document.getElementById('ano-bug-defeito');
        if (selectAno && demanda.ano) {
            selectAno.value = demanda.ano;
        }

        // Ferramenta - selecionar por ID
        const selectFerramentaEl = document.getElementById('ferramenta-bug-defeito');
        if (selectFerramentaEl && demanda.ferramenta_id) {
            selectFerramentaEl.value = demanda.ferramenta_id;
            // Disparar change para carregar detalhes
            selectFerramentaEl.dispatchEvent(new Event('change'));
        }
        
        // Motivos - marcar checkboxes (novo formato N:N)
        if (demanda.motivos_ids && Array.isArray(demanda.motivos_ids)) {
            demanda.motivos_ids.forEach(motivoId => {
                const checkbox = document.getElementById(`motivo-checkbox-${motivoId}`);
                if (checkbox) {
                    checkbox.checked = true;
                }
            });
        }
        
        // Status
        const selectStatus = document.getElementById('status-bug-defeito');
        if (selectStatus && demanda.status_id) {
            selectStatus.value = demanda.status_id;
        }

        // Funcionário ATAN
        const selectFuncionario = document.getElementById('funcionarioAtan-bug-defeito');
        if (selectFuncionario && demanda.funci_atan) {
            selectFuncionario.value = demanda.funci_atan;
        }

        // Estagiário
        const selectEstagiario = document.getElementById('estagiario-bug-defeito');
        if (selectEstagiario && demanda.estagiario_atan) {
            selectEstagiario.value = demanda.estagiario_atan;
        }

        // Estagiário Auxiliar
        const selectEstagiarioAux = document.getElementById('estagiarioAux-bug-defeito');
        if (selectEstagiarioAux && demanda.estagiario_aux_atan) {
            selectEstagiarioAux.value = demanda.estagiario_aux_atan;
        }

        // Precificação Dev
        const selectPrecificacaoDev = document.getElementById('precificacao-dev-bug-defeito');
        if (selectPrecificacaoDev && demanda.precificacao?.precificacao_dev_id) {
            selectPrecificacaoDev.value = demanda.precificacao.precificacao_dev_id;
        }
    }

    // ==================== Submit do Formulário ====================
    if (formEditarDemanda) {
        formEditarDemanda.addEventListener('submit', async function (e) {
            e.preventDefault();

            if (!demandaEditandoId) {
                showMessageEditar('Erro: ID da demanda não encontrado', 'error');
                return;
            }

            // Verificar se precisa confirmar alteração de status
            if (precisaConfirmarStatus()) {
                const confirmado = await confirmarAlteracaoStatus();
                if (!confirmado) return;
            }

            // Desabilitar botão durante o envio
            if (btnSalvarEdicao) {
                btnSalvarEdicao.disabled = true;
                btnSalvarEdicao.innerHTML = '<svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white inline" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>Salvando...';
            }

            try {
                // Coletar dados do formulário
                const formData = new FormData(formEditarDemanda);
                
                // Coletar motivos selecionados (checkboxes)
                const motivosCheckboxes = document.querySelectorAll('input[name="motivos-bug-defeito"]:checked');
                const motivosIds = Array.from(motivosCheckboxes).map(cb => cb.value);
                
                // Obter o nome da ferramenta selecionada
                const ferramentaSelect = document.getElementById('ferramenta-bug-defeito');
                const ferramentaNome = ferramentaSelect?.selectedOptions[0]?.text || null;
                
                const dados = {
                    semestre: formData.get('semestre-bug-defeito'),
                    ano: formData.get('ano-bug-defeito'),
                    ferramenta: formData.get('ferramenta-bug-defeito'),
                    ferramenta_nome: ferramentaNome !== 'Selecione uma ferramenta' ? ferramentaNome : null,
                    motivos_ids: motivosIds, // Novo: array de IDs de motivos
                    status: formData.get('status-bug-defeito'),
                    funci_atan: formData.get('funcionarioAtan-bug-defeito'),
                    estagiario_atan: formData.get('estagiario-bug-defeito'),
                    estagiario_atan_aux: formData.get('estagiarioAux-bug-defeito'),
                    precificacao_dev_id: formData.get('precificacao-dev-bug-defeito')
                };

                // Enviar dados
                const response = await fetch(`/demanda/editar-bug-defeito/${demandaEditandoId}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(dados)
                });

                const result = await response.json();

                if (result.success) {
                    showMessageEditar(result.message, 'success');
                    
                    // Verificar se a demanda deve ser removida da tabela
                    const deveRemoverDaTabela = precisaConfirmarStatus();
                    
                    // Atualizar somente a linha da tabela correspondente
                    const actionDiv = document.querySelector(`[data-id-demanda="${demandaEditandoId}"]`);
                    if (actionDiv) {
                        const tr = actionDiv.closest('tr');
                        
                        if (deveRemoverDaTabela && tr) {
                            // Remover a linha da tabela usando a API do simple-datatables
                            if (window.dataTable) {
                                // Encontrar o índice da linha no dataTable
                                const rowIndex = Array.from(tr.parentNode.children).indexOf(tr);
                                
                                // Adicionar animação de fade out antes de remover
                                tr.style.transition = 'opacity 0.3s ease-out, background-color 0.3s ease-out';
                                tr.style.backgroundColor = '#fef3c7'; // Amarelo suave para indicar remoção
                                tr.style.opacity = '0';
                                
                                setTimeout(() => {
                                    // Remover a linha usando a API do dataTable
                                    window.dataTable.rows.remove(rowIndex);
                                }, 300);
                            } else {
                                // Fallback: remover diretamente do DOM
                                tr.style.transition = 'opacity 0.3s ease-out';
                                tr.style.opacity = '0';
                                setTimeout(() => tr.remove(), 300);
                            }
                        } else if (tr && tr.cells) {
                            // Apenas atualizar os dados da linha
                            const periodoCell = tr.cells[4];
                            const statusCell = tr.cells[7];
                            const funciCell = tr.cells[8];
                            
                            if (periodoCell) {
                                const semestre = result.data?.semestre;
                                const ano = result.data?.ano;
                                periodoCell.innerHTML = semestre && ano ? `${semestre}S${ano}` : '-';
                            }
                            if (statusCell) statusCell.innerHTML = result.data?.status_nome || '';
                            if (funciCell) funciCell.innerHTML = result.data?.funci_atan || '';
                        }
                    }

                    // Fechar modal após delay
                    setTimeout(() => {
                        hideMessageEditar();
                        if (modalInstance) modalInstance.hide();
                    }, 500);
                } else {
                    showMessageEditar(result.message, 'error');
                }

            } catch (error) {
                console.error('Erro ao editar demanda:', error);
                showMessageEditar('Erro interno do servidor', 'error');
            } finally {
                if (btnSalvarEdicao) {
                    btnSalvarEdicao.disabled = false;
                    btnSalvarEdicao.innerHTML = '<i class="fas fa-save mr-2"></i>Salvar Alterações';
                }
            }
        });
    }

    // ==================== Função Global para Abrir Modal ====================
    window.editarDemanda = async function (id) {
        limparFormulario();
        demandaOriginal = null;
        
        try {
            demandaEditandoId = id;

            // Carregar dados da demanda e ferramentas em paralelo
            const [demandaResponse, ferramentasResult] = await Promise.all([
                fetch(`/demanda/editar-bug-defeito/${id}`).then(r => r.json()),
                FerramentaManager.carregarFerramentas().catch(err => {
                    console.warn('Erro ao carregar ferramentas:', err);
                    return [];
                })
            ]);

            if (!demandaResponse.success) {
                alert('Erro ao carregar dados da demanda: ' + demandaResponse.message);
                return;
            }

            const data = demandaResponse;

            // Armazenar dados originais
            demandaOriginal = {
                ano: data.demanda.ano,
                semestre: data.demanda.semestre,
                status_id: data.demanda.status_id
            };

            // Popular selects (ferramentas vem do cache/API separado)
            FerramentaManager.popularSelect(ferramentasResult);
            popularSelectsComDados(data);

            // Aguardar um pouco para garantir que os selects foram populados
            await new Promise(resolve => setTimeout(resolve, 50));

            // Preencher campos com dados atuais
            preencherCamposComDadosAtuais(data);

            // Limpar mensagens e resetar step
            hideMessageEditar();
            if (typeof window.resetStepBugDefeito === 'function') {
                window.resetStepBugDefeito();
            }

            // Mostrar modal
            if (modalInstance) {
                modalInstance.show();
            } else if (modalEditarDemanda) {
                modalEditarDemanda.classList.remove('hidden');
            }

        } catch (error) {
            console.error('Erro ao carregar formulário de edição:', error);
            alert('Erro ao carregar formulário de edição');
        }
    };

    // ==================== Função Global para Fechar Modal ====================
    window.fecharModalEditar = function () {
        if (modalInstance) {
            modalInstance.hide();
        } else if (modalEditarDemanda) {
            modalEditarDemanda.classList.add('hidden');
        }
    };
});