/**
 * @file public/js/acoes-datatables.js
 * @description Script para gerenciar ações e filtros da DataTable de demandas.
 * Inclui filtro de demandas priorizadas pelo comitê.
 * @author Pedro e Rafaela
 */

// Estado do filtro
let filtroPriorizadasAtivo = false;
let dadosOriginais = null;

/**
 * Inicializa o botão de filtro de priorizadas
 */
document.addEventListener('DOMContentLoaded', function() {
    const btnFiltrar = document.getElementById('button-filtrar-priorizadas');
    
    if (btnFiltrar) {
        btnFiltrar.addEventListener('click', toggleFiltroPriorizadas);
    }
});

/**
 * Alterna entre filtrar priorizadas e mostrar todas
 */
async function toggleFiltroPriorizadas() {
    const btn = document.getElementById('button-filtrar-priorizadas');
    const textoFiltro = document.getElementById('filtro-texto');
    const loadingElement = document.getElementById('table-loading');
    const tableContainer = document.getElementById('table-container');
    
    try {
        // Mostrar loading
        if (loadingElement) loadingElement.classList.remove('hidden');
        if (tableContainer) tableContainer.classList.add('hidden');
        
        // Desabilitar botão durante a requisição
        btn.disabled = true;
        
        if (!filtroPriorizadasAtivo) {
            // Ativar filtro - buscar apenas priorizadas
            const response = await fetch('/api/demandas/priorizadas');
            const result = await response.json();
            
            if (result.success) {
                atualizarTabela(result.data);
                filtroPriorizadasAtivo = true;
                
                // Atualizar aparência do botão
                btn.classList.remove('bg-white', 'text-gray-900', 'border-gray-200');
                btn.classList.add('bg-yellow-100', 'text-yellow-800', 'border-yellow-400');
                textoFiltro.textContent = 'Mostrar Todas';
                
                // Mostrar notificação
                mostrarNotificacao(`${result.data.length} demanda(s) priorizada(s) encontrada(s)`, 'success');
            } else {
                throw new Error(result.message);
            }
        } else {
            // Desativar filtro - buscar todas as demandas
            const response = await fetch('/api/demandas/todas');
            const result = await response.json();
            
            if (result.success) {
                atualizarTabela(result.data);
                filtroPriorizadasAtivo = false;
                
                // Restaurar aparência do botão
                btn.classList.remove('bg-yellow-100', 'text-yellow-800', 'border-yellow-400');
                btn.classList.add('bg-white', 'text-gray-900', 'border-gray-200');
                textoFiltro.textContent = 'Filtrar Priorizadas';
                
                // Mostrar notificação
                mostrarNotificacao('Mostrando todas as demandas', 'info');
            } else {
                throw new Error(result.message);
            }
        }
    } catch (error) {
        console.error('Erro ao filtrar demandas:', error);
        mostrarNotificacao('Erro ao filtrar demandas. Tente novamente.', 'error');
    } finally {
        // Reabilitar botão
        btn.disabled = false;
        
        // Esconder loading e mostrar tabela
        if (loadingElement) loadingElement.classList.add('hidden');
        if (tableContainer) tableContainer.classList.remove('hidden');
    }
}

/**
 * Atualiza a tabela com os novos dados
 * @param {Array} demandas - Array de demandas para exibir
 */
function atualizarTabela(demandas) {
    // Verificar se a DataTable existe
    if (!window.dataTable) {
        console.error('DataTable não encontrada');
        return;
    }
    
    // Converter demandas para o formato da tabela
    const novasLinhas = demandas.map(d => gerarLinhaDemanda(d));
    
    // Limpar e repopular a tabela
    window.dataTable.destroy();
    
    const tabelaElement = document.getElementById('tabela-demandas');
    const tbody = tabelaElement.querySelector('tbody');
    tbody.innerHTML = '';
    
    novasLinhas.forEach(row => {
        const tr = document.createElement('tr');
        row.forEach(cell => {
            const td = document.createElement('td');
            td.className = 'font-medium text-gray-900';
            td.innerHTML = cell;
            tr.appendChild(td);
        });
        tbody.appendChild(tr);
    });
    
    // Reinicializar DataTable
    reinicializarDataTable();
}

/**
 * Gera uma linha da tabela para uma demanda
 * @param {Object} d - Objeto da demanda
 * @returns {Array} Array com os valores das células
 */
function gerarLinhaDemanda(d) {
    // Botões de ação
    let botaoEditar = '';
    
    if (d.tipologia === 'Bug' || d.tipologia === 'Defeito') {
        botaoEditar = `
            <button onclick="editarDemanda('${d.id_demanda}')" type="button"
            style="padding: 8px; background: none; border: none; cursor: pointer; color: #2563eb; transition: all 0.2s ease-in-out;"
            onmouseover="this.style.color='#1d4ed8'; this.style.transform='scale(1.25)';"
            onmouseout="this.style.color='#2563eb'; this.style.transform='scale(1)';"
            title="Editar demanda">
                <svg style="width: 20px; height: 20px;" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m14.304 4.844 2.852 2.852M7 7H4a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h11a1 1 0 0 0 1-1v-4.5m2.409-9.91a2.017 2.017 0 0 1 0 2.853l-6.844 6.844L8 14l.713-3.565 6.844-6.844a2.015 2.015 0 0 1 2.852 0Z"/>
                </svg>
            </button>
        `;
    } else if (d.tipologia === 'Melhoria') {
        botaoEditar = `
            <button onclick="editarDemandaMelhoria('${d.id_demanda}')" type="button"
            style="padding: 8px; background: none; border: none; cursor: pointer; color: #2563eb; transition: all 0.2s ease-in-out;"
            onmouseover="this.style.color='#1d4ed8'; this.style.transform='scale(1.25)';"
            onmouseout="this.style.color='#2563eb'; this.style.transform='scale(1)';"
            title="Editar demanda">
                <svg style="width: 20px; height: 20px;" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m14.304 4.844 2.852 2.852M7 7H4a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h11a1 1 0 0 0 1-1v-4.5m2.409-9.91a2.017 2.017 0 0 1 0 2.853l-6.844 6.844L8 14l.713-3.565 6.844-6.844a2.015 2.015 0 0 1 2.852 0Z"/>
                </svg>
            </button>
        `;
    }

    const botaoExcluir = `
        <button onclick="excluirDemanda('${d.id_demanda}')" type="button" data-modal-target="modal-excluir-demanda" 
        style="padding: 8px; background: none; border: none; cursor: pointer; color: #ef4444; transition: all 0.2s ease-in-out;"
        onmouseover="this.style.color='#dc2626'; this.style.transform='scale(1.25)';"
        onmouseout="this.style.color='#ef4444'; this.style.transform='scale(1)';"
        title="Excluir demanda">
        <svg style="width: 20px; height: 20px;" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 7h14m-9 3v8m4-8v8M10 3h4a1 1 0 0 1 1 1v3H9V4a1 1 0 0 1 1-1ZM6 7h12v13a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V7Z"/>
        </svg>
    </button>
    `;

    const botaoObservacoes = `
        <button onclick="abrirObservacoes('${d.id_demanda}')" type="button"
            style="padding: 8px; background: none; border: none; cursor: pointer; color: #4e4e4e; transition: all 0.2s ease-in-out;"
            onmouseover="this.style.color='#414141'; this.style.transform='scale(1.25)';"
            onmouseout="this.style.color='#414141'; this.style.transform='scale(1)';"
            title="Ver observações">
            <svg style="width: 20px; height: 20px;" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7.556 8.5h8m-8 3.5H12m7.111-7H4.89a.896.896 0 0 0-.629.256.868.868 0 0 0-.26.619v9.25c0 .232.094.455.26.619A.896.896 0 0 0 4.89 16H9l3 4 3-4h4.111a.896.896 0 0 0 .629-.256.868.868 0 0 0 .26-.619v-9.25a.868.868 0 0 0-.26-.619A.896.896 0 0 0 19.111 5Z"/>
            </svg>
        </button>
    `;

    const acoes = `
        <div style="display: flex; gap: 4px; align-items: center;" data-id-demanda="${d.id_demanda}">
            ${botaoEditar}
            ${botaoExcluir}
            ${botaoObservacoes}
        </div>
    `;

    // Número GD com estrela se priorizacao_comite = 'sim'
    const estrela = d.priorizacao_comite?.toLowerCase() === 'sim' 
        ? ' <svg class="w-5 h-5 text-yellow-400" style="display: inline; vertical-align: middle; margin-left: 4px; margin-bottom:4px;" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" title="Demanda priorizada"><path d="M13.849 4.22c-.684-1.626-3.014-1.626-3.698 0L8.397 8.387l-4.552.361c-1.775.14-2.495 2.331-1.142 3.477l3.468 2.937-1.06 4.392c-.413 1.713 1.472 3.067 2.992 2.149L12 19.35l3.897 2.354c1.52.918 3.405-.436 2.992-2.15l-1.06-4.39 3.468-2.938c1.353-1.146.633-3.336-1.142-3.477l-4.552-.36-1.754-4.17Z"/></svg>'
        : '';
    const numeroGd = `<span style="white-space: nowrap;">${d.numero_gd}${estrela}</span>`;

    // Período
    const periodo = d.semestre && d.ano ? `${d.semestre}S${d.ano}` : '-';

    // Formatação da Prioridade GUTHIE
    let classeGuthie = 'bg-gray-100 text-gray-800';
    const textoGuthie = d.priorizacao_guthie || d.prioridade_guthie || 'N/A';
    
    switch(textoGuthie) {
        case 'Baixa':
            classeGuthie = 'bg-gray-100 text-gray-800';
            break;
        case 'Média':
            classeGuthie = 'bg-blue-100 text-blue-700';
            break;
        case 'Alta':
            classeGuthie = 'bg-rose-100 text-rose-700';
            break;
        case 'Muito Alta':
            classeGuthie = 'bg-rose-200 text-rose-800';
            break;
    }
    const prioridadeGuthie = `<span class="px-2 py-1 rounded-full text-xs font-medium ${classeGuthie}">${textoGuthie}</span>`;

    return [
        acoes,
        d.tipologia,
        numeroGd,
        d.nome,
        periodo,
        d.score_guthie || d.score || '-',
        prioridadeGuthie,
        d.status_nome || d.status || '-',
        d.funci_atan || '-',
        d.funci_design || '-'
    ];
}

/**
 * Reinicializa a DataTable com as configurações padrão
 */
function reinicializarDataTable() {
    window.dataTable = new simpleDatatables.DataTable("#tabela-demandas", {
        perPage: 10,
        labels: {
            placeholder: "Pesquisar...",
            perPage: "por página",
            noRows: "Nenhum registro encontrado",
            info: "Mostrando {start} a {end} de {rows} registros"
        },
        columns: [
            {
                select: 0,
                sortable: false,
                searchable: false
            },
        ],
        layout: {
            top: "",
            bottom: "{info}{select}{pager}"
        },
        tableRender: (_data, table, type) => {
            if (type === "print") {
                return table
            }

            table.attributes = {
                ...table.attributes,
                style: 'width: 100%; table-layout: auto;'
            };

            const tHead = table.childNodes[0]
            const filterHeaders = {
                nodeName: "TR",
                attributes: {
                    class: "search-filtering-row"
                },
                childNodes: tHead.childNodes[0].childNodes.map(
                    (_th, index) => ({
                        nodeName: "TH",
                        attributes: {
                            style: "padding: 0.5rem; vertical-align: top;"
                        },
                        childNodes: index === 0 ? [] : [
                            {
                                nodeName: "INPUT",
                                attributes: {
                                    class: "datatable-input form-control form-control-sm",
                                    type: "search",
                                    "data-columns": "[" + index + "]",
                                    style: "width: 100%; min-width: 80px; font-size: 0.875rem;",
                                    placeholder: "Filtrar..."
                                }
                            }
                        ]
                    })
                )
            }
            tHead.childNodes.push(filterHeaders)
            return table
        }
    });
}

/**
 * Mostra uma notificação temporária para o usuário
 * @param {string} mensagem - Mensagem a ser exibida
 * @param {string} tipo - Tipo da notificação: 'success', 'error', 'info'
 */
function mostrarNotificacao(mensagem, tipo = 'info') {
    // Remover notificação anterior se existir
    const notificacaoAnterior = document.getElementById('notificacao-filtro');
    if (notificacaoAnterior) {
        notificacaoAnterior.remove();
    }

    // Definir cores baseadas no tipo
    let bgColor, textColor, borderColor;
    switch(tipo) {
        case 'success':
            bgColor = 'bg-green-50';
            textColor = 'text-green-800';
            borderColor = 'border-green-200';
            break;
        case 'error':
            bgColor = 'bg-red-50';
            textColor = 'text-red-800';
            borderColor = 'border-red-200';
            break;
        default:
            bgColor = 'bg-blue-50';
            textColor = 'text-blue-800';
            borderColor = 'border-blue-200';
    }

    // Criar elemento de notificação
    const notificacao = document.createElement('div');
    notificacao.id = 'notificacao-filtro';
    notificacao.className = `fixed top-20 right-4 z-50 px-4 py-3 rounded-lg border ${bgColor} ${textColor} ${borderColor} shadow-lg transition-all duration-300 transform translate-x-0`;
    notificacao.innerHTML = `
        <div class="flex items-center gap-2">
            <span class="text-sm font-medium">${mensagem}</span>
            <button onclick="this.parentElement.parentElement.remove()" class="ml-2 ${textColor} hover:opacity-70">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                </svg>
            </button>
        </div>
    `;

    // Adicionar ao DOM
    document.body.appendChild(notificacao);

    // Remover após 4 segundos
    setTimeout(() => {
        if (notificacao.parentElement) {
            notificacao.classList.add('opacity-0', 'translate-x-full');
            setTimeout(() => notificacao.remove(), 300);
        }
    }, 4000);
}
