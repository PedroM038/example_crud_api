/**
 * @file services/tip_tags_service.js
 * @description Gerencia as tags disponíveis para demandas do tipo melhoria.
 */

const { models } = require('../models/associations');

class TipTagsService {

    static async buscarTodas(options = {}) {
        return models.TipTags.findAll({
            attributes: ['id', 'tag', 'deletedAt'],
            order: [['tag', 'ASC']],
            paranoid: false,
            ...options
        });
    }

    static async buscarAtivas(options = {}) {
        return models.TipTags.findAll({
            attributes: ['id', 'tag'],
            order: [['tag', 'ASC']],
            ...options
        });
    }

    static async criar(data, options = {}) {
        return models.TipTags.create(data, options);
    }

    static async atualizar(id, data, options = {}) {
        const [updated] = await models.TipTags.update(data, {
            where: { id },
            ...options
        });
        if (!updated) throw new Error('Tag não encontrada');
        return models.TipTags.findByPk(id, options);
    }

    static async deletar(id, options = {}) {
        const deleted = await models.TipTags.destroy({
            where: { id },
            ...options
        });
        if (!deleted) throw new Error('Tag não encontrada');
    }

    static async restaurar(id, options = {}) {
        const restored = await models.TipTags.restore({
            where: { id },
            ...options
        });
        if (!restored) throw new Error('Tag não encontrada');
    }
}

module.exports = TipTagsService;
