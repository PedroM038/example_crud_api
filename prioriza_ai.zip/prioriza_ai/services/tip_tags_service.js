/**
 * @file services/tip_tags_service.js
 * @description Responsável por gerenciar as tags disponíveis no sistema.
 * A tabela tip_tags contém todas as tags que podem ser associadas
 * a uma demanda do tipo melhoria.
 */

const { TipTags } = require('../models/associations');

const TipTagsService = {

    async buscaTodasTags() {
        try {
            const tags = await TipTags.findAll({
                attributes: ['id', 'tag', 'deletedAt'],
                order: [['tag', 'ASC']],
                paranoid: false
            });

            return tags;
        } catch (error) {
            throw new Error(`Erro ao buscar tags: ${error.message}`);
        }
    },

    async buscaTodasTagsAtivas() {
        try {
            const tags = await TipTags.findAll({
                attributes: ['id', 'tag', 'deletedAt'],
                order: [['tag', 'ASC']],
                paranoid: true
            });

            return tags;
        } catch (error) {
            throw new Error(`Erro ao buscar tags: ${error.message}`);
        }
    },

    async criaTag(tagData) {
        try {
            const novaTag = await TipTags.create(tagData);
            return novaTag;
        } catch (error) {
            throw new Error(`Erro ao criar tag: ${error.message}`);
        }
    },

    async atualizaTag(id, tagData) {
        try {
            const [updated] = await TipTags.update(tagData, {
                where: { id }
            });
            if (updated) {
                const tagAtualizada = await TipTags.findByPk(id);
                return tagAtualizada;
            }
            throw new Error("Tag não encontrada");
        } catch (error) {
            throw new Error(`Erro ao atualizar tag: ${error.message}`);
        }
    },

    async deletaTag(id) {
        try {
            const deleted = await TipTags.destroy({
                where: { id }
            });
            if (deleted) {
                return { message: "Tag deletada com sucesso" };
            }
            throw new Error("Tag não encontrada");
        } catch (error) {
            throw new Error(`Erro ao deletar tag: ${error.message}`);
        }
    },

    async restauraTag(id) {
        try {
            const restored = await TipTags.restore({
                where: { id }
            });
            if (restored) {
                return { message: "Tag restaurada com sucesso" };
            }
            throw new Error("Tag não encontrada ou não estava deletada");
        } catch (error) {
            throw new Error(`Erro ao restaurar tag: ${error.message}`);
        }
    },
};

module.exports = TipTagsService;
