const tip_inviabilidades = require('../models/tip_inviabilidades');

class tip_inviabilidades_service {

    static async buscaTodasInviabilidades() {
        try {
            const inviabilidades = await tip_inviabilidades.findAll({
                attributes: ['id', 'inviabilidade', 'deletedAt'],
                order: [['inviabilidade', 'ASC']],
                paranoid: false
            });
            return inviabilidades;
        } catch (error) {
            console.error("Erro ao buscar inviabilidades:", error);
            throw new Error("Erro ao buscar inviabilidades");
        }
    }

    static async buscaTodasInviabilidadesAtivas() {
        try {
            const inviabilidades = await tip_inviabilidades.findAll({
                attributes: ['id', 'inviabilidade', 'deletedAt'],
                order: [['inviabilidade', 'ASC']],
                paranoid: true
            });
            return inviabilidades;
        } catch (error) {
            console.error("Erro ao buscar inviabilidades:", error);
            throw new Error("Erro ao buscar inviabilidades");
        }
    }
    
    static async criaInviabilidade(inviabilidadeData) {
        try {
            const novaInviabilidade = await tip_inviabilidades.create(inviabilidadeData);
            return novaInviabilidade;
        } catch (error) {
            console.error("Erro ao criar inviabilidade:", error);
            throw new Error("Erro ao criar inviabilidade");
        }
    }

    static async atualizaInviabilidade(id, inviabilidadeData) {
        try {
            const [updated] = await tip_inviabilidades.update(inviabilidadeData, {
                where: { id: id }
            });
            if (updated) {
                const updatedInviabilidade = await tip_inviabilidades.findByPk(id);
                return updatedInviabilidade;
            }
            throw new Error("Inviabilidade não encontrada");
        } catch (error) {
            console.error("Erro ao atualizar inviabilidade:", error);
            throw new Error("Erro ao atualizar inviabilidade");
        }
    }

    static async deletaInviabilidade(id) {
        try {
            const deleted = await tip_inviabilidades.destroy({
                where: { id: id }
            });
            if (deleted) {
                return { message: "Inviabilidade deletada com sucesso" };
            }
            throw new Error("Inviabilidade não encontrada");
        } catch (error) {
            console.error("Erro ao deletar inviabilidade:", error);
            throw new Error("Erro ao deletar inviabilidade");
        }
    }

    static async restauraInviabilidade(id) {
        try {
            const restored = await tip_inviabilidades.restore({
                where: { id: id }
            });
            if (restored) {
                return { message: "Inviabilidade restaurada com sucesso" };
            }
            throw new Error("Inviabilidade não encontrada ou não estava deletada");
        } catch (error) {
            console.error("Erro ao restaurar inviabilidade:", error);
            throw new Error("Erro ao restaurar inviabilidade");
        }
    }
}

module.exports = tip_inviabilidades_service;