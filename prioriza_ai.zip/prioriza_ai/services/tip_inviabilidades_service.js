const { models } = require('../models/associations');

class TipInviabilidadesService {

    static async buscarTodas(options = {}) {
        return models.TipInviabilidades.findAll({
            attributes: ['id', 'inviabilidade', 'deletedAt'],
            order: [['inviabilidade', 'ASC']],
            paranoid: false,
            ...options
        });
    }

    static async buscarAtivas(options = {}) {
        return models.TipInviabilidades.findAll({
            attributes: ['id', 'inviabilidade'],
            order: [['inviabilidade', 'ASC']],
            ...options
        });
    }

    static async criar(data, options = {}) {
        return models.TipInviabilidades.create(data, options);
    }

    static async atualizar(id, data, options = {}) {
        const [updated] = await models.TipInviabilidades.update(data, {
            where: { id },
            ...options
        });
        if (!updated) throw new Error('Inviabilidade não encontrada');
        return models.TipInviabilidades.findByPk(id, options);
    }

    static async deletar(id, options = {}) {
        const deleted = await models.TipInviabilidades.destroy({
            where: { id },
            ...options
        });
        if (!deleted) throw new Error('Inviabilidade não encontrada');
    }

    static async restaurar(id, options = {}) {
        const restored = await models.TipInviabilidades.restore({
            where: { id },
            ...options
        });
        if (!restored) throw new Error('Inviabilidade não encontrada');
    }
}

module.exports = TipInviabilidadesService;