const { models } = require('../models/associations');

class TipHorasEconomizadasService {

    static async buscarTodas(options = {}) {
        return models.TipHorasEconomizadas.findAll({
            attributes: ['id', 'peso', 'pontos', 'legenda'],
            order: [['peso', 'ASC']],
            ...options
        });
    }

    static async criar(data, options = {}) {
        return models.TipHorasEconomizadas.create(data, options);
    }

    static async atualizar(id, data, options = {}) {
        const [updated] = await models.TipHorasEconomizadas.update(data, {
            where: { id },
            ...options
        });
        if (!updated) throw new Error('Horas economizadas não encontrada');
        return models.TipHorasEconomizadas.findByPk(id, options);
    }
}

module.exports = TipHorasEconomizadasService;

