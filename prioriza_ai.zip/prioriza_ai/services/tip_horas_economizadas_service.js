const tip_horas_economizadas = require('../models/tip_horas_economizadas');

class tip_horas_economizadas_service {
    static async buscaTodasHorasEconomizadas() {
        try {
            const horas = await tip_horas_economizadas.findAll({
                attributes: ['id', 'peso', 'pontos', 'legenda'],
                order: [['peso', 'ASC']]
            });
            return horas;
        } catch (error) {
            console.error("Erro ao buscar horas economizadas:", error);
            throw new Error("Erro ao buscar horas economizadas");
        }
    }
    
    static async criaHorasEconomizadas(horasData) {
        try {
            const novasHoras = await tip_horas_economizadas.create(horasData);
            return novasHoras;
        } catch (error) {
            console.error("Erro ao criar horas economizadas:", error);
            throw new Error("Erro ao criar horas economizadas");
        }
    }

    static async atualizaHorasEconomizadas(id, horasData) {
        try {
            const [updated] = await tip_horas_economizadas.update(horasData, {
                where: { id: id }
            });
            if (updated) {
                const updatedHoras = await tip_horas_economizadas.findByPk(id);
                return updatedHoras;
            }
            throw new Error("Horas economizadas não encontrada");
        } catch (error) {
            console.error("Erro ao atualizar horas economizadas:", error);
            throw new Error("Erro ao atualizar horas economizadas");
        }
    }
}

module.exports = tip_horas_economizadas_service;

