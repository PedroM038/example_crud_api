/**
 * @file services/observacoes_service.js
 * @description Serviço para gerenciar as operações relacionadas às observações das demandas.
 * Inclui busca de observações por demanda e inserção de novas observações.
 * @author Pedro e Rafaela
 */

const Observacoes = require('../models/observacoes');
const { Op } = require('sequelize');

class ObservacoesService {

    /**
     * Busca todas as observações de uma demanda específica
     * @param {number} id_demanda - ID da demanda
     * @returns {Array} Lista de observações ordenadas por data (mais recente primeiro)
     */
    static async buscaObservacoesPorDemanda(id_demanda) {
        try {
            const observacoes = await Observacoes.findAll({
                where: { id_demanda },
                order: [['data', 'DESC']],
                raw: true
            });

            // Mapear dados para o formato esperado pelo front
            return observacoes.map(obs => ({
                id: obs.id_observacao,
                id_demanda: obs.id_demanda,
                observacao: obs.observacao,
                data: obs.data,
                matricula: obs.matricula,
                nome: obs.nome,
                // Formatar usuário para exibição
                usuario: obs.matricula ? `${obs.nome}` : 'Usuário'
            }));

        } catch (error) {
            console.error("Erro ao buscar observações por demanda:", error);
            throw new Error("Erro ao buscar observações por demanda");
        }
    }

    /**
     * Insere uma nova observação para uma demanda
     * @param {number} id_demanda - ID da demanda
     * @param {string} observacao - Texto da observação
     * @param {string} matricula - Matrícula do usuário que está criando a observação
     * @returns {Object} Dados da observação criada
     */
    static async inserirObservacao(id_demanda, observacao, matricula, nome) {
        try {
            // Validações
            if (!id_demanda) {
                throw new Error("ID da demanda é obrigatório");
            }

            if (!observacao || observacao.trim().length === 0) {
                throw new Error("Texto da observação é obrigatório");
            }

            if (observacao.trim().length > 1000) {
                throw new Error("Observação muito longa (máximo 1000 caracteres)");
            }

            const novaObservacao = await Observacoes.create({
                id_demanda,
                observacao: observacao.trim(),
                matricula: matricula || null,
                nome: nome || null,
            });

            // Retornar já no formato esperado pelo front
            return {
                id: novaObservacao.id_observacao,
                id_demanda: novaObservacao.id_demanda,
                observacao: novaObservacao.observacao,
                data: novaObservacao.data,
                matricula: novaObservacao.matricula,
                nome: novaObservacao.nome,
                usuario: novaObservacao.matricula ? `${novaObservacao.nome}` : 'Usuário'
            };

        } catch (error) {
            console.error("Erro ao inserir observação:", error);
            throw new Error(error.message || "Erro ao inserir observação");
        }
    }

    /**
     * Conta o número de observações de uma demanda
     * @param {number} id_demanda - ID da demanda
     * @returns {number} Número de observações
     */
    static async contarObservacoesPorDemanda(id_demanda) {
        try {
            const count = await Observacoes.count({
                where: { id_demanda }
            });
            
            return count;
        } catch (error) {
            console.error("Erro ao contar observações:", error);
            return 0;
        }
    }
}

module.exports = ObservacoesService;