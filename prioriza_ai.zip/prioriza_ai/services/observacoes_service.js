/**
 * @file services/observacoes_service.js
 * @description Serviço para gerenciar operações de observações das demandas.
 * @author Pedro e Rafaela
 */

const { models } = require('../models/associations');

class ObservacoesService {

    /**
     * Busca todas as observações de uma demanda
     * @param {number} idDemanda - ID da demanda
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Array>} Lista de observações ordenadas por data
     */
    static async buscarPorDemanda(idDemanda, options = {}) {
        return models.Observacoes.findAll({
            where: { id_demanda: idDemanda },
            order: [['data', 'DESC']],
            ...options
        });
    }

    /**
     * Cria uma nova observação
     * @param {Object} dados - Dados da observação
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Object>} Observação criada
     */
    static async criar(dados, options = {}) {
        return models.Observacoes.create({
            id_demanda: dados.idDemanda,
            observacao: dados.observacao?.trim(),
            matricula: dados.matricula || null,
            nome: dados.nome || null
        }, options);
    }

    /**
     * Conta observações de uma demanda
     * @param {number} idDemanda - ID da demanda
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<number>} Quantidade de observações
     */
    static async contarPorDemanda(idDemanda, options = {}) {
        return models.Observacoes.count({
            where: { id_demanda: idDemanda },
            ...options
        });
    }

    /**
     * Remove uma observação por ID
     * @param {number} idObservacao - ID da observação
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<number>} Número de registros removidos
     */
    static async remover(idObservacao, options = {}) {
        return models.Observacoes.destroy({
            where: { id_observacao: idObservacao },
            ...options
        });
    }

    /**
     * Remove todas as observações de uma demanda
     * @param {number} idDemanda - ID da demanda
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<number>} Número de registros removidos
     */
    static async removerPorDemanda(idDemanda, options = {}) {
        return models.Observacoes.destroy({
            where: { id_demanda: idDemanda },
            ...options
        });
    }
}

module.exports = ObservacoesService;