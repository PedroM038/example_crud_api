/**
 * @file services/bugDefeitoService.js
 * @description Serviço para gerenciar demandas do tipo Bug/Defeito.
 * Responsável por buscar (uma ou todas) e editar demandas agregando dados das tabelas relacionadas.
 * Campos retornados: id_demanda, nome, tipologia, numero_gd, ferramenta, status, funci_atan, estagiario_atan
 * Suporta múltiplos motivos por demanda através da tabela motivos_demanda.
 * @author
 */

const { Op } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const Demandas = require('../models/demandas');
const DemandasBugDefeito = require('../models/demandas_bug_defeito');
const Status = require('../models/tip_status');
const Estagiarios = require('../models/tip_estagiarios');
const tip_motivos = require('../models/tip_motivos');
const MotivosDemanda = require('../models/motivos_demanda');
const Precificacao = require('../models/precificacao');
const PrecificacaoDev = require('../models/tip_precificacao_dev');

const scoreBug = '4.00';
const scoreDefeito = '5.00';
const prioridadeBug = 'Alta';
const prioridadeDefeito = 'Muito Alta';

const BugDefeitoService = {

    /**
     * Verifica se a demanda é do tipo Bug ou Defeito.
     * @param {string} tipologia
     * @return {boolean}
     */
    verificaTipoDemanda(tipologia) {
        return tipologia === 'Bug' || tipologia === 'Defeito';
    },

    
    /**
     * Monta objeto de retorno unificado.
     * @param {Object} demandaInstance - Instância da demanda
     * @param {string|null} ferramentaNome - Nome da ferramenta (opcional, obtido via API)
     * @param {Array|null} motivosArray - Array de motivos associados à demanda
     */
    _mapDemanda(demandaInstance, motivosArray = null) {
        if (!demandaInstance) return null;
        const d = demandaInstance;
        const b = d.bugDetalhe || {};
        const status = b.statusInfo || {};
        const estagiario = b.estagiarioInfo || {};
        const estagiarioAux = b.estagiarioAuxInfo || {};
        
        // Mapear motivos do array (formato N:N)
        const motivos = motivosArray ? motivosArray.map(m => ({
            id: m.id,
            motivo: m.motivo
        })) : [];

        return {
            id_demanda: d.id_demanda,
            nome: d.nome,
            tipologia: d.tipologia,
            numero_gd: d.numero_gd,
            semestre: d.semestre,
            ano: d.ano,
            ferramenta_id: b.ferramenta,
            ferramenta_nome: b.ferramenta_nome, // Agora vem da API CESUP
            motivos: motivos,
            motivos_ids: motivos.map(m => m.id),
            status_id: b.status,
            status_nome: status.status,
            funci_atan: b.funci_atan,
            estagiario_atan: b.estagiario_atan,
            estagiario_nome: estagiario.nome,
            estagiario_aux_atan: b.estagiario_atan_aux,
            estagiario_aux_nome: estagiarioAux.nome,
            score: d.tipologia === 'Bug' ? scoreBug : scoreDefeito,
            prioridade_guthie: d.tipologia === 'Bug' ? prioridadeBug : prioridadeDefeito,
            prioridade_comite: null,

            precificacao: {
                id: d.precificacaoInfo?.id || null,
                precificacao_dev_id: d.precificacaoInfo?.precificacao_dev || null,
                precificacao_dev_legenda: d.precificacaoInfo?.precificacaoDevInfo?.legenda || null,
                precificacao_dev_sprints: d.precificacaoInfo?.precificacaoDevInfo?.quant_sprints || null,
            },
        };
    },

     /**
     * @description Mapeia uma demanda Bug/Defeito para o formato esperado na tabela do frontend.
     * Aqui teremos menos detalhes, apenas o necessário para a lista.
     * Os dados necessários são: id, nome, numero_gd, tipologia, status, guthie.score, guthie.priorizacao_guthie, priorizacao_comite
     * funci_atan, funci_design. Assim teremos menos dados e mais performático.
     * 
     * @param {Object} demandaInstance - Instância da demanda BugDefeito.
     * @param {*} demandaInstance 
     * @return {Object|null} - Objeto mapeado ou null se a demanda não existir.
     * @private
     */
    _mapDemandaLista(demandaInstance) {
        if (!demandaInstance) return null;
        const d = demandaInstance;
        const b = d.bugDetalhe || {};
        const status = b.statusInfo || {};

        return {
            id_demanda: d.id_demanda,
            nome: d.nome,
            numero_gd: d.numero_gd,
            tipologia: d.tipologia,
            semestre: d.semestre,
            ano: d.ano,
            status_id: b.status,
            status_nome: status.status,
            funci_atan: b.funci_atan,
            score_guthie: d.tipologia === 'Bug' ? scoreBug : scoreDefeito,
            priorizacao_guthie: d.tipologia === 'Bug' ? prioridadeBug : prioridadeDefeito,
            priorizacao_comite: null,
            funci_design: null, // Este campo não é utilizado em Bug/Defeito, mas mantido para compatibilidade
            createdAt: d.createdAt
        }
    },

    /**
     * Busca uma demanda Bug/Defeito pelo ID.
     * @param {number} idDemanda
     * @param {string} cookies - Cookies para autenticação na API CESUP (opcional)
     * @returns {Promise<Object|null>}
     */
    async buscaDemandaPorId(idDemanda, cookies = '') {
        const demanda = await Demandas.findOne({
            where: {
                id_demanda: idDemanda,
                tipologia: { [Op.in]: ['Bug', 'Defeito'] }
            },
            include: [
                {
                    model: DemandasBugDefeito,
                    as: 'bugDetalhe',
                    required: true,
                    attributes: ['ferramenta', 'ferramenta_nome', 'status', 'funci_atan', 'estagiario_atan', 'estagiario_atan_aux'],
                    include: [
                        {
                            model: Status,
                            as: 'statusInfo',
                            attributes: ['status']
                        },
                        {
                            model: Estagiarios,
                            as: 'estagiarioInfo',
                            attributes: ['nome', 'matricula']
                        },
                        {
                            model: Estagiarios,
                            as: 'estagiarioAuxInfo',
                            attributes: ['nome', 'matricula']
                        }
                    ]
                },
                {
                    model: Precificacao,
                    as: 'precificacaoInfo',
                    required: false,
                    include: [
                        {
                            model: PrecificacaoDev,
                            as: 'precificacaoDevInfo',
                            attributes: ['id', 'legenda', 'quant_sprints']
                        }
                    ]
                },
                {
                    model: tip_motivos,
                    as: 'motivos',
                    attributes: ['id', 'motivo'],
                    through: { attributes: [] } // Não incluir campos da tabela intermediária
                }
            ]
        });

        if (!demanda) return null;

        // Passar os motivos do relacionamento N:N
        const motivosArray = demanda.motivos || [];
        return this._mapDemanda(demanda, motivosArray);
    },

    /**
     * Busca todas as demandas Bug/Defeito.
     * Filtro: demandas do ano/semestre atual OU demandas de períodos anteriores
     * que não estejam com status "Entregue" ou "Cancelado".
     * @returns {Promise<Array>}
     */
    async buscaTodasDemandas() {
        // Obter ano e semestre atuais
        const dataAtual = new Date();
        const anoAtual = dataAtual.getFullYear();
        const semestreAtual = dataAtual.getMonth() < 6 ? 1 : 2;

        // Status que excluem demandas de períodos anteriores
        const statusExcluidos = ['Entregue', 'Cancelado'];

        const demandas = await Demandas.findAll({
            where: {
                tipologia: { [Op.in]: ['Bug', 'Defeito'] },
                ativa: true
            },
            include: [
                {
                    model: DemandasBugDefeito,
                    as: 'bugDetalhe',
                    required: true,
                    attributes: ['status', 'funci_atan', 'estagiario_atan'],
                    include: [
                        {
                            model: Status,
                            as: 'statusInfo',
                            attributes: ['status']
                        },
                    ]
                },
            ],
            order: [['createdAt', 'DESC']]
        });

        // Filtrar em memória para aplicar a lógica correta
        const demandasFiltradas = demandas.filter(d => {
            const ehPeriodoAtual = d.ano === anoAtual && parseInt(d.semestre) === semestreAtual;
            
            // Se for do período atual, inclui independente do status
            if (ehPeriodoAtual) return true;

            // Se for de período anterior, verifica se o status não é Entregue ou Cancelado
            const statusNome = d.bugDetalhe?.statusInfo?.status;
            return !statusExcluidos.includes(statusNome);
        });

        return demandasFiltradas.map(d => this._mapDemandaLista(d));
    },

    /**
 * Edita uma demanda Bug/Defeito (dados específicos).
 * Suporta múltiplos motivos através do array motivos_ids.
 * @param {number} idDemanda
 * @param {Object} dados
 * @param {Array<number>} dados.motivos_ids - Array de IDs dos motivos selecionados
 * @returns {Promise<Object>} demanda atualizada
 */
    async editaDemanda(idDemanda, dados) {
        const {
            semestre,
            ano,
            ferramenta,
            ferramenta_nome,
            motivos_ids,
            status,
            funci_atan,
            estagiario_atan,
            estagiario_atan_aux,
            precificacao_dev_id
        } = dados;

        return await sequelize.transaction(async (t) => {
            const demanda = await Demandas.findOne({
                where: {
                    id_demanda: idDemanda,
                    tipologia: { [Op.in]: ['Bug', 'Defeito'] }
                },
                transaction: t
            });

            if (!demanda) {
                throw new Error('Demanda não encontrada ou não é Bug/Defeito.');
            }

            if (semestre !== undefined) demanda.semestre = semestre || null;
            if (ano !== undefined) demanda.ano = ano || null;
            await demanda.save({transaction: t});

            // Detalhe
            const detalhe = await DemandasBugDefeito.findOne({
                where: { id_demanda: idDemanda },
                transaction: t
            });

            if (!detalhe) {
                throw new Error('Registro de detalhe Bug/Defeito não encontrado.');
            }

            if (ferramenta !== undefined) detalhe.ferramenta = ferramenta || null;
            if (ferramenta_nome !== undefined) detalhe.ferramenta_nome = ferramenta_nome || null; 
            if (status !== undefined) detalhe.status = status || null;
            if (funci_atan !== undefined) detalhe.funci_atan = funci_atan || null;
            if (estagiario_atan !== undefined) detalhe.estagiario_atan = estagiario_atan || null;
            if (estagiario_atan_aux !== undefined) detalhe.estagiario_atan_aux = estagiario_atan_aux || null;

            // Gerenciar múltiplos motivos (tabela motivos_demanda)
            if (motivos_ids !== undefined) {
                // Remover motivos existentes
                await MotivosDemanda.destroy({
                    where: { id_demanda: idDemanda },
                    transaction: t
                });

                // Inserir novos motivos (se houver)
                if (Array.isArray(motivos_ids) && motivos_ids.length > 0) {
                    const motivosParaInserir = motivos_ids
                        .filter(id => id) // Remove valores vazios/null
                        .map(motivoId => ({
                            id_demanda: idDemanda,
                            motivo_id: parseInt(motivoId)
                        }));

                    if (motivosParaInserir.length > 0) {
                        await MotivosDemanda.bulkCreate(motivosParaInserir, { transaction: t });
                    }
                }
            }

            let precificacaoData = {};
            if (precificacao_dev_id !== undefined) precificacaoData.precificacao_dev = precificacao_dev_id || null;

            // Verificar se já existe registro na tabela de precificação
            let precificacao = await Precificacao.findOne({
                where: { id_demanda: idDemanda },
                transaction: t
            });

            if (precificacao) {
                // Atualiza registro existente
                await precificacao.update(precificacaoData, { transaction: t });
            } else if (Object.keys(precificacaoData).length > 0) {
                precificacaoData.id_demanda = idDemanda;
                // Cria novo registro
                await Precificacao.create(precificacaoData, { transaction: t });
            }

            await detalhe.save({ transaction: t });

            return;
        });
    }
};

module.exports = BugDefeitoService;