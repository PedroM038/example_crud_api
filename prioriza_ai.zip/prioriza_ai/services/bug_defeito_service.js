/**
 * @file services/bug_defeito_service.js
 * @description Serviço para gerenciar demandas do tipo Bug/Defeito.
 * @author Pedro e Rafaela
 */

const { Op } = require('sequelize');
const { models, sequelize } = require('../models/associations');

// Configurações de score e prioridade por tipologia
const CONFIG_TIPOLOGIA = {
    Bug: { score: '4.00', prioridade: 'Alta' },
    Defeito: { score: '5.00', prioridade: 'Muito Alta' }
};

// Tipologias aceitas por este service
const TIPOLOGIAS = ['Bug', 'Defeito'];

// Includes reutilizáveis
const INCLUDES = {
    // Include mínimo para listagem
    lista: [{
        model: models.DemandasBugDefeito,
        as: 'bugDefeito',
        required: true,
        attributes: ['status', 'funci_atan', 'estagiario_atan'],
        include: [{
            model: models.TipStatus,
            as: 'statusInfo',
            attributes: ['status']
        }]
    }],

    // Include completo para detalhes
    completo: [{
        model: models.DemandasBugDefeito,
        as: 'bugDefeito',
        required: true,
        attributes: ['ferramenta', 'ferramenta_nome', 'status', 'funci_atan', 'estagiario_atan', 'estagiario_atan_aux'],
        include: [
            { model: models.TipStatus, as: 'statusInfo', attributes: ['status'] },
            { model: models.TipEstagiarios, as: 'estagiarioAtan', attributes: ['nome', 'matricula'] },
            { model: models.TipEstagiarios, as: 'estagiarioAtanAux', attributes: ['nome', 'matricula'] }
        ]
    }, {
        model: models.Precificacao,
        as: 'precificacao',
        required: false,
        include: [{
            model: models.TipPrecificacaoDev,
            as: 'devInfo',
            attributes: ['id', 'legenda', 'quant_sprints']
        }]
    }, {
        model: models.TipMotivos,
        as: 'motivos',
        attributes: ['id', 'motivo'],
        through: { attributes: [] }
    }]
};

class BugDefeitoService {

    /**
     * Verifica se a tipologia é Bug ou Defeito
     * @param {string} tipologia
     * @returns {boolean}
     */
    static ehTipologiaValida(tipologia) {
        return TIPOLOGIAS.includes(tipologia);
    }

    /**
     * Busca uma demanda por ID
     * @param {number} idDemanda - ID da demanda
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Object|null>} Demanda mapeada ou null
     */
    static async buscarPorId(idDemanda, options = {}) {
        const demanda = await models.Demandas.findOne({
            where: {
                id_demanda: idDemanda,
                tipologia: { [Op.in]: TIPOLOGIAS }
            },
            include: INCLUDES.completo,
            ...options
        });

        return demanda ? this._mapearCompleto(demanda) : null;
    }

    /**
     * Busca todas as demandas com filtros opcionais
     * @param {Object} filtros - Filtros opcionais
     * @param {number} filtros.ano - Ano específico
     * @param {number} filtros.semestre - Semestre específico
     * @param {number} filtros.statusId - ID do status
     * @param {string} filtros.funciAtan - Matrícula do funcionário
     * @param {boolean} filtros.apenasAtivas - Se true, filtra por ativa=true (default: true)
     * @param {boolean} filtros.incluirEntregues - Se true, inclui Entregue/Cancelado de períodos anteriores
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Array>} Lista de demandas
     */
    static async buscarTodas(filtros = {}, options = {}) {
        const {
            ano,
            semestre,
            statusId,
            funciAtan,
            apenasAtivas = true,
            incluirEntregues = false
        } = filtros;

        // Where base
        const where = {
            tipologia: { [Op.in]: TIPOLOGIAS }
        };

        if (apenasAtivas) where.ativa = true;
        if (ano) where.ano = ano;
        if (semestre) where.semestre = semestre;

        // Where do detalhe (bugDefeito)
        const whereDetalhe = {};
        if (statusId) whereDetalhe.status = statusId;
        if (funciAtan) whereDetalhe.funci_atan = funciAtan;

        const demandas = await models.Demandas.findAll({
            where,
            include: [{
                model: models.DemandasBugDefeito,
                as: 'bugDefeito',
                required: true,
                attributes: ['status', 'funci_atan', 'estagiario_atan'],
                where: Object.keys(whereDetalhe).length > 0 ? whereDetalhe : undefined,
                include: [{
                    model: models.TipStatus,
                    as: 'statusInfo',
                    attributes: ['status']
                }]
            }],
            order: [['createdAt', 'DESC']],
            ...options
        });

        // Filtro de período (se não especificado ano/semestre)
        let resultado = demandas;
        if (!ano && !semestre && !incluirEntregues) {
            resultado = this._filtrarPorPeriodo(demandas);
        }

        return resultado.map(d => this._mapearLista(d));
    }

    // ==================== EDIÇÃO  ====================

    /**
     * Atualiza dados básicos da demanda (tabela demandas)
     * @param {number} idDemanda - ID da demanda
     * @param {Object} dados - { semestre, ano }
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<boolean>} true se atualizou
     */
    static async editarDados(idDemanda, dados, options = {}) {
        const campos = {};
        if (dados.semestre !== undefined) campos.semestre = dados.semestre || null;
        if (dados.ano !== undefined) campos.ano = dados.ano || null;

        if (Object.keys(campos).length === 0) return false;

        const [updated] = await models.Demandas.update(campos, {
            where: { id_demanda: idDemanda, tipologia: { [Op.in]: TIPOLOGIAS } },
            ...options
        });

        return updated > 0;
    }

    /**
     * Atualiza detalhes específicos de Bug/Defeito (tabela demandas_bug_defeito)
     * @param {number} idDemanda - ID da demanda
     * @param {Object} dados - { ferramenta, ferramenta_nome, status, funci_atan, estagiario_atan, estagiario_atan_aux }
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<boolean>} true se atualizou
     */
    static async editarDetalhe(idDemanda, dados, options = {}) {
        const campos = {};
        if (dados.ferramenta !== undefined) campos.ferramenta = dados.ferramenta || null;
        if (dados.ferramenta_nome !== undefined) campos.ferramenta_nome = dados.ferramenta_nome || null;
        if (dados.status !== undefined) campos.status = dados.status || null;
        if (dados.funci_atan !== undefined) campos.funci_atan = dados.funci_atan || null;
        if (dados.estagiario_atan !== undefined) campos.estagiario_atan = dados.estagiario_atan || null;
        if (dados.estagiario_atan_aux !== undefined) campos.estagiario_atan_aux = dados.estagiario_atan_aux || null;

        if (Object.keys(campos).length === 0) return false;

        const [updated] = await models.DemandasBugDefeito.update(campos, {
            where: { id_demanda: idDemanda },
            ...options
        });

        return updated > 0;
    }

    /**
     * Sincroniza motivos da demanda (N:N)
     * @param {number} idDemanda - ID da demanda
     * @param {Array<number>} motivosIds - Array de IDs dos motivos
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Object>} { removidos, adicionados }
     */
    static async sincronizarMotivos(idDemanda, motivosIds = [], options = {}) {
        // Remove todos os motivos existentes
        const removidos = await models.MotivosDemanda.destroy({
            where: { id_demanda: idDemanda },
            ...options
        });

        // Insere novos motivos
        let adicionados = 0;
        if (Array.isArray(motivosIds) && motivosIds.length > 0) {
            const registros = motivosIds
                .filter(id => id)
                .map(motivoId => ({
                    id_demanda: idDemanda,
                    motivo_id: parseInt(motivoId)
                }));

            if (registros.length > 0) {
                await models.MotivosDemanda.bulkCreate(registros, options);
                adicionados = registros.length;
            }
        }

        return { removidos, adicionados };
    }

    /**
     * Remove todos os dados relacionados a uma demanda Bug/Defeito
     * @param {number} idDemanda - ID da demanda
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<void>}
     */
    static async removerDados(idDemanda, options = {}) {
        await Promise.all([
            models.DemandasBugDefeito.destroy({ where: { id_demanda: idDemanda }, ...options }),
            models.MotivosDemanda.destroy({ where: { id_demanda: idDemanda }, ...options })
        ]);
    }

    // ==================== Métodos privados ====================

    /**
     * Filtra demandas do período atual ou anteriores não finalizadas
     * @private
     */
    static _filtrarPorPeriodo(demandas) {
        const dataAtual = new Date();
        const anoAtual = dataAtual.getFullYear();
        const semestreAtual = dataAtual.getMonth() < 6 ? 1 : 2;
        const statusFinalizados = ['Entregue', 'Cancelado'];

        return demandas.filter(d => {
            const ehPeriodoAtual = d.ano === anoAtual && parseInt(d.semestre) === semestreAtual;
            if (ehPeriodoAtual) return true;

            const statusNome = d.bugDefeito?.statusInfo?.status;
            return !statusFinalizados.includes(statusNome);
        });
    }

    /**
     * Mapeia demanda para formato completo (detalhes)
     * @private
     */
    static _mapearCompleto(d) {
        const b = d.bugDefeito || {};
        const config = CONFIG_TIPOLOGIA[d.tipologia] || {};
        const motivos = (d.motivos || []).map(m => ({ id: m.id, motivo: m.motivo }));

        return {
            id_demanda: d.id_demanda,
            nome: d.nome,
            tipologia: d.tipologia,
            numero_gd: d.numero_gd,
            semestre: d.semestre,
            ano: d.ano,

            // Ferramenta
            ferramenta_id: b.ferramenta,
            ferramenta_nome: b.ferramenta_nome,

            // Status
            status_id: b.status,
            status_nome: b.statusInfo?.status,

            // Atribuição
            funci_atan: b.funci_atan,
            estagiario_atan: b.estagiario_atan,
            estagiario_nome: b.estagiarioAtan?.nome,
            estagiario_aux_atan: b.estagiario_atan_aux,
            estagiario_aux_nome: b.estagiarioAtanAux?.nome,

            // Motivos
            motivos,
            motivos_ids: motivos.map(m => m.id),

            // Score e prioridade (calculados pela tipologia)
            score: config.score,
            prioridade_guthie: config.prioridade,
            prioridade_comite: null,

            // Precificação
            precificacao: {
                id: d.precificacao?.id || null,
                precificacao_dev_id: d.precificacao?.precificacao_dev || null,
                precificacao_dev_legenda: d.precificacao?.devInfo?.legenda || null,
                precificacao_dev_sprints: d.precificacao?.devInfo?.quant_sprints || null
            }
        };
    }

    /**
     * Mapeia demanda para formato de lista (resumido)
     * @private
     */
    static _mapearLista(d) {
        const b = d.bugDefeito || {};
        const config = CONFIG_TIPOLOGIA[d.tipologia] || {};

        return {
            id_demanda: d.id_demanda,
            nome: d.nome,
            numero_gd: d.numero_gd,
            tipologia: d.tipologia,
            semestre: d.semestre,
            ano: d.ano,
            status_id: b.status,
            status_nome: b.statusInfo?.status,
            funci_atan: b.funci_atan,
            score_guthie: config.score,
            priorizacao_guthie: config.prioridade,
            priorizacao_comite: null,
            funci_design: null,
            createdAt: d.createdAt
        };
    }
}

module.exports = BugDefeitoService;