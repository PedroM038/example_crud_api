/**
 * @file services/tags_service.js
 * @description Serviço para gerenciar tags associadas às demandas de melhoria.
 * @author Pedro e Rafaela
 */

const { models, sequelize } = require('../models/associations');

class TagsService {

    /**
     * Busca todas as tags de uma demanda (com info da tip_tags)
     * @param {number} idDemanda - ID da demanda
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Array>} Tags com informações
     */
    static async buscarPorDemanda(idDemanda, options = {}) {
        return models.Tags.findAll({
            where: { id_demanda: idDemanda },
            include: [{
                model: models.TipTags,
                as: 'tagInfo',
                attributes: ['id', 'tag']
            }],
            ...options
        });
    }

    /**
     * Sincroniza as tags de uma demanda (remove antigas, adiciona novas)
     * Usa transação para garantir atomicidade
     * @param {number} idDemanda - ID da demanda
     * @param {Array<number>} tagIds - Array de IDs das tags (tip_tags)
     * @param {string} matricula - Matrícula do usuário
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Object>} Resultado com contadores
     */
    static async sincronizar(idDemanda, tagIds = [], matricula = null, options = {}) {
        // Se já existe transação externa, usa ela; senão cria uma nova
        const transaction = options.transaction || await sequelize.transaction();
        const transacaoExterna = !!options.transaction;

        try {
            // Remove tags antigas
            const removidas = await models.Tags.destroy({
                where: { id_demanda: idDemanda },
                transaction
            });

            // Adiciona novas tags (se houver)
            let adicionadas = 0;
            if (tagIds.length > 0) {
                const registros = tagIds.map(tagId => ({
                    id_demanda: idDemanda,
                    tag: tagId,
                    matricula
                }));

                const criadas = await models.Tags.bulkCreate(registros, { transaction });
                adicionadas = criadas.length;
            }

            // Commit apenas se a transação foi criada aqui
            if (!transacaoExterna) await transaction.commit();

            return { removidas, adicionadas };

        } catch (error) {
            if (!transacaoExterna) await transaction.rollback();
            throw error;
        }
    }

    /**
     * Remove todas as tags de uma demanda
     * @param {number} idDemanda - ID da demanda
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<number>} Número de tags removidas
     */
    static async removerPorDemanda(idDemanda, options = {}) {
        return models.Tags.destroy({
            where: { id_demanda: idDemanda },
            ...options
        });
    }

    /**
     * Verifica se tags existem na tip_tags
     * @param {Array<number>} tagIds - IDs das tags para verificar
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<boolean>} true se todas existem
     */
    static async validarTagsExistem(tagIds, options = {}) {
        if (!tagIds || tagIds.length === 0) return true;
        
        const encontradas = await models.TipTags.count({
            where: { id: tagIds },
            ...options
        });

        return encontradas === tagIds.length;
    }
}

module.exports = TagsService;