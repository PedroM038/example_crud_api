/**
 * @file services/tags_service.js
 * @description responsável por gerenciar o campo de tags referente a uma demanda
 * do tipo melhoria. Cada demanda pode se associar com tags.
 */

const { Tags, TipTags, Demandas } = require('../models/associations');

const TagsService = {

    /**
     * Busca todas as tags associadas a uma demanda específica
     * @param {number} idDemanda - ID da demanda
     * @returns {array} Array com as tags da demanda e suas informações
     */
    async buscaTagsPorDemanda(idDemanda) {
        try {
            const tags = await Tags.findAll({
                where: { id_demanda: idDemanda },
                include: [
                    {
                        model: TipTags,
                        as: 'tagsInfo',
                        attributes: ['id', 'tag']
                    }
                ],
                raw: true,
                attributes: ['id_tag', 'id_demanda', 'tag', 'matricula']
            });

            if (!tags || tags.length === 0) return [];

            return tags.map(tag => ({
                id_tag: tag.id_tag,
                id_demanda: tag.id_demanda,
                tag_id: tag.tag,
                tag_nome: tag['tagsInfo.tag'],
                matricula: tag.matricula
            }));
        } catch (error) {
            throw new Error(`Erro ao buscar tags da demanda ${idDemanda}: ${error.message}`);
        }
    },

    /**
     * Atualiza todas as tags de uma demanda de uma vez
     * Remove as tags antigas e adiciona as novas
     * @param {number} idDemanda - ID da demanda
     * @param {array} novasTagIds - Array de novos IDs de tags
     * @param {string} matricula - Matrícula do usuário que está atualizando
     * @returns {object} Resultado da operação
     */
    async atualizaTagsDemanda(idDemanda, novasTagIds, matricula) {
        try {
            if (!idDemanda) throw new Error('ID da demanda é obrigatório');
            if (!Array.isArray(novasTagIds)) {
                throw new Error('novasTagIds deve ser um array');
            }

            // Verificar se a demanda existe
            const demanda = await Demandas.findByPk(idDemanda);
            if (!demanda) throw new Error(`Demanda ${idDemanda} não encontrada`);
            
            // Verificar se todas as novas tags existem
            const tagsValidas = await TipTags.findAll({
                where: { id: novasTagIds },
                attributes: ['id']
            });

            if (tagsValidas.length !== novasTagIds.length) {
                throw new Error('Uma ou mais tags fornecidas não existem');
            }

            // Remover todas as tags antigas
            const tagsRemovidas = await Tags.destroy({
                where: { id_demanda: idDemanda }
            });

            // Adicionar as novas tags
            let tagsAdicionadas = 0;
            if (novasTagIds.length > 0) {
                const insercoes = novasTagIds.map(tagId => ({
                    id_demanda: idDemanda,
                    tag: tagId,
                    matricula: matricula || null
                }));

                const resultado = await Tags.bulkCreate(insercoes);
                tagsAdicionadas = resultado.length;
            }

            return {
                sucesso: true,
                mensagem: `Tags atualizadas: ${tagsRemovidas} removida(s), ${tagsAdicionadas} adicionada(s)`,
                tagsRemovidas: tagsRemovidas,
                tagsAdicionadas: tagsAdicionadas
            };
        } catch (error) {
            throw new Error(`Erro ao atualizar tags da demanda ${idDemanda}: ${error.message}`);
        }
    },
};

module.exports = TagsService;