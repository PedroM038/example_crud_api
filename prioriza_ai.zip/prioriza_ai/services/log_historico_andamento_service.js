/**
 * @file services/log_historico_andamento_service.js
 * @description Serviço para gerenciar histórico de ações nas fases e etapas.
 * @author Pedro e Rafaela
 */

const { models } = require('../models/associations');

class LogHistoricoAndamentoService {

    /**
     * Registra uma ação no histórico de andamento
     * @param {Object} dados - Dados do registro
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Object>} Registro criado
     */
    static async registrar(dados, options = {}) {
        return models.LogHistoricoAndamento.create({
            id_demanda: dados.idDemanda,
            acao: dados.acao,
            usuario: dados.usuario,
            etapa: dados.etapa || null,
            fase: dados.fase || null
        }, options);
    }

    /**
     * Busca histórico com filtros opcionais
     * @param {Object} filtros - Filtros opcionais (etapa, acao, idDemanda)
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Array>} Lista de registros
     */
    static async buscar(filtros = {}, options = {}) {
        const where = {};
        
        if (filtros.etapa) where.etapa = filtros.etapa;
        if (filtros.acao) where.acao = filtros.acao;
        if (filtros.idDemanda) where.id_demanda = filtros.idDemanda;

        return models.LogHistoricoAndamento.findAll({
            where,
            order: [['createdAt', 'DESC']],
            ...options
        });
    }

    /**
     * Busca todo o histórico
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Array>} Lista de todos os registros
     */
    static async buscarTodos(options = {}) {
        return models.LogHistoricoAndamento.findAll({
            order: [['createdAt', 'DESC']],
            ...options
        });
    }
}

module.exports = LogHistoricoAndamentoService;
