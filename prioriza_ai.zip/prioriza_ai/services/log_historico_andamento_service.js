/**
 * @file services/log_historico_andamento_service.js
 * @description Serviço para gerenciar as operações relacionadas ao histórico 
 * de ações nas fases e etapas. Inclui registro de ações como criação, edição e exclusão.
 */

const { LogHistoricoAndamento } = require('../models/associations');

class LogHistoricoAndamentoService {

    /**
     * Registra uma nova ação no histórico de andamento
     * @param {number} id_demanda - ID da demanda
     * @param {string} acao - Ação realizada (criacao, edicao, exclusao)
     * @param {string} usuario - Matrícula ou nome do usuário
     * @param {string} etapa - Valor da etapa no momento da ação
     * @param {string} fase - Valor da fase no momento da ação
     * @returns {object} Registro criado
     */
    static async registraAcao(id_demanda, acao, usuario, etapa, fase) {
        try {
            const novoRegistro = await LogHistoricoAndamento.create({
                id_demanda,
                acao,
                usuario,
                etapa,
                fase
            });
            return novoRegistro;
        } catch (error) {
            console.error("Erro ao registrar ação no histórico de andamento:", error);
            throw new Error("Erro ao registrar ação no histórico de andamento");
        }
    }

    /**
     * Busca todo o histórico de andamento
     * @returns {array} Array com todos os registros de histórico
     */
    static async buscaTodoHistorico() {
        try {
            const historico = await LogHistoricoAndamento.findAll({
                order: [['createdAt', 'DESC']]
            });
            return historico;
        } catch (error) {
            console.error("Erro ao buscar histórico de andamento:", error);
            throw new Error("Erro ao buscar histórico de andamento");
        }
    }

    /**
     * Busca histórico por etapa específica
     * @param {string} etapa - Nome da etapa
     * @returns {array} Array com registros de histórico da etapa
     */
    static async buscaHistoricoPorEtapa(etapa) {
        try {
            const historico = await LogHistoricoAndamento.findAll({
                where: { etapa },
                order: [['createdAt', 'DESC']]
            });
            return historico;
        } catch (error) {
            console.error("Erro ao buscar histórico por etapa:", error);
            throw new Error("Erro ao buscar histórico por etapa");
        }
    }

    /**
     * Busca histórico por tipo de ação
     * @param {string} acao - Tipo de ação (criacao, edicao, exclusao)
     * @returns {array} Array com registros de histórico da ação
     */
    static async buscaHistoricoPorAcao(acao) {
        try {
            const historico = await LogHistoricoAndamento.findAll({
                where: { acao },
                order: [['createdAt', 'DESC']]
            });
            return historico;
        } catch (error) {
            console.error("Erro ao buscar histórico por ação:", error);
            throw new Error("Erro ao buscar histórico por ação");
        }
    }
}

module.exports = LogHistoricoAndamentoService;
