const { models } = require('../models/associations');

class TipPrecificacaoDevService {

    static async buscarTodas(options = {}) {
        return models.TipPrecificacaoDev.findAll({
            attributes: ['id', 'legenda', 'quant_sprints'],
            order: [['id', 'ASC']],
            ...options
        });
    }

    static async buscarPorId(id, options = {}) {
        return models.TipPrecificacaoDev.findByPk(id, {
            attributes: ['id', 'legenda', 'quant_sprints'],
            ...options
        });
    }

    static async criar(data, options = {}) {
        return models.TipPrecificacaoDev.create(data, options);
    }

    static async atualizar(id, data, options = {}) {
        const [updated] = await models.TipPrecificacaoDev.update(data, {
            where: { id },
            ...options
        });
        if (!updated) throw new Error('Precificação Dev não encontrada');
        return models.TipPrecificacaoDev.findByPk(id, options);
    }
}

module.exports = TipPrecificacaoDevService;
