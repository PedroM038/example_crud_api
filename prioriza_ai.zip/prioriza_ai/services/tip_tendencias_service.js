const { models } = require('../models/associations');

class TipTendenciasService {

    static async buscarTodas(options = {}) {
        return models.TipTendencias.findAll({
            attributes: ['id', 'peso', 'pontos', 'legenda'],
            order: [['peso', 'ASC']],
            ...options
        });
    }

    static async criar(data, options = {}) {
        return models.TipTendencias.create(data, options);
    }

    static async atualizar(id, data, options = {}) {
        const [updated] = await models.TipTendencias.update(data, {
            where: { id },
            ...options
        });
        if (!updated) throw new Error('Tendência não encontrada');
        return models.TipTendencias.findByPk(id, options);
    }
}

module.exports = TipTendenciasService;