/**
 * @file services/tendenciaService.js
 * @description Service para operações relacionadas as tendencias.
 * @author Pedro e Rafaela
 */

const tip_tendencias = require('../models/tip_tendencias');
class tip_tendencias_service {
    
    static async buscaTodasTendencias() {
        try {
            const tendencias = await tip_tendencias.findAll({
                attributes: ['id','peso', 'pontos', 'legenda'],
                order: [['peso', 'ASC']]
            });
            return tendencias;
        } catch (error) {
            console.error("Erro ao buscar tendencias:", error);
            throw new Error("Erro ao buscar tendencias");
        }
    }

    static async criaTendencia(tendenciaData) {
        try {
            const novaTendencia = await tip_tendencias.create(tendenciaData);
            return novaTendencia;
        } catch (error) {
            console.error("Erro ao criar tendencia:", error);
            throw new Error("Erro ao criar tendencia");
        }
    }

    static async atualizaTendencia(id, tendenciaData) {
        try {
            const [updated] = await tip_tendencias.update(tendenciaData, {
                where: { id: id }
            });
            if (updated) {
                const updatedTendencia = await tip_tendencias.findByPk(id);
                return updatedTendencia;
            }
            throw new Error("Tendencia não encontrada");
        } catch (error) {
            console.error("Erro ao atualizar tendencia:", error);
            throw new Error("Erro ao atualizar tendencia");
        }
    }
}

module.exports = tip_tendencias_service;