/**
 * @file services/precificacao_service.js
 * @description Gerencia a precificação (sprints dev/design) das demandas.
 */

const { models } = require('../models/associations');

class PrecificacaoService {

    /**
     * Busca precificação de uma demanda com detalhes de dev e design
     */
    static async buscarPorDemanda(idDemanda, options = {}) {
        return models.Precificacao.findOne({
            where: { id_demanda: idDemanda },
            include: [
                {
                    model: models.TipPrecificacaoDev,
                    as: 'devInfo',
                    attributes: ['id', 'legenda', 'quant_sprints']
                },
                {
                    model: models.TipPrecificacaoDesign,
                    as: 'designInfo',
                    attributes: ['id', 'legenda', 'quant_sprints']
                }
            ],
            ...options
        });
    }

    /**
     * Cria ou atualiza precificação de uma demanda (upsert)
     */
    static async salvar(idDemanda, dados, options = {}) {
        const { precificacao_dev_id, precificacao_design_id } = dados;

        const [precificacao, created] = await models.Precificacao.findOrCreate({
            where: { id_demanda: idDemanda },
            defaults: {
                id_demanda: idDemanda,
                precificacao_dev: precificacao_dev_id || null,
                precificacao_design: precificacao_design_id || null
            },
            ...options
        });

        if (!created) {
            await precificacao.update({
                precificacao_dev: precificacao_dev_id || null,
                precificacao_design: precificacao_design_id || null
            }, options);
        }

        return precificacao;
    }

    /**
     * Remove precificação de uma demanda
     */
    static async removerPorDemanda(idDemanda, options = {}) {
        const deleted = await models.Precificacao.destroy({
            where: { id_demanda: idDemanda },
            ...options
        });
        return deleted > 0;
    }
}

module.exports = PrecificacaoService;
