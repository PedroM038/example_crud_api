/**
 * @file services/precificacaoService.js
 * @description Service responsável por gerenciar precificação das demandas
 * @author Pedro e Rafaela
 */

const { Precificacao, PrecificacaoDev, PrecificacaoDesign } = require('../models/associations');

const PrecificacaoService = {

    /**
     * Busca todas as opções de precificação Dev
     * @returns {Promise<Array>}
     */
    async buscaTodasPrecificacoesDev() {
        const precificacoes = await PrecificacaoDev.findAll({
            attributes: ['id', 'legenda', 'quant_sprints'],
            order: [['id', 'ASC']]
        });

        return precificacoes.map(p => ({
            id: p.id,
            legenda: p.legenda,
            quant_sprints: p.quant_sprints
        }));
    },

    /**
     * Busca todas as opções de precificação Design
     * @returns {Promise<Array>}
     */
    async buscaTodasPrecificacoesDesign() {
        const precificacoes = await PrecificacaoDesign.findAll({
            attributes: ['id', 'legenda', 'quant_sprints'],
            order: [['id', 'ASC']]
        });

        return precificacoes.map(p => ({
            id: p.id,
            legenda: p.legenda,
            quant_sprints: p.quant_sprints
        }));
    },

    /**
     * Busca precificação de uma demanda específica
     * @param {number} idDemanda
     * @returns {Promise<Object|null>}
     */
    async buscaPrecificacaoPorDemanda(idDemanda) {
        const precificacao = await Precificacao.findOne({
            where: { id_demanda: idDemanda },
            include: [
                {
                    model: PrecificacaoDev,
                    as: 'precificacaoDevInfo',
                    attributes: ['id', 'legenda', 'quant_sprints']
                },
                {
                    model: PrecificacaoDesign,
                    as: 'precificacaoDesignInfo',
                    attributes: ['id', 'legenda', 'quant_sprints']
                }
            ]
        });

        if (!precificacao) return null;

        return {
            id: precificacao.id,
            id_demanda: precificacao.id_demanda,
            precificacao_dev_id: precificacao.precificacao_dev,
            precificacao_dev_legenda: precificacao.precificacaoDevInfo?.legenda || null,
            precificacao_dev_sprints: precificacao.precificacaoDevInfo?.quant_sprints || null,
            precificacao_design_id: precificacao.precificacao_design,
            precificacao_design_legenda: precificacao.precificacaoDesignInfo?.legenda || null,
            precificacao_design_sprints: precificacao.precificacaoDesignInfo?.quant_sprints || null
        };
    },

    /**
     * Cria ou atualiza precificação de uma demanda
     * @param {number} idDemanda
     * @param {Object} dados - Objeto com precificacao_dev_id e precificacao_design_id
     * @param {Object} transaction - Transação Sequelize opcional
     * @returns {Promise<Object>}
     */
    async atualizaPrecificacaoDemanda(idDemanda, dados, transaction = null) {
        const { precificacao_dev_id, precificacao_design_id } = dados;

        // Verificar se já existe registro de precificação para esta demanda
        let precificacao = await Precificacao.findOne({
            where: { id_demanda: idDemanda },
            transaction
        });

        const precificacaoData = {
            precificacao_dev: precificacao_dev_id || null,
            precificacao_design: precificacao_design_id || null
        };

        if (precificacao) {
            // Atualizar registro existente
            await precificacao.update(precificacaoData, { transaction });
        } else {
            // Criar novo registro
            precificacaoData.id_demanda = idDemanda;
            precificacao = await Precificacao.create(precificacaoData, { transaction });
        }

        return precificacao;
    },

    /**
     * Remove precificação de uma demanda
     * @param {number} idDemanda
     * @param {Object} transaction - Transação Sequelize opcional
     * @returns {Promise<number>}
     */
    async removePrecificacaoPorDemanda(idDemanda, transaction = null) {
        return await Precificacao.destroy({
            where: { id_demanda: idDemanda },
            transaction
        });
    }
};

module.exports = PrecificacaoService;
