/**
 * @file services/andamento_service.js
 * @description Serviço para gerenciar andamento das demandas (fases e etapas).
 * @author Pedro e Rafaela
 */

const { models, sequelize } = require('../models/associations');
const LogHistoricoAndamentoService = require('./log_historico_andamento_service');

// Include padrão para consultas com informações de fase/etapa
const INCLUDE_FASE_ETAPA = [{
    model: models.TipFasesEtapas,
    as: 'faseEtapaInfo',
    attributes: ['id', 'etapa', 'fase', 'percentual']
}];

class AndamentoService {

    /**
     * Busca todos os andamentos de uma demanda
     * @param {number} idDemanda - ID da demanda
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Array>} Andamentos ordenados por data
     */
    static async buscarPorDemanda(idDemanda, options = {}) {
        return models.Andamento.findAll({
            where: { id_demanda: idDemanda },
            include: INCLUDE_FASE_ETAPA,
            order: [['createdAt', 'ASC']],
            ...options
        });
    }

    /**
     * Busca um andamento por ID
     * @param {number} id - ID do andamento
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Object|null>} Andamento ou null
     */
    static async buscarPorId(id, options = {}) {
        return models.Andamento.findByPk(id, {
            include: INCLUDE_FASE_ETAPA,
            ...options
        });
    }

    /**
     * Verifica se uma fase/etapa já existe para uma demanda
     * @param {number} idDemanda - ID da demanda
     * @param {number} faseEtapa - ID da fase/etapa
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<boolean>} true se já existe
     */
    static async existeFaseEtapa(idDemanda, faseEtapa, options = {}) {
        const count = await models.Andamento.count({
            where: { id_demanda: idDemanda, fase_etapa: faseEtapa },
            ...options
        });
        return count > 0;
    }

    /**
     * Adiciona um andamento
     * @param {Object} dados - { idDemanda, faseEtapa, matricula }
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Object>} Andamento criado
     */
    static async adicionar(dados, options = {}) {
        const andamento = await models.Andamento.create({
            id_demanda: dados.idDemanda,
            fase_etapa: dados.faseEtapa,
            matricula: dados.matricula
        }, options);

        // Registra no histórico (não bloqueia, mas em mesma transação se houver)
        await this._registrarHistorico(dados.idDemanda, 'criacao', dados.matricula, dados.faseEtapa, options);

        return andamento;
    }

    /**
     * Atualiza um andamento
     * @param {number} id - ID do andamento
     * @param {Object} dados - { faseEtapa, matricula }
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Object|null>} Andamento atualizado ou null
     */
    static async atualizar(id, dados, options = {}) {
        const andamento = await models.Andamento.findByPk(id, options);
        if (!andamento) return null;

        await andamento.update({
            fase_etapa: dados.faseEtapa,
            matricula: dados.matricula
        }, options);

        // Registra no histórico
        await this._registrarHistorico(andamento.id_demanda, 'edicao', dados.matricula, dados.faseEtapa, options);

        return andamento;
    }

    /**
     * Remove um andamento
     * @param {number} id - ID do andamento
     * @param {string} matricula - Matrícula de quem está removendo
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<boolean>} true se removido
     */
    static async remover(id, matricula, options = {}) {
        const andamento = await models.Andamento.findByPk(id, {
            include: INCLUDE_FASE_ETAPA,
            ...options
        });
        if (!andamento) return false;

        const idDemanda = andamento.id_demanda;
        const etapa = andamento.faseEtapaInfo?.etapa || '';
        const fase = andamento.faseEtapaInfo?.fase || '';

        await andamento.destroy(options);

        // Registra no histórico (com dados já obtidos)
        await LogHistoricoAndamentoService.registrar({
            idDemanda,
            acao: 'exclusao',
            usuario: matricula,
            etapa,
            fase
        }, options);

        return true;
    }

    /**
     * Sincroniza andamentos de uma demanda (adiciona novos, remove desmarcados)
     * Usa transação para garantir atomicidade
     * @param {number} idDemanda - ID da demanda
     * @param {Array<number>} fasesMarcadas - IDs das fases que devem estar marcadas
     * @param {string} matricula - Matrícula do usuário
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Object>} Resumo { adicionados, removidos, total }
     */
    static async sincronizar(idDemanda, fasesMarcadas = [], matricula, options = {}) {
        const transaction = options.transaction || await sequelize.transaction();
        const transacaoExterna = !!options.transaction;

        try {
            // Busca andamentos atuais
            const atuais = await models.Andamento.findAll({
                where: { id_demanda: idDemanda },
                include: INCLUDE_FASE_ETAPA,
                transaction
            });

            const idsAtuais = atuais.map(a => a.fase_etapa);
            const idsMarcados = fasesMarcadas.map(id => parseInt(id));

            const paraAdicionar = idsMarcados.filter(id => !idsAtuais.includes(id));
            const paraRemover = atuais.filter(a => !idsMarcados.includes(a.fase_etapa));

            // Adiciona novos
            for (const faseEtapa of paraAdicionar) {
                await models.Andamento.create({
                    id_demanda: idDemanda,
                    fase_etapa: faseEtapa,
                    matricula
                }, { transaction });

                await this._registrarHistorico(idDemanda, 'criacao', matricula, faseEtapa, { transaction });
            }

            // Remove desmarcados
            for (const andamento of paraRemover) {
                const etapa = andamento.faseEtapaInfo?.etapa || '';
                const fase = andamento.faseEtapaInfo?.fase || '';

                await andamento.destroy({ transaction });

                await LogHistoricoAndamentoService.registrar({
                    idDemanda,
                    acao: 'exclusao',
                    usuario: matricula,
                    etapa,
                    fase
                }, { transaction });
            }

            if (!transacaoExterna) await transaction.commit();

            return {
                adicionados: paraAdicionar.length,
                removidos: paraRemover.length,
                total: idsMarcados.length
            };

        } catch (error) {
            if (!transacaoExterna) await transaction.rollback();
            throw error;
        }
    }

    /**
     * Remove todos os andamentos de uma demanda
     * @param {number} idDemanda - ID da demanda
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<number>} Número de registros removidos
     */
    static async removerPorDemanda(idDemanda, options = {}) {
        return models.Andamento.destroy({
            where: { id_demanda: idDemanda },
            ...options
        });
    }

    /**
     * Calcula o percentual de progresso de uma demanda
     * @param {number} idDemanda - ID da demanda
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<number>} Percentual (0-100)
     */
    static async calcularProgresso(idDemanda, options = {}) {
        const andamentos = await this.buscarPorDemanda(idDemanda, options);
        
        if (andamentos.length === 0) return 0;

        const total = andamentos.reduce((acc, a) => {
            return acc + parseFloat(a.faseEtapaInfo?.percentual || 0);
        }, 0);

        return Math.min(total, 100);
    }

    /**
     * Registra ação no histórico (método privado auxiliar)
     * @private
     */
    static async _registrarHistorico(idDemanda, acao, matricula, faseEtapa, options = {}) {
        const faseInfo = await models.TipFasesEtapas.findByPk(faseEtapa, options);
        
        await LogHistoricoAndamentoService.registrar({
            idDemanda,
            acao,
            usuario: matricula,
            etapa: faseInfo?.etapa || '',
            fase: faseInfo?.fase || ''
        }, options);
    }
}

module.exports = AndamentoService;
