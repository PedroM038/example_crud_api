/**
 * @file services/andamento_service.js
 * @description Serviço para gerenciar as operações relacionadas ao andamento das demandas.
 * Permite adicionar, editar, remover e consultar o progresso das demandas através
 * das fases e etapas.
 */

const { Andamento, tip_fases_etapas } = require('../models/associations');
const LogHistoricoAndamentoService = require('./log_historico_andamento_service');

const AndamentoService = {

    /**
     * Adiciona um novo registro de andamento para uma demanda
     * @param {number} id_demanda - ID da demanda
     * @param {number} fase_etapa - ID da fase/etapa
     * @param {string} matricula - Matrícula do usuário que está adicionando
     * @returns {object} Registro de andamento criado
     */
    async adicionaAndamento(id_demanda, fase_etapa, matricula) {
        try {
            const novoAndamento = await Andamento.create({
                id_demanda,
                fase_etapa,
                matricula
            });

            // Busca dados da fase/etapa para o log
            const faseEtapaInfo = await tip_fases_etapas.findByPk(fase_etapa);
            
            // Registra no histórico de forma assíncrona
            setImmediate(async () => {
                try {
                    await LogHistoricoAndamentoService.registraAcao(
                        id_demanda,
                        'criacao',
                        matricula,
                        faseEtapaInfo?.etapa || '',
                        faseEtapaInfo?.fase || ''
                    );
                } catch (err) {
                    console.error("Erro ao registrar histórico de andamento (background):", err);
                }
            });

            return novoAndamento;
        } catch (error) {
            console.error("Erro ao adicionar andamento:", error);
            throw new Error(`Erro ao adicionar andamento: ${error.message}`);
        }
    },

    /**
     * Edita um registro de andamento existente
     * @param {number} id - ID do registro de andamento
     * @param {number} fase_etapa - Novo ID da fase/etapa
     * @param {string} matricula - Matrícula do usuário que está editando
     * @returns {object} Registro de andamento atualizado
     */
    async editaAndamento(id, fase_etapa, matricula) {
        try {
            const andamento = await Andamento.findByPk(id);
            
            if (!andamento) {
                throw new Error("Registro de andamento não encontrado");
            }

            await andamento.update({
                fase_etapa,
                matricula
            });

            // Busca dados da fase/etapa para o log
            const faseEtapaInfo = await tip_fases_etapas.findByPk(fase_etapa);
            
            // Registra no histórico de forma assíncrona
            setImmediate(async () => {
                try {
                    await LogHistoricoAndamentoService.registraAcao(
                        id_demanda,
                        'edicao',
                        matricula,
                        faseEtapaInfo?.etapa || '',
                        faseEtapaInfo?.fase || ''
                    );
                } catch (err) {
                    console.error("Erro ao registrar histórico de andamento (background):", err);
                }
            });

            return andamento;
        } catch (error) {
            console.error("Erro ao editar andamento:", error);
            throw new Error(`Erro ao editar andamento: ${error.message}`);
        }
    },

    /**
     * Remove um registro de andamento
     * @param {number} id - ID do registro de andamento
     * @param {number} id_demanda - ID da demanda
     * @param {string} matricula - Matrícula do usuário que está removendo
     * @returns {boolean} True se removido com sucesso
     */
    async removeAndamento(id, id_demanda, matricula) {
        try {
            const andamento = await Andamento.findByPk(id, {
                include: [{
                    model: tip_fases_etapas,
                    as: 'andamentoInfo'
                }]
            });
            
            if (!andamento) {
                throw new Error("Registro de andamento não encontrado");
            }

            const etapa = andamento.andamentoInfo?.etapa || '';
            const fase = andamento.andamentoInfo?.fase || '';

            await andamento.destroy();

            // Registra no histórico de forma assíncrona
            setImmediate(async () => {
                try {
                    await LogHistoricoAndamentoService.registraAcao(
                        id_demanda,
                        'exclusao',
                        matricula,
                        etapa,
                        fase
                    );
                } catch (err) {
                    console.error("Erro ao registrar histórico de andamento (background):", err);
                }
            });

            return true;
        } catch (error) {
            console.error("Erro ao remover andamento:", error);
            throw new Error(`Erro ao remover andamento: ${error.message}`);
        }
    },

    /**
     * Busca todos os andamentos de uma demanda específica
     * @param {number} id_demanda - ID da demanda
     * @returns {array} Array com todos os andamentos da demanda
     */
    async buscaAndamentosPorDemanda(id_demanda) {
        try {
            const andamentos = await Andamento.findAll({
                where: { id_demanda },
                include: [{
                    model: tip_fases_etapas,
                    as: 'andamentoInfo',
                    attributes: ['id', 'etapa', 'fase', 'percentual']
                }],
                order: [['createdAt', 'ASC']]
            });

            return andamentos;
        } catch (error) {
            console.error("Erro ao buscar andamentos por demanda:", error);
            throw new Error(`Erro ao buscar andamentos: ${error.message}`);
        }
    },

    /**
     * Busca um andamento específico pelo ID
     * @param {number} id - ID do andamento
     * @returns {object} Registro de andamento
     */
    async buscaAndamentoPorId(id) {
        try {
            const andamento = await Andamento.findByPk(id, {
                include: [{
                    model: tip_fases_etapas,
                    as: 'andamentoInfo',
                    attributes: ['id', 'etapa', 'fase', 'percentual']
                }]
            });

            return andamento;
        } catch (error) {
            console.error("Erro ao buscar andamento por ID:", error);
            throw new Error(`Erro ao buscar andamento: ${error.message}`);
        }
    },

    /**
     * Calcula o percentual total de progresso de uma demanda
     * com base nos andamentos registrados
     * @param {number} id_demanda - ID da demanda
     * @returns {number} Percentual total de progresso
     */
    async calculaProgressoDemanda(id_demanda) {
        try {
            const andamentos = await this.buscaAndamentosPorDemanda(id_demanda);
            
            if (!andamentos || andamentos.length === 0) {
                return 0;
            }

            // Soma os percentuais de todas as fases/etapas
            const totalPercentual = andamentos.reduce((acc, andamento) => {
                const percentual = parseFloat(andamento.andamentoInfo?.percentual || 0);
                return acc + percentual;
            }, 0);

            // Limita a 100%
            return Math.min(totalPercentual, 100);
        } catch (error) {
            console.error("Erro ao calcular progresso da demanda:", error);
            throw new Error(`Erro ao calcular progresso: ${error.message}`);
        }
    },

    /**
     * Verifica se uma fase/etapa já foi adicionada para uma demanda
     * @param {number} id_demanda - ID da demanda
     * @param {number} fase_etapa - ID da fase/etapa
     * @returns {boolean} True se já existe
     */
    async verificaFaseEtapaExistente(id_demanda, fase_etapa) {
        try {
            const existe = await Andamento.findOne({
                where: { 
                    id_demanda,
                    fase_etapa 
                }
            });

            return !!existe;
        } catch (error) {
            console.error("Erro ao verificar fase/etapa existente:", error);
            throw new Error(`Erro ao verificar fase/etapa: ${error.message}`);
        }
    },

    /**
     * Sincroniza os andamentos de uma demanda com base em um array de fases/etapas marcadas.
     * Adiciona os novos e remove os desmarcados.
     * Ideal para operações em massa no front-end (checkboxes).
     * @param {number} id_demanda - ID da demanda
     * @param {array} fasesEtapasMarcadas - Array de IDs das fases/etapas que devem estar marcadas
     * @param {string} matricula - Matrícula do usuário que está realizando a operação
     * @returns {object} Objeto com resumo das operações realizadas
     */
    async sincronizaAndamentos(id_demanda, fasesEtapasMarcadas, matricula) {
        try {
            // Busca andamentos atuais da demanda
            const andamentosAtuais = await Andamento.findAll({
                where: { id_demanda },
                include: [{
                    model: tip_fases_etapas,
                    as: 'andamentoInfo',
                    attributes: ['id', 'etapa', 'fase']
                }]
            });

            const idsAtuais = andamentosAtuais.map(a => a.fase_etapa);
            const idsMarcados = fasesEtapasMarcadas.map(id => parseInt(id));

            // Determina o que adicionar e o que remover
            const idsParaAdicionar = idsMarcados.filter(id => !idsAtuais.includes(id));
            const idsParaRemover = idsAtuais.filter(id => !idsMarcados.includes(id));

            const adicionados = [];
            const removidos = [];

            // Adiciona novos andamentos
            for (const fase_etapa of idsParaAdicionar) {
                const novo = await Andamento.create({
                    id_demanda,
                    fase_etapa,
                    matricula
                });
                adicionados.push(novo);
            }

            // Remove andamentos desmarcados
            for (const fase_etapa of idsParaRemover) {
                const andamento = andamentosAtuais.find(a => a.fase_etapa === fase_etapa);
                if (andamento) {
                    await andamento.destroy();
                    removidos.push({
                        fase_etapa,
                        etapa: andamento.andamentoInfo?.etapa,
                        fase: andamento.andamentoInfo?.fase
                    });
                }
            }

            // Registra no histórico de forma assíncrona
            setImmediate(async () => {
                try {
                    // Log para adições
                    for (const add of adicionados) {
                        const info = await tip_fases_etapas.findByPk(add.fase_etapa);
                        await LogHistoricoAndamentoService.registraAcao(
                            id_demanda,
                            'criacao',
                            matricula,
                            info?.etapa || '',
                            info?.fase || ''
                        );
                    }
                    // Log para remoções
                    for (const rem of removidos) {
                        await LogHistoricoAndamentoService.registraAcao(
                            id_demanda,
                            'exclusao',
                            matricula,
                            rem.etapa || '',
                            rem.fase || ''
                        );
                    }
                } catch (err) {
                    console.error("Erro ao registrar histórico de andamento (background):", err);
                }
            });

            return {
                adicionados: adicionados.length,
                removidos: removidos.length,
                totalAtual: idsMarcados.length
            };
        } catch (error) {
            console.error("Erro ao sincronizar andamentos:", error);
            throw new Error(`Erro ao sincronizar andamentos: ${error.message}`);
        }
    }
};

module.exports = AndamentoService;
