const { models } = require('../models/associations');

class TipTemposService {

    static async buscarTodos(options = {}) {
        return models.TipTempos.findAll({
            attributes: ['id', 'tempo', 'tempo_freq', 'calc_tempo'],
            order: [['calc_tempo', 'ASC']],
            ...options
        });
    }

    static async criar(data, options = {}) {
        return models.TipTempos.create(data, options);
    }

    static async atualizar(id, data, options = {}) {
        const [updated] = await models.TipTempos.update(data, {
            where: { id },
            ...options
        });
        if (!updated) throw new Error('Tempo não encontrado');
        return models.TipTempos.findByPk(id, options);
    }
}

module.exports = TipTemposService;