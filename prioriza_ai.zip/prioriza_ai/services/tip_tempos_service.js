const tip_tempos = require('../models/tip_tempos');

class tip_tempos_service {
    
    static async buscaTodosTempos() {
        try {
            const tempos = await tip_tempos.findAll({
                attributes: ['id', 'tempo', 'tempo_freq', 'calc_tempo'],
                order: [['calc_tempo', 'ASC']]
            });
            return tempos;
        } catch (error) {
            console.error("Erro ao buscar tempos:", error);
            throw new Error("Erro ao buscar tempos");
        }
    }
    
    static async criaTempo(tempoData) {
        try {
            const novoTempo = await tip_tempos.create(tempoData);
            return novoTempo;
        } catch (error) {
            console.error("Erro ao criar tempo:", error);
            throw new Error("Erro ao criar tempo");
        }
    }

    static async atualizaTempo(id, tempoData) {
        try {
            const [updated] = await tip_tempos.update(tempoData, {
                where: { id: id }
            });
            if (updated) {
                const updatedTempo = await tip_tempos.findByPk(id);
                return updatedTempo;
            }
            throw new Error("Tip Tempo não encontrado");
        } catch (error) {
            console.error("Erro ao atualizar tempo:", error);
            throw new Error("Erro ao atualizar tempo");
        }
    }
}

module.exports = tip_tempos_service;