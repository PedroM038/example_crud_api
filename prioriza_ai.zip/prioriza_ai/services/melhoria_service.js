/**
 * @file services/melhoria_service.js
 * @description Serviço para gerenciar demandas do tipo Melhoria.
 * @author Pedro e Rafaela
 */

const { Op } = require('sequelize');
const { models } = require('../models/associations');

// Services auxiliares (apenas para busca e remoção)
const TagsService = require('./tags_service');
const AndamentoService = require('./andamento_service');
const MatrizGuthieService = require('./matriz_guthie_service');
const HorasFteService = require('./horas_fte_service');
const ResponsaveisMelhoriaService = require('./responsaveis_service');

// Tipologia
const TIPOLOGIA = 'Melhoria';

// Includes reutilizáveis
const INCLUDES = {
    // Include para listagem (mínimo necessário)
    lista: [{
        model: models.DemandasMelhoria,
        as: 'melhoria',
        required: true,
        attributes: ['status', 'priorizacao_comite'],
        include: [{
            model: models.TipStatus,
            as: 'statusInfo',
            attributes: ['status']
        }, {
            model: models.MatrizGuthie,
            as: 'guthieInfo',
            required: false,
            attributes: ['score', 'priorizacao_guthie']
        }]
    }, {
        model: models.ResponsaveisMelhoria,
        as: 'responsaveis',
        required: false,
        attributes: ['funci_atan', 'funci_design']
    }],

    // Include completo para detalhes
    completo: [{
        model: models.DemandasMelhoria,
        as: 'melhoria',
        required: true,
        include: [
            { model: models.TipAreas, as: 'areaInfo', attributes: ['area'] },
            { model: models.TipIndicadores, as: 'indicadorInfo', attributes: ['indicador'] },
            { model: models.TipInviabilidades, as: 'inviabilidadeInfo', attributes: ['inviabilidade'] },
            { model: models.TipStatus, as: 'statusInfo', attributes: ['status'] },
            {
                model: models.MatrizGuthie,
                as: 'guthieInfo',
                required: false,
                include: [
                    { model: models.TipGravidades, as: 'gravidadeInfo', attributes: ['id', 'pontos', 'peso', 'legenda'] },
                    { model: models.TipHorasEconomizadas, as: 'horasEconomizadasInfo', attributes: ['id', 'pontos', 'peso', 'legenda'] },
                    { model: models.TipImpactos, as: 'impactoInfo', attributes: ['id', 'pontos', 'peso', 'legenda'] },
                    { model: models.TipTendencias, as: 'tendenciaInfo', attributes: ['id', 'pontos', 'peso', 'legenda'] },
                    { model: models.TipUrgencias, as: 'urgenciaInfo', attributes: ['id', 'pontos', 'peso', 'legenda'] },
                    { model: models.TipExperiencias, as: 'experienciaInfo', attributes: ['id', 'pontos', 'peso', 'legenda'] }
                ]
            },
            {
                model: models.HorasFte,
                as: 'horasFTEInfo',
                required: false,
                include: [
                    { model: models.TipTempos, as: 'tempoInfo', attributes: ['id', 'tempo', 'tempo_freq', 'calc_tempo'] },
                    { model: models.TipRepeticoes, as: 'repeticaoInfo', attributes: ['id', 'repeticao', 'repeticao_freq', 'calc_repeticao'] }
                ]
            }
        ]
    }, {
        model: models.ResponsaveisMelhoria,
        as: 'responsaveis',
        required: false,
        include: [
            { model: models.TipEstagiarios, as: 'estagiarioAtan', attributes: ['id', 'nome', 'matricula'] },
            { model: models.TipEstagiarios, as: 'estagiarioDesign', attributes: ['id', 'nome', 'matricula'] },
            { model: models.TipEstagiarios, as: 'estagiarioAtanAux', attributes: ['id', 'nome', 'matricula'] },
            { model: models.TipEstagiarios, as: 'estagiarioDesignAux', attributes: ['id', 'nome', 'matricula'] }
        ]
    }, {
        model: models.Precificacao,
        as: 'precificacao',
        required: false,
        include: [
            { model: models.TipPrecificacaoDev, as: 'devInfo', attributes: ['id', 'legenda', 'quant_sprints'] },
            { model: models.TipPrecificacaoDesign, as: 'designInfo', attributes: ['id', 'legenda', 'quant_sprints'] }
        ]
    }]
};

class MelhoriaService {

    /**
     * Verifica se a tipologia é Melhoria
     * @param {string} tipologia
     * @returns {boolean}
     */
    static ehTipologiaValida(tipologia) {
        return tipologia === TIPOLOGIA;
    }

    /**
     * Busca uma demanda por ID (com todos os dados relacionados)
     * @param {number} idDemanda - ID da demanda
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Object|null>} Demanda mapeada ou null
     */
    static async buscarPorId(idDemanda, options = {}) {
        const demanda = await models.Demandas.findOne({
            where: { id_demanda: idDemanda, tipologia: TIPOLOGIA },
            include: INCLUDES.completo,
            ...options
        });

        if (!demanda) return null;

        // Buscar dados complementares em paralelo
        const [tags, andamentos, progresso] = await Promise.all([
            TagsService.buscarPorDemanda(idDemanda, options),
            AndamentoService.buscarPorDemanda(idDemanda, options),
            AndamentoService.calcularProgresso(idDemanda, options)
        ]);

        return this._mapearCompleto(demanda, { tags, andamentos, progresso });
    }

    /**
     * Busca todas as demandas com filtros opcionais
     * @param {Object} filtros - Filtros opcionais
     * @param {number} filtros.ano - Ano específico
     * @param {number} filtros.semestre - Semestre específico
     * @param {number} filtros.statusId - ID do status
     * @param {number} filtros.areaId - ID da área
     * @param {string} filtros.funciAtan - Matrícula do funcionário ATAN
     * @param {string} filtros.funciDesign - Matrícula do funcionário Design
     * @param {boolean} filtros.apenasAtivas - Se true, filtra por ativa=true (default: true)
     * @param {boolean} filtros.incluirEntregues - Se true, inclui Entregue/Cancelado de períodos anteriores
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Array>} Lista de demandas
     */
    static async buscarTodas(filtros = {}, options = {}) {
        const {
            ano,
            semestre,
            statusId,
            areaId,
            funciAtan,
            funciDesign,
            apenasAtivas = true,
            incluirEntregues = false
        } = filtros;

        // Where base
        const where = { tipologia: TIPOLOGIA };
        if (apenasAtivas) where.ativa = true;
        if (ano) where.ano = ano;
        if (semestre) where.semestre = semestre;

        // Where do detalhe (melhoria)
        const whereDetalhe = {};
        if (statusId) whereDetalhe.status = statusId;
        if (areaId) whereDetalhe.area = areaId;

        // Where dos responsáveis
        const whereResponsaveis = {};
        if (funciAtan) whereResponsaveis.funci_atan = funciAtan;
        if (funciDesign) whereResponsaveis.funci_design = funciDesign;

        const demandas = await models.Demandas.findAll({
            where,
            include: [{
                model: models.DemandasMelhoria,
                as: 'melhoria',
                required: true,
                attributes: ['status', 'priorizacao_comite'],
                where: Object.keys(whereDetalhe).length > 0 ? whereDetalhe : undefined,
                include: [{
                    model: models.TipStatus,
                    as: 'statusInfo',
                    attributes: ['status']
                }, {
                    model: models.MatrizGuthie,
                    as: 'guthieInfo',
                    required: false,
                    attributes: ['score', 'priorizacao_guthie']
                }]
            }, {
                model: models.ResponsaveisMelhoria,
                as: 'responsaveis',
                required: Object.keys(whereResponsaveis).length > 0,
                attributes: ['funci_atan', 'funci_design'],
                where: Object.keys(whereResponsaveis).length > 0 ? whereResponsaveis : undefined
            }],
            order: [['createdAt', 'DESC']],
            ...options
        });

        // Filtro de período (se não especificado ano/semestre)
        let resultado = demandas;
        if (!ano && !semestre && !incluirEntregues) {
            resultado = this._filtrarPorPeriodo(demandas);
        }

        return resultado.map(d => this._mapearLista(d));
    }

    // ==================== EDIÇÃO GRANULAR ====================

    /**
     * Atualiza dados básicos da demanda (tabela demandas)
     * @param {number} idDemanda - ID da demanda
     * @param {Object} dados - { semestre, ano }
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<boolean>} true se atualizou
     */
    static async editarDados(idDemanda, dados, options = {}) {
        const campos = {};
        if (dados.semestre !== undefined) campos.semestre = dados.semestre || null;
        if (dados.ano !== undefined) campos.ano = dados.ano || null;

        if (Object.keys(campos).length === 0) return false;

        const [updated] = await models.Demandas.update(campos, {
            where: { id_demanda: idDemanda, tipologia: TIPOLOGIA },
            ...options
        });

        return updated > 0;
    }

    /**
     * Atualiza detalhes específicos da Melhoria (tabela demandas_melhoria)
     * @param {number} idDemanda - ID da demanda
     * @param {Object} dados - { area, escopo, mvp, status_id, priorizacao_comite, etc }
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<boolean>} true se atualizou
     */
    static async editarDetalhe(idDemanda, dados, options = {}) {
        const campos = {};
        if (dados.area !== undefined) campos.area = dados.area || null;
        if (dados.escopo !== undefined) campos.escopo = dados.escopo || null;
        if (dados.mvp !== undefined) campos.mvp = dados.mvp || null;
        if (dados.priorizacao_comite !== undefined) campos.priorizacao_comite = dados.priorizacao_comite || null;
        if (dados.pessoas_envolvidas !== undefined) campos.pessoas_envolvidas = dados.pessoas_envolvidas || null;
        if (dados.vinculo_indicador_id !== undefined) campos.vinculo_indicador = dados.vinculo_indicador_id || null;
        if (dados.auditoria !== undefined) campos.auditoria = dados.auditoria || null;
        if (dados.inviabilidade_id !== undefined) campos.inviabilidade = dados.inviabilidade_id || null;
        if (dados.status_id !== undefined) campos.status = dados.status_id || null;
        if (dados.horas_bb !== undefined) campos.horas_bb = dados.horas_bb || null;
        if (dados.horas_previstas !== undefined) campos.horas_previstas = dados.horas_previstas || null;
        if (dados.horas_validadas !== undefined) campos.horas_validadas = dados.horas_validadas || null;
        if (dados.projeto !== undefined) campos.projeto = dados.projeto || null;
        if (dados.ferramenta !== undefined) campos.ferramenta = dados.ferramenta || null;

        if (Object.keys(campos).length === 0) return false;

        const [updated] = await models.DemandasMelhoria.update(campos, {
            where: { id_demanda: idDemanda },
            ...options
        });

        return updated > 0;
    }

    /**
     * Atualiza responsáveis da demanda (funcis e estagiários)
     * @param {number} idDemanda - ID da demanda
     * @param {Object} dados - { funci_atan, funci_design, estagiario_atan_id, etc }
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Object>} Registro atualizado
     */
    static async editarResponsaveis(idDemanda, dados, options = {}) {
        const campos = {};
        if (dados.funci_design !== undefined) campos.funci_design = dados.funci_design || null;
        if (dados.funci_design_aux !== undefined) campos.funci_design_aux = dados.funci_design_aux || null;
        if (dados.estagiario_design_id !== undefined) campos.estagiario_design = dados.estagiario_design_id || null;
        if (dados.estagiario_design_aux_id !== undefined) campos.estagiario_design_aux = dados.estagiario_design_aux_id || null;
        if (dados.funci_atan !== undefined) campos.funci_atan = dados.funci_atan || null;
        if (dados.funci_atan_aux !== undefined) campos.funci_atan_aux = dados.funci_atan_aux || null;
        if (dados.estagiario_atan_id !== undefined) campos.estagiario_atan = dados.estagiario_atan_id || null;
        if (dados.estagiario_atan_aux_id !== undefined) campos.estagiario_atan_aux = dados.estagiario_atan_aux_id || null;

        if (Object.keys(campos).length === 0) return null;

        return ResponsaveisMelhoriaService.salvar(idDemanda, campos, options);
    }

    /**
     * Atualiza matriz Guthie (score e priorização)
     * @param {number} idDemanda - ID da demanda
     * @param {Object} dados - { gravidade, urgencia, tendencia, impacto, etc }
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Object>} Registro atualizado
     */
    static async editarGuthie(idDemanda, dados, options = {}) {
        const campos = {};
        if (dados.gravidade !== undefined) campos.gravidade = dados.gravidade || null;
        if (dados.urgencia !== undefined) campos.urgencia = dados.urgencia || null;
        if (dados.tendencia !== undefined) campos.tendencia = dados.tendencia || null;
        if (dados.horas_economizadas !== undefined) campos.horas_economizadas = dados.horas_economizadas || null;
        if (dados.impacto !== undefined) campos.impacto = dados.impacto || null;
        if (dados.experiencia !== undefined) campos.experiencia = dados.experiencia || null;
        if (dados.score !== undefined && dados.score !== '--') campos.score = dados.score || null;
        if (dados.priorizacao_guthie !== undefined) campos.priorizacao_guthie = dados.priorizacao_guthie || null;

        if (Object.keys(campos).length === 0) return null;

        return MatrizGuthieService.salvar(idDemanda, campos, options);
    }

    /**
     * Atualiza cálculo de horas FTE
     * @param {number} idDemanda - ID da demanda
     * @param {Object} dados - { quantidade_funcionario, quantidade_tempo, etc }
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Object>} Registro atualizado
     */
    static async editarHorasFte(idDemanda, dados, options = {}) {
        const campos = {};
        if (dados.quantidade_funcionario !== undefined) campos.quantidade_funci = dados.quantidade_funcionario || null;
        if (dados.quantidade_tempo !== undefined) campos.quantidade_tempo = dados.quantidade_tempo || null;
        if (dados.quantidade_repeticao !== undefined) campos.quantidade_repeticao = dados.quantidade_repeticao || null;
        if (dados.unidade_tempo !== undefined) campos.unidade_tempo = dados.unidade_tempo || null;
        if (dados.unidade_repeticao !== undefined) campos.unidade_repeticao = dados.unidade_repeticao || null;
        if (dados.horas_ano !== undefined && dados.horas_ano !== '--') campos.horas_ano = dados.horas_ano || null;
        if (dados.fte_ano !== undefined && dados.fte_ano !== '--') campos.fte_ano = dados.fte_ano || null;

        if (Object.keys(campos).length === 0) return null;

        return HorasFteService.salvar(idDemanda, campos, options);
    }

    /**
     * Remove todos os dados relacionados a uma demanda Melhoria
     * @param {number} idDemanda - ID da demanda
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<void>}
     */
    static async removerDados(idDemanda, options = {}) {
        await Promise.all([
            models.DemandasMelhoria.destroy({ where: { id_demanda: idDemanda }, ...options }),
            ResponsaveisMelhoriaService.removerPorDemanda(idDemanda, options),
            MatrizGuthieService.removerPorDemanda(idDemanda, options),
            HorasFteService.removerPorDemanda(idDemanda, options),
            TagsService.removerPorDemanda(idDemanda, options),
            AndamentoService.removerPorDemanda(idDemanda, options)
        ]);
    }

    // ==================== Métodos privados de mapeamento ====================

    static _filtrarPorPeriodo(demandas) {
        const dataAtual = new Date();
        const anoAtual = dataAtual.getFullYear();
        const semestreAtual = dataAtual.getMonth() < 6 ? 1 : 2;
        const statusFinalizados = ['Entregue', 'Cancelado'];

        return demandas.filter(d => {
            const ehPeriodoAtual = d.ano === anoAtual && parseInt(d.semestre) === semestreAtual;
            if (ehPeriodoAtual) return true;

            const statusNome = d.melhoria?.statusInfo?.status;
            return !statusFinalizados.includes(statusNome);
        });
    }

    static _mapearLista(d) {
        const m = d.melhoria || {};
        const guthie = m.guthieInfo || {};
        const responsaveis = d.responsaveis || {};

        return {
            id_demanda: d.id_demanda,
            nome: d.nome,
            numero_gd: d.numero_gd,
            semestre: d.semestre,
            ano: d.ano,
            tipologia: d.tipologia,
            status_id: m.status,
            status_nome: m.statusInfo?.status || null,
            score_guthie: guthie.score || null,
            priorizacao_guthie: guthie.priorizacao_guthie || null,
            priorizacao_comite: m.priorizacao_comite || null,
            funci_atan: responsaveis.funci_atan || null,
            funci_design: responsaveis.funci_design || null,
            createdAt: d.createdAt
        };
    }

    static _mapearCompleto(d, { tags = [], andamentos = [], progresso = 0 } = {}) {
        const m = d.melhoria || {};
        const guthie = m.guthieInfo || {};
        const horasFTE = m.horasFTEInfo || {};
        const responsaveis = d.responsaveis || {};

        return {
            id_demanda: d.id_demanda,
            nome: d.nome,
            tipologia: d.tipologia,
            numero_gd: d.numero_gd,
            ativa: d.ativa,
            semestre: d.semestre,
            ano: d.ano,

            // Dados específicos da melhoria
            id_demanda_melhoria: m.id_demanda_melhoria,
            area_id: m.area,
            area_nome: m.areaInfo?.area,
            escopo: m.escopo,
            mvp: m.mvp,
            priorizacao_comite: m.priorizacao_comite,
            status_id: m.status,
            status_nome: m.statusInfo?.status,
            pessoas_envolvidas: m.pessoas_envolvidas,
            vinculo_indicador_id: m.vinculo_indicador,
            vinculo_indicador_nome: m.indicadorInfo?.indicador,
            auditoria: m.auditoria,
            inviabilidade_id: m.inviabilidade,
            inviabilidade_nome: m.inviabilidadeInfo?.inviabilidade,
            horas_bb: m.horas_bb,
            horas_previstas: m.horas_previstas,
            horas_validadas: m.horas_validadas,
            projeto: m.projeto,
            ferramenta: m.ferramenta,

            // Responsáveis
            funci_atan: responsaveis.funci_atan || null,
            funci_atan_aux: responsaveis.funci_atan_aux || null,
            funci_design: responsaveis.funci_design || null,
            funci_design_aux: responsaveis.funci_design_aux || null,
            estagiario_atan_id: responsaveis.estagiario_atan || null,
            estagiario_atan_nome: responsaveis.estagiarioAtanInfo?.nome || null,
            estagiario_design_id: responsaveis.estagiario_design || null,
            estagiario_design_nome: responsaveis.estagiarioDesignInfo?.nome || null,
            estagiario_atan_aux_id: responsaveis.estagiario_atan_aux || null,
            estagiario_atan_aux_nome: responsaveis.estagiarioAtanAuxInfo?.nome || null,
            estagiario_design_aux_id: responsaveis.estagiario_design_aux || null,
            estagiario_design_aux_nome: responsaveis.estagiarioDesignAuxInfo?.nome || null,

            // Score e prioridade
            score: guthie.score || null,
            prioridade_comite: m.priorizacao_comite || null,
            prioridade_guthie: guthie.priorizacao_guthie || null,

            // Matriz Guthie
            guthie: this._mapearGuthie(guthie),

            // Horas FTE
            fte: this._mapearHorasFte(horasFTE),

            // Precificação
            precificacao: this._mapearPrecificacao(d.precificacao),

            // Tags e andamentos
            tags,
            andamentos,
            progresso
        };
    }

    static _mapearGuthie(g) {
        if (!g || !g.id_guthie) return null;

        return {
            id_guthie: g.id_guthie,
            gravidade: g.gravidade,
            gravidade_pontos: g.gravidadeInfo?.pontos,
            gravidade_peso: g.gravidadeInfo?.peso,
            gravidade_legenda: g.gravidadeInfo?.legenda,
            horas_economizadas: g.horas_economizadas,
            horas_economizadas_pontos: g.horasEconomizadasInfo?.pontos,
            horas_economizadas_peso: g.horasEconomizadasInfo?.peso,
            horas_economizadas_legenda: g.horasEconomizadasInfo?.legenda,
            impacto: g.impacto,
            impacto_pontos: g.impactoInfo?.pontos,
            impacto_peso: g.impactoInfo?.peso,
            impacto_legenda: g.impactoInfo?.legenda,
            tendencia: g.tendencia,
            tendencia_pontos: g.tendenciaInfo?.pontos,
            tendencia_peso: g.tendenciaInfo?.peso,
            tendencia_legenda: g.tendenciaInfo?.legenda,
            urgencia: g.urgencia,
            urgencia_pontos: g.urgenciaInfo?.pontos,
            urgencia_peso: g.urgenciaInfo?.peso,
            urgencia_legenda: g.urgenciaInfo?.legenda,
            experiencia: g.experiencia,
            experiencia_pontos: g.experienciaInfo?.pontos,
            experiencia_peso: g.experienciaInfo?.peso,
            experiencia_legenda: g.experienciaInfo?.legenda,
            score: g.score,
            priorizacao_guthie: g.priorizacao_guthie
        };
    }

    static _mapearHorasFte(h) {
        if (!h || !h.id) return null;

        return {
            id: h.id,
            quantidade_funcionario: h.quantidade_funci,
            quantidade_tempo: h.quantidade_tempo,
            quantidade_repeticao: h.quantidade_repeticao,
            unidade_tempo: h.unidade_tempo,
            tempo_descricao: h.tempoInfo?.tempo,
            tempo_freq: h.tempoInfo?.tempo_freq,
            calc_tempo: h.tempoInfo?.calc_tempo,
            unidade_repeticao: h.unidade_repeticao,
            repeticao_descricao: h.repeticaoInfo?.repeticao,
            repeticao_freq: h.repeticaoInfo?.repeticao_freq,
            calc_repeticao: h.repeticaoInfo?.calc_repeticao,
            horas_ano: h.horas_ano,
            fte_ano: h.fte_ano
        };
    }

    static _mapearPrecificacao(p) {
        if (!p) return null;

        return {
            id: p.id,
            precificacao_dev_id: p.precificacao_dev,
            precificacao_dev_legenda: p.devInfo?.legenda,
            precificacao_dev_sprints: p.devInfo?.quant_sprints,
            precificacao_design_id: p.precificacao_design,
            precificacao_design_legenda: p.designInfo?.legenda,
            precificacao_design_sprints: p.designInfo?.quant_sprints
        };
    }
}

module.exports = MelhoriaService;