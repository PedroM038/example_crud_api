/**
 * @file services/melhoriaService.js
 * @description Serviço para gerenciar demandas do tipo Melhoria.
 * Responsável por buscar (uma ou todas) e editar demandas agregando dados das tabelas relacionadas.
 * @author Pedro e Rafaela
 */

const { Op } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');
const { Tags, TipTags } = require('../models/associations');
const tagsService = require('./tags_service');
const andamentoService = require('./andamento_service');

const {
    Demandas,
    Melhoria,
    Area,
    Indicador,
    Inviabilidade,
    Status,
    Estagiarios,
    Guthie,
    HorasFTE,
    Gravidade,
    HorasEconomizadas,
    Impacto,
    Tendencia,
    Urgencia,
    Experiencia,
    Tempo,
    Repeticao,
    ResponsaveisMelhoria,
    Precificacao,
    PrecificacaoDev,
    PrecificacaoDesign
} = require('../models/associations');

const MelhoriaService = {

    /**
     * Dispenso comentários sobre oq faz esse método.
     * @param {string} tipologia
     * @return {boolean}
     */
    verificaTipoDemanda(tipologia) {
        return tipologia === 'Melhoria';
    },

    /**
     * Monta objeto de retorno unificado.
     * Basicamente mapeia a demanda Melhoria com todos os dados relacionados.
     * note que são muitos dados, então o objeto retornado é grande.
     */
    _mapDemanda(demandaInstance) {
        if (!demandaInstance) return null;
        const d = demandaInstance;
        const m = d.melhoriaDetalhe || {};
        const area = m.areaInfo || {};
        const indicador = m.indicadorInfo || {};
        const inviabilidade = m.inviabilidadeInfo || {};
        const status = m.statusInfo || {};
        const guthie = m.guthieInfo || {};
        const horasFTE = m.horasFTEInfo || {};

        // Extrair dados de responsáveis da tabela separada
        const responsaveis = d.responsaveisMelhoriaInfo || {};
        const estagiarioAtan = responsaveis.estagiarioAtanInfo || {};
        const estagiarioDesign = responsaveis.estagiarioDesignInfo || {};
        const estagiarioAtanAux = responsaveis.estagiarioAtanAuxInfo || {};
        const estagiarioDesignAux = responsaveis.estagiarioDesignAuxInfo || {};

        // Extrair dados das associações da matriz Guthie
        const guthieGravidade = guthie.gravidadeInfo || {};
        const guthieHorasEcon = guthie.horasEconomizadasInfo || {};
        const guthieImpacto = guthie.impactoInfo || {};
        const guthieTendencia = guthie.tendenciaInfo || {};
        const guthieUrgencia = guthie.urgenciaInfo || {};
        const guthieExperiencia = guthie.experienciaInfo || {};

        // Extrair dados das associações das horas FTE
        const fteTempo = horasFTE.tempoInfo || {};
        const fteRepeticao = horasFTE.repeticaoInfo || {};

        return {
            id_demanda: d.id_demanda,
            nome: d.nome,
            tipologia: d.tipologia,
            numero_gd: d.numero_gd,
            ativa: d.ativa,
            semestre: d.semestre,
            ano: d.ano,

            // Dados específicos da melhoria
            id_demanda_melhoria: m.id_demanda_melhoria,
            area_id: m.area,
            area_nome: area.area,
            escopo: m.escopo,
            mvp: m.mvp,
            priorizacao_comite: m.priorizacao_comite,
            status_id: m.status,
            status_nome: status.status,
            pessoas_envolvidas: m.pessoas_envolvidas,
            vinculo_indicador_id: m.vinculo_indicador,
            vinculo_indicador_nome: indicador.indicador,
            auditoria: m.auditoria,
            inviabilidade_id: m.inviabilidade,
            inviabilidade_nome: inviabilidade.inviabilidade,
            horas_bb: m.horas_bb,
            horas_previstas: m.horas_previstas,
            horas_validadas: m.horas_validadas,
            projeto: m.projeto,
            ferramenta: m.ferramenta,
            funci_atan: responsaveis.funci_atan || null,
            funci_atan_aux: responsaveis.funci_atan_aux || null,
            funci_design: responsaveis.funci_design || null,
            funci_design_aux: responsaveis.funci_design_aux || null,
            estagiario_atan_id: responsaveis.estagiario_atan || null,
            estagiario_atan_nome: estagiarioAtan.nome || null,
            estagiario_design_id: responsaveis.estagiario_design || null,
            estagiario_design_nome: estagiarioDesign.nome || null,
            estagiario_atan_aux_id: responsaveis.estagiario_atan_aux || null,
            estagiario_atan_aux_nome: estagiarioAtanAux.nome || null,
            estagiario_design_aux_id: responsaveis.estagiario_design_aux || null,
            estagiario_design_aux_nome: estagiarioDesignAux.nome || null,
            score: guthie.score || null,
            prioridade_comite: m.priorizacao_comite || null,
            prioridade_guthie: guthie.priorizacao_guthie || null,

            // Dados da matriz Guthie estruturados com associações
            guthie: {
                id_guthie: guthie.id_guthie || null,
                gravidade: guthie.gravidade || null,
                gravidade_pontos: guthieGravidade.pontos || null,
                gravidade_peso: guthieGravidade.peso || null,
                gravidade_legenda: guthieGravidade.legenda || null,

                horas_economizadas: guthie.horas_economizadas || null,
                horas_economizadas_pontos: guthieHorasEcon.pontos || null,
                horas_economizadas_peso: guthieHorasEcon.peso || null,
                horas_economizadas_legenda: guthieHorasEcon.legenda || null,

                impacto: guthie.impacto || null,
                impacto_pontos: guthieImpacto.pontos || null,
                impacto_peso: guthieImpacto.peso || null,
                impacto_legenda: guthieImpacto.legenda || null,

                tendencia: guthie.tendencia || null,
                tendencia_pontos: guthieTendencia.pontos || null,
                tendencia_peso: guthieTendencia.peso || null,
                tendencia_legenda: guthieTendencia.legenda || null,

                urgencia: guthie.urgencia || null,
                urgencia_pontos: guthieUrgencia.pontos || null,
                urgencia_peso: guthieUrgencia.peso || null,
                urgencia_legenda: guthieUrgencia.legenda || null,

                experiencia: guthie.experiencia || null,
                experiencia_pontos: guthieExperiencia.pontos || null,
                experiencia_peso: guthieExperiencia.peso || null,
                experiencia_legenda: guthieExperiencia.legenda || null,

                score: guthie.score || null,
                priorizacao_guthie: guthie.priorizacao_guthie || null
            },

            // Dados das horas FTE estruturados com associações
            fte: {
                id: horasFTE.id || null,
                quantidade_funcionario: horasFTE.quantidade_funci || null,
                quantidade_tempo: horasFTE.quantidade_tempo || null,
                quantidade_repeticao: horasFTE.quantidade_repeticao || null,

                unidade_tempo: horasFTE.unidade_tempo || null,
                tempo_descricao: fteTempo.tempo || null,
                tempo_freq: fteTempo.tempo_freq || null,
                calc_tempo: fteTempo.calc_tempo || null,

                unidade_repeticao: horasFTE.unidade_repeticao || null,
                repeticao_descricao: fteRepeticao.repeticao || null,
                repeticao_freq: fteRepeticao.repeticao_freq || null,
                calc_repeticao: fteRepeticao.calc_repeticao || null,

                horas_ano: horasFTE.horas_ano || null,
                fte_ano: horasFTE.fte_ano || null
            },

            // Dados de precificação estruturados
            precificacao: {
                id: d.precificacaoInfo?.id || null,
                precificacao_dev_id: d.precificacaoInfo?.precificacao_dev || null,
                precificacao_dev_legenda: d.precificacaoInfo?.precificacaoDevInfo?.legenda || null,
                precificacao_dev_sprints: d.precificacaoInfo?.precificacaoDevInfo?.quant_sprints || null,
                precificacao_design_id: d.precificacaoInfo?.precificacao_design || null,
                precificacao_design_legenda: d.precificacaoInfo?.precificacaoDesignInfo?.legenda || null,
                precificacao_design_sprints: d.precificacaoInfo?.precificacaoDesignInfo?.quant_sprints || null
            },

            // Tags associadas à demanda (será populado separadamente)
            tags: d._tags || [],

            // Andamentos associados à demanda (será populado separadamente)
            andamentos: d._andamentos || [],
            progresso: d._progresso || 0
        };
    },

    /**
     * @description Mapeia uma demanda Melhoria para o formato esperado na tabela do frontend.
     * Aqui teremos menos detalhes, apenas o necessário para a lista.
     * Os dados necessários são: id, nome, numero_gd, tipologia, status, guthie.score, guthie.priorizacao_guthie, priorizacao_comite
     * funci_atan, funci_design. Assim teremos menos dados e mais performático.
     * 
     * @param {Object} demandaInstance - Instância da demanda Melhoria.
     * @param {*} demandaInstance 
     * @return {Object|null} - Objeto mapeado ou null se a demanda não existir.
     * @private
     */
    _mapDemandaLista(demandaInstance) {
        if (!demandaInstance) return null;
        const d = demandaInstance;
        const m = d.melhoriaDetalhe || {};
        const guthie = m.guthieInfo || {};
        const responsaveis = d.responsaveisMelhoriaInfo || {};

        return {
            id_demanda: d.id_demanda,
            nome: d.nome,
            numero_gd: d.numero_gd,
            semestre: d.semestre,
            ano: d.ano,
            tipologia: d.tipologia,
            status_id: m.status,
            status_nome: m.statusInfo?.status || null,
            score_guthie: guthie.score || null,
            priorizacao_guthie: guthie.priorizacao_guthie || null,
            priorizacao_comite: m.priorizacao_comite || null,
            funci_atan: responsaveis.funci_atan || null,
            funci_design: responsaveis.funci_design || null,
            createdAt: d.createdAt
        };
    },

    /**
     * Busca uma demanda Melhoria pelo ID.
     * @param {number} idDemanda
     * @returns {Promise<Object|null>}
     */
    async buscaDemandaPorId(idDemanda) {
        const demanda = await Demandas.findOne({
            where: {
                id_demanda: idDemanda,
                tipologia: 'Melhoria'
            },
            include: [
                {
                    model: Melhoria,
                    as: 'melhoriaDetalhe',
                    required: true,
                    include: [
                        {
                            model: Area,
                            as: 'areaInfo',
                            attributes: ['area']
                        },
                        {
                            model: Indicador,
                            as: 'indicadorInfo',
                            attributes: ['indicador']
                        },
                        {
                            model: Inviabilidade,
                            as: 'inviabilidadeInfo',
                            attributes: ['inviabilidade']
                        },
                        {
                            model: Status,
                            as: 'statusInfo',
                            attributes: ['status']
                        },
                        {
                            model: Guthie,
                            as: 'guthieInfo',
                            required: false,
                            include: [
                                {
                                    model: Gravidade,
                                    as: 'gravidadeInfo',
                                    attributes: ['id', 'pontos', 'peso', 'legenda']
                                },
                                {
                                    model: HorasEconomizadas,
                                    as: 'horasEconomizadasInfo',
                                    attributes: ['id', 'pontos', 'peso', 'legenda']
                                },
                                {
                                    model: Impacto,
                                    as: 'impactoInfo',
                                    attributes: ['id', 'pontos', 'peso', 'legenda']
                                },
                                {
                                    model: Tendencia,
                                    as: 'tendenciaInfo',
                                    attributes: ['id', 'pontos', 'peso', 'legenda']
                                },
                                {
                                    model: Urgencia,
                                    as: 'urgenciaInfo',
                                    attributes: ['id', 'pontos', 'peso', 'legenda']
                                },
                                {
                                    model: Experiencia,
                                    as: 'experienciaInfo',
                                    attributes: ['id', 'pontos', 'peso', 'legenda']
                                }
                            ]
                        },
                        {
                            model: HorasFTE,
                            as: 'horasFTEInfo',
                            required: false,
                            include: [
                                {
                                    model: Tempo,
                                    as: 'tempoInfo',
                                    attributes: ['id', 'tempo', 'tempo_freq', 'calc_tempo']
                                },
                                {
                                    model: Repeticao,
                                    as: 'repeticaoInfo',
                                    attributes: ['id', 'repeticao', 'repeticao_freq', 'calc_repeticao']
                                }
                            ]
                        },
                    ]
                },
                {
                    model: ResponsaveisMelhoria,
                    as: 'responsaveisMelhoriaInfo',
                    required: false,
                    include: [
                        {
                            model: Estagiarios,
                            as: 'estagiarioAtanInfo',
                            attributes: ['id', 'nome', 'matricula']
                        },
                        {
                            model: Estagiarios,
                            as: 'estagiarioDesignInfo',
                            attributes: ['id', 'nome', 'matricula']
                        },
                        {
                            model: Estagiarios,
                            as: 'estagiarioAtanAuxInfo',
                            attributes: ['id', 'nome', 'matricula']
                        },
                        {
                            model: Estagiarios,
                            as: 'estagiarioDesignAuxInfo',
                            attributes: ['id', 'nome', 'matricula']
                        }
                    ]
                },
                {
                    model: Precificacao,
                    as: 'precificacaoInfo',
                    required: false,
                    include: [
                        {
                            model: PrecificacaoDev,
                            as: 'precificacaoDevInfo',
                            attributes: ['id', 'legenda', 'quant_sprints']
                        },
                        {
                            model: PrecificacaoDesign,
                            as: 'precificacaoDesignInfo',
                            attributes: ['id', 'legenda', 'quant_sprints']
                        }
                    ]
                }
            ]
        });

        if (!demanda) return null;

        // Buscar tags associadas à demanda
        const tags = await tagsService.buscaTagsPorDemanda(idDemanda);
        demanda._tags = tags;

        // Buscar andamentos associados à demanda
        const andamentos = await andamentoService.buscaAndamentosPorDemanda(idDemanda);
        const progresso = await andamentoService.calculaProgressoDemanda(idDemanda);
        demanda._andamentos = andamentos;
        demanda._progresso = progresso;

        return this._mapDemanda(demanda);
    },

    /**
     * Busca todas as demandas Melhoria.
     * Filtro: demandas do ano/semestre atual OU demandas de períodos anteriores
     * que não estejam com status "Entregue" ou "Cancelado".
     * @returns {Promise<Array>}
     */
    async buscaTodasDemandas() {
        // Obter ano e semestre atuais
        const dataAtual = new Date();
        const anoAtual = dataAtual.getFullYear();
        const semestreAtual = dataAtual.getMonth() < 6 ? 1 : 2;

        // Status que excluem demandas de períodos anteriores
        const statusExcluidos = ['Entregue', 'Cancelado'];

        const demandas = await Demandas.findAll({
            where: {
                tipologia: 'Melhoria',
                ativa: true
            },
            include: [
                {
                    model: Melhoria,
                    as: 'melhoriaDetalhe',
                    required: true,
                    include: [
                        {
                            model: Status,
                            as: 'statusInfo',
                            attributes: ['status']
                        },
                        {
                            model: Guthie,
                            as: 'guthieInfo',
                            required: false,
                        },
                    ]
                },
                {
                    model: ResponsaveisMelhoria,
                    as: 'responsaveisMelhoriaInfo',
                    required: false,
                    attributes: ['funci_atan', 'funci_design']
                }
            ],
            order: [['createdAt', 'DESC']]
        });

        // Filtrar em memória para aplicar a lógica correta
        const demandasFiltradas = demandas.filter(d => {
            const ehPeriodoAtual = d.ano === anoAtual && parseInt(d.semestre) === semestreAtual;
            
            // Se for do período atual, inclui independente do status
            if (ehPeriodoAtual) return true;

            // Se for de período anterior, verifica se o status não é Entregue ou Cancelado
            const statusNome = d.melhoriaDetalhe?.statusInfo?.status;
            return !statusExcluidos.includes(statusNome);
        });

        return demandasFiltradas.map(d => this._mapDemandaLista(d));
    },

    /**
 * Edita uma demanda Melhoria.
 * @param {number} idDemanda
 * @param {Object} dados
 * @returns {Promise<Object>} demanda atualizada
 */
    async editaDemanda(idDemanda, dados, usuario) {
        const {
            semestre,
            ano,
            area,
            escopo,
            mvp,
            score,
            gravidade,
            urgencia,
            tendencia,
            horas_economizadas,
            impacto,
            experiencia,
            priorizacao_guthie,
            priorizacao_comite,
            pessoas_envolvidas,
            vinculo_indicador_id,
            auditoria,
            horas_bb,
            horas_previstas,
            horas_validadas,
            projeto,
            ferramenta,
            inviabilidade_id,
            status_id,
            funci_design,
            funci_design_aux,
            estagiario_design_id,
            estagiario_design_aux_id,
            funci_atan,
            funci_atan_aux,
            estagiario_atan_id,
            estagiario_atan_aux_id,
            fte_ano,
            horas_ano,
            unidade_tempo,
            unidade_repeticao,
            quantidade_tempo,
            quantidade_repeticao,
            quantidade_funcionario,
            precificacao_dev_id,
            precificacao_design_id,
            tags
        } = dados;

        return await sequelize.transaction(async (t) => {
            // Verificar se a demanda existe
            const demanda = await Demandas.findOne({
                where: {
                    id_demanda: idDemanda,
                    tipologia: 'Melhoria'
                },
                transaction: t
            });

            if (!demanda) {
                throw new Error('Demanda não encontrada ou não é do tipo Melhoria.');
            }

            if (semestre !== undefined) demanda.semestre = semestre || null;
            if (ano !== undefined) demanda.ano = ano || null;
            await demanda.save({ transaction: t });

            // 1. Atualizar detalhe da melhoria
            const melhoria = await Melhoria.findOne({
                where: { id_demanda: idDemanda },
                transaction: t
            });

            if (!melhoria) {
                throw new Error('Registro de detalhe Melhoria não encontrado.');
            }

            // Atualizar campos específicos da melhoria
            if (area !== undefined) melhoria.area = area || null;
            if (escopo !== undefined) melhoria.escopo = escopo || null;
            if (mvp !== undefined) melhoria.mvp = mvp || null;
            if (priorizacao_comite !== undefined) melhoria.priorizacao_comite = priorizacao_comite || null;
            if (pessoas_envolvidas !== undefined) melhoria.pessoas_envolvidas = pessoas_envolvidas || null;
            if (vinculo_indicador_id !== undefined) melhoria.vinculo_indicador = vinculo_indicador_id || null;
            if (auditoria !== undefined) melhoria.auditoria = auditoria || null;
            if (inviabilidade_id !== undefined) melhoria.inviabilidade = inviabilidade_id || null;
            if (status_id !== undefined) melhoria.status = status_id || null;
            if (horas_bb !== undefined) melhoria.horas_bb = horas_bb || null;
            if (horas_previstas !== undefined) melhoria.horas_previstas = horas_previstas || null;
            if (horas_validadas !== undefined) melhoria.horas_validadas = horas_validadas || null;
            if (projeto !== undefined) melhoria.projeto = projeto || null;
            if (ferramenta !== undefined) melhoria.ferramenta = ferramenta || null;

            await melhoria.save({ transaction: t });

            // 2. Atualizar/criar responsáveis na tabela separada
            let responsaveisData = {};
            if (funci_design !== undefined) responsaveisData.funci_design = funci_design || null;
            if (funci_design_aux !== undefined) responsaveisData.funci_design_aux = funci_design_aux || null;
            if (estagiario_design_id !== undefined) responsaveisData.estagiario_design = estagiario_design_id || null;
            if (estagiario_design_aux_id !== undefined) responsaveisData.estagiario_design_aux = estagiario_design_aux_id || null;
            if (funci_atan !== undefined) responsaveisData.funci_atan = funci_atan || null;
            if (funci_atan_aux !== undefined) responsaveisData.funci_atan_aux = funci_atan_aux || null;
            if (estagiario_atan_id !== undefined) responsaveisData.estagiario_atan = estagiario_atan_id || null;
            if (estagiario_atan_aux_id !== undefined) responsaveisData.estagiario_atan_aux = estagiario_atan_aux_id || null;

            // Verificar se já existe registro de responsáveis para esta demanda
            let responsaveis = await ResponsaveisMelhoria.findOne({
                where: { id_demanda: idDemanda },
                transaction: t
            });

            if (responsaveis) {
                // Atualizar registro existente
                await responsaveis.update(responsaveisData, { transaction: t });
            } else if (Object.keys(responsaveisData).length > 0) {
                // Criar novo registro se há dados para inserir
                responsaveisData.id_demanda = idDemanda;
                await ResponsaveisMelhoria.create(responsaveisData, { transaction: t });
            }

            // 3. Atualizar/criar matriz Guthie
            let guthieData = {};
            if (gravidade !== undefined) guthieData.gravidade = gravidade || null;
            if (urgencia !== undefined) guthieData.urgencia = urgencia || null;
            if (tendencia !== undefined) guthieData.tendencia = tendencia || null;
            if (horas_economizadas !== undefined) guthieData.horas_economizadas = horas_economizadas || null;
            if (impacto !== undefined) guthieData.impacto = impacto || null;
            if (experiencia !== undefined) guthieData.experiencia = experiencia || null;
            if (score !== undefined && score !== '--') guthieData.score = score || null;
            if (priorizacao_guthie !== undefined) guthieData.priorizacao_guthie = priorizacao_guthie || null;

            // Verificar se já existe registro na matriz Guthie
            let guthie = await Guthie.findOne({
                where: { id_demanda: idDemanda },
                transaction: t
            });

            if (guthie) {
                // Atualizar registro existente
                await guthie.update(guthieData, { transaction: t });
            } else if (Object.keys(guthieData).length > 0) {
                // Criar novo registro se há dados para inserir
                guthieData.id_demanda = idDemanda;
                await Guthie.create(guthieData, { transaction: t });
            }

            // 4. Atualizar/criar horas FTE
            let horasFteData = {};
            if (quantidade_funcionario !== undefined) horasFteData.quantidade_funci = quantidade_funcionario || null;
            if (quantidade_tempo !== undefined) horasFteData.quantidade_tempo = quantidade_tempo || null;
            if (quantidade_repeticao !== undefined) horasFteData.quantidade_repeticao = quantidade_repeticao || null;
            if (unidade_tempo !== undefined) horasFteData.unidade_tempo = unidade_tempo || null;
            if (unidade_repeticao !== undefined) horasFteData.unidade_repeticao = unidade_repeticao || null;
            if (horas_ano !== undefined && horas_ano !== '--') horasFteData.horas_ano = horas_ano || null;
            if (fte_ano !== undefined && fte_ano !== '--') horasFteData.fte_ano = fte_ano || null;

            // Verificar se já existe registro na tabela horas_fte
            let horasFte = await HorasFTE.findOne({
                where: { id_demanda: idDemanda },
                transaction: t
            });

            if (horasFte) {
                // Atualizar registro existente
                await horasFte.update(horasFteData, { transaction: t });
            } else if (Object.keys(horasFteData).length > 0) {
                // Criar novo registro se há dados para inserir
                horasFteData.id_demanda = idDemanda;
                await HorasFTE.create(horasFteData, { transaction: t });
            }

            // 5. Atualizar/criar precificação
            let precificacaoData = {};
            if (precificacao_dev_id !== undefined) precificacaoData.precificacao_dev = precificacao_dev_id || null;
            if (precificacao_design_id !== undefined) precificacaoData.precificacao_design = precificacao_design_id || null;

            // Verificar se já existe registro na tabela precificacao
            let precificacao = await Precificacao.findOne({
                where: { id_demanda: idDemanda },
                transaction: t
            });

            if (precificacao) {
                // Atualizar registro existente
                await precificacao.update(precificacaoData, { transaction: t });
            } else if (Object.keys(precificacaoData).length > 0) {
                // Criar novo registro se há dados para inserir
                precificacaoData.id_demanda = idDemanda;
                await Precificacao.create(precificacaoData, { transaction: t });
            }

            const matricula = usuario.chave;
            // 6. Atualizar tags
            if (tags !== undefined && Array.isArray(tags)) {

                // Remover todas as tags antigas
                await Tags.destroy({
                    where: { id_demanda: idDemanda },
                    transaction: t
                });

                // Adicionar as novas tags
                if (tags.length > 0) {
                    const insercoes = tags.map(tagId => ({
                        id_demanda: idDemanda,
                        tag: tagId,
                        matricula: matricula || null
                    }));

                    await Tags.bulkCreate(insercoes, { transaction: t });
                }
            }
            return; 
        });
    },
};

module.exports = MelhoriaService;