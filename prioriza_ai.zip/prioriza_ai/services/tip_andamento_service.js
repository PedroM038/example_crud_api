/**
 * @file services/fases_etapas_service.js
 * @description Responsável por gerenciar as fases e etapas disponíveis no sistema.
 * A tabela tip_fases_etapas contém todas as fases e etapas que podem ser 
 * associadas ao andamento de uma demanda.
 */

const tip_andamento = require('../models/tip_fases_etapas');

const tip_andamento_service = {
    async buscaTodasFasesEtapas() {
        try {
            const fasesEtapas = await tip_andamento.findAll({
                attributes: ['id', 'etapa', 'fase', 'percentual', 'deletedAt'],
                order: [['etapa', 'ASC'], ['fase', 'ASC']],
                paranoid: false
            });

            return fasesEtapas;
        } catch (error) {
            throw new Error(`Erro ao buscar fases e etapas: ${error.message}`);
        }
    },

    async buscaTodasFasesEtapasAtivas() {
        try {
            const fasesEtapas = await tip_andamento.findAll({
                attributes: ['id', 'etapa', 'fase', 'percentual', 'deletedAt'],
                order: [['etapa', 'ASC'], ['fase', 'ASC']],
                paranoid: true
            });

            return fasesEtapas;
        } catch (error) {
            throw new Error(`Erro ao buscar fases e etapas: ${error.message}`);
        }
    },

    async buscaFaseEtapaPorId(id) {
        try {
            const faseEtapa = await tip_andamento.findByPk(id, {
                attributes: ['id', 'etapa', 'fase', 'percentual']
            });

            return faseEtapa;
        } catch (error) {
            throw new Error(`Erro ao buscar fase/etapa por ID: ${error.message}`);
        }
    },

    async buscaFasesPorEtapa(etapa) {
        try {
            const fases = await tip_andamento.findAll({
                attributes: ['id', 'etapa', 'fase', 'percentual'],
                where: { etapa },
                order: [['fase', 'ASC']],
                paranoid: true
            });

            return fases;
        } catch (error) {
            throw new Error(`Erro ao buscar fases por etapa: ${error.message}`);
        }
    },

    async buscaTodasEtapas() {
        try {
            const etapas = await tip_andamento.findAll({
                attributes: ['etapa'],
                group: ['etapa'],
                order: [['etapa', 'ASC']],
                paranoid: true
            });

            return etapas.map(e => e.etapa);
        } catch (error) {
            throw new Error(`Erro ao buscar etapas: ${error.message}`);
        }
    },

    /**
     * Retorna fases e etapas agrupadas por etapa
     * Útil para montar selects encadeados no front-end
     * @returns {object} Objeto com etapas como chaves e array de fases como valores
     */
    async buscaFasesEtapasAgrupadas() {
        try {
            const fasesEtapas = await tip_andamento.findAll({
                attributes: ['id', 'etapa', 'fase', 'percentual'],
                order: [['id', 'ASC']],  // Ordenar por ID para manter a sequência natural
                paranoid: true
            });

            // Agrupa por etapa
            const agrupadas = fasesEtapas.reduce((acc, item) => {
                const etapa = item.etapa;
                if (!acc[etapa]) {
                    acc[etapa] = [];
                }
                acc[etapa].push({
                    id: item.id,
                    fase: item.fase,
                    percentual: item.percentual
                });
                return acc;
            }, {});

            return agrupadas;
        } catch (error) {
            throw new Error(`Erro ao buscar fases e etapas agrupadas: ${error.message}`);
        }
    },

    async criaFaseEtapa(faseEtapaData) {
        try {
            const novaFaseEtapa = await tip_andamento.create(faseEtapaData);
            return novaFaseEtapa;
        } catch (error) {
            throw new Error(`Erro ao criar fase/etapa: ${error.message}`);
        }
    },

    async atualizaFaseEtapa(id, faseEtapaData) {
        try {
            const [updated] = await tip_andamento.update(faseEtapaData, {
                where: { id }
            });
            if (updated) {
                const faseEtapaAtualizada = await tip_andamento.findByPk(id);
                return faseEtapaAtualizada;
            }
            throw new Error("Fase/Etapa não encontrada");
        } catch (error) {
            throw new Error(`Erro ao atualizar fase/etapa: ${error.message}`);
        }
    },

    async deletaFaseEtapa(id) {
        try {
            const deleted = await tip_andamento.destroy({
                where: { id }
            });
            if (deleted) {
                return { message: "Fase/Etapa deletada com sucesso" };
            }
            throw new Error("Fase/Etapa não encontrada");
        } catch (error) {
            throw new Error(`Erro ao deletar fase/etapa: ${error.message}`);
        }
    },

    async restauraFaseEtapa(id) {
        try {
            const restored = await tip_andamento.restore({
                where: { id }
            });
            if (restored) {
                return { message: "Fase/Etapa restaurada com sucesso" };
            }
            throw new Error("Fase/Etapa não encontrada ou não estava deletada");
        } catch (error) {
            throw new Error(`Erro ao restaurar fase/etapa: ${error.message}`);
        }
    }
};

module.exports = tip_andamento_service;
