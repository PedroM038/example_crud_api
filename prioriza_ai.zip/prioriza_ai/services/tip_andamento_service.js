/**
 * @file services/tip_andamento_service.js
 * @description Gerencia as fases e etapas do andamento de demandas.
 */

const { models } = require('../models/associations');

class TipFasesEtapasService {

    static async buscarTodas(options = {}) {
        return models.TipFasesEtapas.findAll({
            attributes: ['id', 'etapa', 'fase', 'percentual', 'deletedAt'],
            order: [['etapa', 'ASC'], ['fase', 'ASC']],
            paranoid: false,
            ...options
        });
    }

    static async buscarAtivas(options = {}) {
        return models.TipFasesEtapas.findAll({
            attributes: ['id', 'etapa', 'fase', 'percentual'],
            order: [['etapa', 'ASC'], ['fase', 'ASC']],
            ...options
        });
    }

    static async buscarPorId(id, options = {}) {
        return models.TipFasesEtapas.findByPk(id, {
            attributes: ['id', 'etapa', 'fase', 'percentual'],
            ...options
        });
    }

    static async buscarPorEtapa(etapa, options = {}) {
        const { where = {}, ...restOptions } = options;
        return models.TipFasesEtapas.findAll({
            attributes: ['id', 'etapa', 'fase', 'percentual'],
            where: { etapa, ...where },
            order: [['fase', 'ASC']],
            ...restOptions
        });
    }

    static async buscarEtapasDistintas(options = {}) {
        const etapas = await models.TipFasesEtapas.findAll({
            attributes: ['etapa'],
            group: ['etapa'],
            order: [['etapa', 'ASC']],
            ...options
        });
        return etapas.map(e => e.etapa);
    }

    static async buscarAgrupadas(options = {}) {
        const fasesEtapas = await models.TipFasesEtapas.findAll({
            attributes: ['id', 'etapa', 'fase', 'percentual'],
            order: [['id', 'ASC']],
            ...options
        });

        return fasesEtapas.reduce((acc, item) => {
            const etapa = item.etapa;
            if (!acc[etapa]) acc[etapa] = [];
            acc[etapa].push({
                id: item.id,
                fase: item.fase,
                percentual: item.percentual
            });
            return acc;
        }, {});
    }

    static async criar(data, options = {}) {
        return models.TipFasesEtapas.create(data, options);
    }

    static async atualizar(id, data, options = {}) {
        const [updated] = await models.TipFasesEtapas.update(data, {
            where: { id },
            ...options
        });
        if (!updated) throw new Error('Fase/Etapa não encontrada');
        return models.TipFasesEtapas.findByPk(id, options);
    }

    static async deletar(id, options = {}) {
        const deleted = await models.TipFasesEtapas.destroy({
            where: { id },
            ...options
        });
        if (!deleted) throw new Error('Fase/Etapa não encontrada');
    }

    static async restaurar(id, options = {}) {
        const restored = await models.TipFasesEtapas.restore({
            where: { id },
            ...options
        });
        if (!restored) throw new Error('Fase/Etapa não encontrada');
    }
}

module.exports = TipFasesEtapasService;
