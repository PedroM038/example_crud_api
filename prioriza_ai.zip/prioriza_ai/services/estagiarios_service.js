/**
 * @file services/estagiarios_service.js
 * @description Service responsável por trazer os estagiarios que podem
 * ser selecionados por atan ou design.
* @author Pedro e Rafaela
 */

const database = process.env.DATABASE;
const { query } = require('../database/conexao');
const tip_estagiarios = require('../models/tip_estagiarios');

const EstagiariosService = {

    // Constantes para UORs
    UOR_ATAN: 286527,
    UOR_DESIGN: 286521,

    /**
     * Busca estagiários do banco de dados
     * @param {string} equipe - Nome da equipe ('Automação' ou 'Design')
     * @returns {Promise<Array>}
     */
    async buscaEstagiarios(equipe) {
        try {
            const sql = `
                SELECT id, equipe, matricula, nome
                FROM ${database}.tip_estagiarios
                WHERE equipe = ? AND deletedAt IS NULL
                ORDER BY nome ASC
            `;

            const resultado = await query(sql, [equipe]);
            return resultado || [];
        } catch (error) {
            console.error(`Erro ao buscar estagiários da equipe ${equipe}:`, error.message);
            return [];
        }
    },

    async buscaEstagiariosTodos(equipe) {
        try {
            const sql = `
                SELECT id, equipe, matricula, nome
                FROM ${database}.tip_estagiarios
                WHERE equipe = ?
                ORDER BY nome ASC
            `;

            const resultado = await query(sql, [equipe]);
            return resultado || [];
        } catch (error) {
            console.error(`Erro ao buscar estagiários da equipe ${equipe}:`, error.message);
            return [];
        }
    },

    /**
     * Busca estagiários da equipe ATAN
     * @returns {Promise<Array>}
     */
    async buscaEstagiariosAtan() {
        return await this.buscaEstagiarios('Automação');
    },

    /**
     * Busca estagiários da equipe DESIGN
     * @returns {Promise<Array>}
     */
    async buscaEstagiariosDesign() {
        return await this.buscaEstagiarios('Design');
    },
};

module.exports = EstagiariosService;