const tip_status = require('../models/tip_status');

class tip_status_service {

    static async buscaTodosStatus() {
        try {
            const statusList = await tip_status.findAll({
                attributes: ['id', 'status', 'deletedAt'],
                order: [['status', 'ASC']],
                paranoid: false
            });
            return statusList;
        } catch (error) {
            console.error("Erro ao buscar status:", error);
            throw new Error("Erro ao buscar status");
        }
    }

    static async buscaTodosStatusAtivos() {
        try {
            const statusList = await tip_status.findAll({
                attributes: ['id', 'status', 'deletedAt'],
                order: [['status', 'ASC']],
                paranoid: true
            });
            return statusList;
        } catch (error) {
            console.error("Erro ao buscar status:", error);
            throw new Error("Erro ao buscar status");
        }
    }

    static async criaStatus(statusData) {
        try {
            const novoStatus = await tip_status.create(statusData);
            return novoStatus;
        } catch (error) {
            console.error("Erro ao criar status:", error);
            throw new Error("Erro ao criar status");
        }
    }

    static async atualizaStatus(id, statusData) {
        try {
            const [updated] = await tip_status.update(statusData, {
                where: { id: id }
            });
            if (updated) {
                const updatedStatus = await tip_status.findByPk(id);
                return updatedStatus;
            }
            throw new Error("Status não encontrado");
        } catch (error) {
            console.error("Erro ao atualizar status:", error);
            throw new Error("Erro ao atualizar status");
        }
    }

    static async deletaStatus(id) {
        try {
            const deleted = await tip_status.destroy({
                where: { id: id }
            });
            if (deleted) {
                return { message: "Status deletado com sucesso" };
            }
            throw new Error("Status não encontrado");
        } catch (error) {
            console.error("Erro ao deletar status:", error);
            throw new Error("Erro ao deletar status");
        }
    }

    static async restauraStatus(id) {
        try {
            const restored = await tip_status.restore({
                where: { id: id }
            });
            if (restored) {
                return { message: "Status restaurado com sucesso" };
            }
            throw new Error("Status não encontrado ou não estava deletado");
        } catch (error) {
            console.error("Erro ao restaurar status:", error);
            throw new Error("Erro ao restaurar status");
        }
    }
}

module.exports = tip_status_service;