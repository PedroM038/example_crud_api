const { models } = require('../models/associations');

class TipPrecificacaoDesignService {

    static async buscarTodas(options = {}) {
        return models.TipPrecificacaoDesign.findAll({
            attributes: ['id', 'legenda', 'quant_sprints'],
            order: [['id', 'ASC']],
            ...options
        });
    }

    static async buscarPorId(id, options = {}) {
        return models.TipPrecificacaoDesign.findByPk(id, {
            attributes: ['id', 'legenda', 'quant_sprints'],
            ...options
        });
    }

    static async criar(data, options = {}) {
        return models.TipPrecificacaoDesign.create(data, options);
    }

    static async atualizar(id, data, options = {}) {
        const [updated] = await models.TipPrecificacaoDesign.update(data, {
            where: { id },
            ...options
        });
        if (!updated) throw new Error('Precificação Design não encontrada');
        return models.TipPrecificacaoDesign.findByPk(id, options);
    }
}

module.exports = TipPrecificacaoDesignService;
