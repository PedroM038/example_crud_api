const { models } = require('../models/associations');

class TipGravidadesService {

    static async buscarTodas(options = {}) {
        return models.TipGravidades.findAll({
            attributes: ['id', 'peso', 'pontos', 'legenda'],
            order: [['peso', 'ASC']],
            ...options
        });
    }

    static async criar(data, options = {}) {
        return models.TipGravidades.create(data, options);
    }

    static async atualizar(id, data, options = {}) {
        const [updated] = await models.TipGravidades.update(data, {
            where: { id },
            ...options
        });
        if (!updated) throw new Error('Gravidade não encontrada');
        return models.TipGravidades.findByPk(id, options);
    }
}

module.exports = TipGravidadesService;