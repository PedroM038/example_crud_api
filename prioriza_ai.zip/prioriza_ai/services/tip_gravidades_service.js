const tip_gravidades = require('../models/tip_gravidades');

class tip_gravidades_service {
    static async buscaTodasGravidades() {
        try {
            const gravidades = await tip_gravidades.findAll({
                attributes: ['id', 'peso', 'pontos', 'legenda'],
                order: [['peso', 'ASC']]
            });
            return gravidades;
        } catch (error) {
            console.error("Erro ao buscar gravidades:", error);
            throw new Error("Erro ao buscar gravidades");
        }
    }

    static async criaGravidade(gravidadeData) {
        try {
            const novaGravidade = await tip_gravidades.create(gravidadeData);
            return novaGravidade;
        } catch (error) {
            console.error("Erro ao criar gravidade:", error);
            throw new Error("Erro ao criar gravidade");
        }
    }

    static async atualizaGravidade(id, gravidadeData) {
        try {
            const [updated] = await tip_gravidades.update(gravidadeData, {
                where: { id: id }
            });
            if (updated) {
                const updatedGravidade = await tip_gravidades.findByPk(id);
                return updatedGravidade;
            }
            throw new Error("Gravidade não encontrada");
        } catch (error) {
            console.error("Erro ao atualizar gravidade:", error);
            throw new Error("Erro ao atualizar gravidade");
        }
    }
}

module.exports = tip_gravidades_service;