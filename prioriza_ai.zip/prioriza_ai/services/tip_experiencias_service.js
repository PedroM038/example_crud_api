const { models } = require('../models/associations');

class TipExperienciasService {

    static async buscarTodas(options = {}) {
        return models.TipExperiencias.findAll({
            attributes: ['id', 'peso', 'pontos', 'legenda'],
            order: [['peso', 'ASC']],
            ...options
        });
    }

    static async criar(data, options = {}) {
        return models.TipExperiencias.create(data, options);
    }

    static async atualizar(id, data, options = {}) {
        const [updated] = await models.TipExperiencias.update(data, {
            where: { id },
            ...options
        });
        if (!updated) throw new Error('Experiência não encontrada');
        return models.TipExperiencias.findByPk(id, options);
    }
}

module.exports = TipExperienciasService;