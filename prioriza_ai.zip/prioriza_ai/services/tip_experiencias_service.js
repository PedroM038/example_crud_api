const tip_experiencias = require('../models/tip_experiencias');

class tip_experiencias_service {

    static async buscaTodasExperiencias() {
        try {
            const experiencias = await tip_experiencias.findAll({
                attributes: ['id', 'peso', 'pontos', 'legenda'],
                order: [['peso', 'ASC']]
            });
            return experiencias;
        } catch (error) {
            console.error("Erro ao buscar experiências:", error);
            throw new Error("Erro ao buscar experiências");
        }
    }

    static async criaExperiencia(experienciaData) {
        try {
            const novaExperiencia = await tip_experiencias.create(experienciaData);
            return novaExperiencia;
        } catch (error) {
            console.error("Erro ao criar experiência:", error);
            throw new Error("Erro ao criar experiência");
        }
    }

    static async atualizaExperiencia(id, experienciaData) {
        try {
            const [updated] = await tip_experiencias.update(experienciaData, {
                where: { id: id }
            });
            if (updated) {
                const updatedExperiencia = await tip_experiencias.findByPk(id);
                return updatedExperiencia;
            }
            throw new Error("Experiência não encontrada");
        } catch (error) {
            console.error("Erro ao atualizar experiência:", error);
            throw new Error("Erro ao atualizar experiência");
        }
    }
}

module.exports = tip_experiencias_service;