const { Guthie, Gravidade, HorasEconomizadas, Impacto, Tendencia, Urgencia, Experiencia } = require('../models/associations');

/**
 * Service para operações CRUD na matriz Guthie.
 */

const matrizGuthieService = {
    // Lista todos os registros da matriz Guthie, incluindo associações
    async listAll() {
        return Guthie.findAll({
            include: [
                { model: Gravidade, as: 'gravidadeInfo' },
                { model: HorasEconomizadas, as: 'horasEconomizadasInfo' },
                { model: Impacto, as: 'impactoInfo' },
                { model: Tendencia, as: 'tendenciaInfo' },
                { model: Urgencia, as: 'urgenciaInfo' },
                { model: Experiencia, as: 'experienciaInfo' }
            ]
        });
    },

    // Busca um registro específico por id_guthie
    async getById(id_guthie) {
        return Guthie.findByPk(id_guthie, {
            include: [
                { model: Gravidade, as: 'gravidadeInfo' },
                { model: HorasEconomizadas, as: 'horasEconomizadasInfo' },
                { model: Impacto, as: 'impactoInfo' },
                { model: Tendencia, as: 'tendenciaInfo' },
                { model: Urgencia, as: 'urgenciaInfo' },
                { model: Experiencia, as: 'experienciaInfo' }
            ]
        });
    },

    // Busca um registro específico por id_demanda
    async getByDemanda(id_demanda) {
        return Guthie.findOne({
            where: { id_demanda },
            include: [
                { model: Gravidade, as: 'gravidadeInfo' },
                { model: HorasEconomizadas, as: 'horasEconomizadasInfo' },
                { model: Impacto, as: 'impactoInfo' },
                { model: Tendencia, as: 'tendenciaInfo' },
                { model: Urgencia, as: 'urgenciaInfo' },
                { model: Experiencia, as: 'experienciaInfo' }
            ]
        });
    },

    // Cria um novo registro na matriz Guthie com dados nulos
    async create(idDemanda) {
        return Guthie.create({
            id_demanda: idDemanda,
            gravidade: null,
            horas_economizadas: null,
            impacto: null,
            tendencia: null,
            urgencia: null,
            experiencia: null
        });
    },

    // Atualiza um registro existente
    async update(id_guthie, data) {
        const guthie = await Guthie.findByPk(id_guthie);
        if (!guthie) return null;
        await guthie.update(data);
        return guthie;
    },

    // Deleta um registro
    async remove(id_guthie) {
        const guthie = await Guthie.findByPk(id_guthie);
        if (!guthie) return null;
        await guthie.destroy();
        return true;
    }
};

module.exports = matrizGuthieService;