/**
 * @file services/matriz_guthie_service.js
 * @description Serviço para operações na matriz GUT+HIE (priorização de demandas).
 * @author Pedro e Rafaela
 */

const { models } = require('../models/associations');

// Includes padrão para consultas com informações completas
const INCLUDES_COMPLETO = [
    { model: models.TipGravidades, as: 'gravidadeInfo' },
    { model: models.TipHorasEconomizadas, as: 'horasEconomizadasInfo' },
    { model: models.TipImpactos, as: 'impactoInfo' },
    { model: models.TipTendencias, as: 'tendenciaInfo' },
    { model: models.TipUrgencias, as: 'urgenciaInfo' },
    { model: models.TipExperiencias, as: 'experienciaInfo' }
];

class MatrizGuthieService {

    /**
     * Busca todos os registros da matriz
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Array>} Lista de registros com associações
     */
    static async buscarTodos(options = {}) {
        return models.MatrizGuthie.findAll({
            include: INCLUDES_COMPLETO,
            ...options
        });
    }

    /**
     * Busca matriz por ID da demanda
     * @param {number} idDemanda - ID da demanda
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Object|null>} Registro ou null
     */
    static async buscarPorDemanda(idDemanda, options = {}) {
        return models.MatrizGuthie.findOne({
            where: { id_demanda: idDemanda },
            include: INCLUDES_COMPLETO,
            ...options
        });
    }

    /**
     * Busca ou cria matriz para uma demanda (garante que sempre existe)
     * @param {number} idDemanda - ID da demanda
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Object>} Registro existente ou novo
     */
    static async buscarOuCriar(idDemanda, options = {}) {
        const [registro] = await models.MatrizGuthie.findOrCreate({
            where: { id_demanda: idDemanda },
            defaults: {
                id_demanda: idDemanda,
                gravidade: null,
                horas_economizadas: null,
                impacto: null,
                tendencia: null,
                urgencia: null,
                experiencia: null
            },
            ...options
        });
        return registro;
    }

    /**
     * Salva (cria ou atualiza) matriz de uma demanda
     * @param {number} idDemanda - ID da demanda
     * @param {Object} dados - Dados da matriz
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Object>} Registro salvo
     */
    static async salvar(idDemanda, dados, options = {}) {
        const [registro, criado] = await models.MatrizGuthie.findOrCreate({
            where: { id_demanda: idDemanda },
            defaults: { id_demanda: idDemanda, ...dados },
            ...options
        });

        if (!criado) {
            await registro.update(dados, options);
        }

        return registro;
    }

    /**
     * Remove matriz de uma demanda
     * @param {number} idDemanda - ID da demanda
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<number>} Número de registros removidos
     */
    static async removerPorDemanda(idDemanda, options = {}) {
        return models.MatrizGuthie.destroy({
            where: { id_demanda: idDemanda },
            ...options
        });
    }
}

module.exports = MatrizGuthieService;