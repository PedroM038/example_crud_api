/**
 * @file services/log_historico_service.js
 * @description Serviço para gerenciar histórico de ações nas demandas.
 * @author Pedro e Rafaela
 */

const { models } = require('../models/associations');

class LogHistoricoDemandasService {

    /**
     * Registra uma ação no histórico
     * @param {Object} dados - Dados do registro
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Object>} Registro criado
     */
    static async registrar(dados, options = {}) {
        return models.LogHistoricoDemandas.create({
            id_demanda: dados.idDemanda,
            acao: dados.acao,
            usuario: dados.usuario,
            detalhes: dados.detalhes || null
        }, options);
    }

    /**
     * Busca histórico por demanda
     * @param {number} idDemanda - ID da demanda
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Array>} Lista de registros ordenados por data
     */
    static async buscarPorDemanda(idDemanda, options = {}) {
        return models.LogHistoricoDemandas.findAll({
            where: { id_demanda: idDemanda },
            order: [['data_hora', 'DESC']],
            ...options
        });
    }

    /**
     * Busca histórico por tipo de ação
     * @param {string} acao - Tipo de ação (criacao, edicao, exclusao)
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Array>} Lista de registros
     */
    static async buscarPorAcao(acao, options = {}) {
        return models.LogHistoricoDemandas.findAll({
            where: { acao },
            order: [['data_hora', 'DESC']],
            ...options
        });
    }

    /**
     * Busca todo o histórico
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Array>} Lista de todos os registros
     */
    static async buscarTodos(options = {}) {
        return models.LogHistoricoDemandas.findAll({
            order: [['data_hora', 'DESC']],
            ...options
        });
    }
}

module.exports = LogHistoricoDemandasService;