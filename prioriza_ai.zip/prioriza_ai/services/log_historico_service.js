/**
 * @file services/historicoService.js
 * @description Serviço para gerenciar as operações relacionadas ao histórico de ações nas demandas.
 * Inclui registro de ações como criação, edição, exclusão, etc.
 * @author Pedro e Rafaela
 */

const Historico = require('../models/log_historico_demandas');

class HistoricoService {

    // Registra uma nova ação no histórico
    static async registraAcao(id_demanda, acao, usuario, detalhes = null) {
        try {
            const novoRegistro = await Historico.create({
                id_demanda,
                acao,
                usuario,
                detalhes
            });
            return novoRegistro;
        } catch (error) {
            console.error("Erro ao registrar ação no histórico:", error);
            throw new Error("Erro ao registrar ação no histórico");
        }
    }

    // Busca histórico por ID da demanda
    static async buscaHistoricoPorDemanda(id_demanda) {
        try {
            const historico = await Historico.findAll({
                where: { id_demanda },
                order: [['data_hora', 'DESC']]
            });
            return historico;
        } catch (error) {
            console.error("Erro ao buscar histórico por demanda:", error);
            throw new Error("Erro ao buscar histórico por demanda");
        }
    }
}

module.exports = HistoricoService;