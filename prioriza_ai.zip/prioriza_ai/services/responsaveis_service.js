/**
 * @file services/responsaveis_service.js
 * @description CRUD de responsáveis de demandas do tipo Melhoria.
 */

const { models } = require('../models/associations');

class ResponsaveisMelhoriaService {

    /**
     * Busca responsáveis de uma demanda com dados dos estagiários
     */
    static async buscarPorDemanda(idDemanda, options = {}) {
        return models.ResponsaveisMelhoria.findOne({
            where: { id_demanda: idDemanda },
            include: [
                {
                    model: models.TipEstagiarios,
                    as: 'estagiarioAtan',
                    attributes: ['id', 'nome', 'matricula']
                },
                {
                    model: models.TipEstagiarios,
                    as: 'estagiarioAtanAux',
                    attributes: ['id', 'nome', 'matricula']
                },
                {
                    model: models.TipEstagiarios,
                    as: 'estagiarioDesign',
                    attributes: ['id', 'nome', 'matricula']
                },
                {
                    model: models.TipEstagiarios,
                    as: 'estagiarioDesignAux',
                    attributes: ['id', 'nome', 'matricula']
                }
            ],
            ...options
        });
    }

    /**
     * Cria ou atualiza responsáveis de uma demanda (upsert)
     */
    static async salvar(idDemanda, dados, options = {}) {
        const responsaveisData = {
            funci_atan: dados.funci_atan || null,
            funci_atan_aux: dados.funci_atan_aux || null,
            funci_design: dados.funci_design || null,
            funci_design_aux: dados.funci_design_aux || null,
            estagiario_atan: dados.estagiario_atan_id || null,
            estagiario_atan_aux: dados.estagiario_atan_aux_id || null,
            estagiario_design: dados.estagiario_design_id || null,
            estagiario_design_aux: dados.estagiario_design_aux_id || null
        };

        const [responsaveis, created] = await models.ResponsaveisMelhoria.findOrCreate({
            where: { id_demanda: idDemanda },
            defaults: { id_demanda: idDemanda, ...responsaveisData },
            ...options
        });

        if (!created) {
            await responsaveis.update(responsaveisData, options);
        }

        return responsaveis;
    }

    /**
     * Remove responsáveis de uma demanda
     */
    static async removerPorDemanda(idDemanda, options = {}) {
        const deleted = await models.ResponsaveisMelhoria.destroy({
            where: { id_demanda: idDemanda },
            ...options
        });
        return deleted > 0;
    }
}

module.exports = ResponsaveisMelhoriaService;