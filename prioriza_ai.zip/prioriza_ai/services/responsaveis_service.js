/**
 * @file services/responsaveisService.js
 * @description Service responsável por gerenciar responsáveis das demandas
 * @author Pedro e Rafaela
 */

const funcionariosService = require('./funcionarios_service');
const estagiariosService = require('./estagiarios_service');
const { ResponsaveisMelhoria, Estagiarios } = require('../models/associations');

const ResponsaveisService = {

    // Constantes para UORs
    UOR_ATAN: 286527,
    UOR_DESIGN: 286521,
   
    /**
     * Busca todos os responsáveis da equipe ATAN (funcionários + estagiários)
     * @returns {Promise<Object>}
     */
    async buscaTodosResponsaveisAtan() {
        const [funcionarios, estagiarios] = await Promise.all([
            funcionariosService.buscaFuncionariosAtan(),
            estagiariosService.buscaEstagiariosAtan()
        ]);

        return {
            funcionarios,
            estagiarios
        };
    },

    /**
     * Busca todos os funcionários da equipe ATAN
     * @returns {Promise<Array>}
     */
    async buscaFuncionariosAtan() {
        return await funcionariosService.buscaFuncionariosAtan();
    },
     
    /**
     * Busca todos os estagiários da equipe ATAN
     * @returns {Promise<Array>}
     */

    async buscaEstagiariosAtan() {
        return await estagiariosService.buscaEstagiariosAtan();
    },

    /**
     * Busca todos os funcionários da equipe DESIGN
     * @returns {Promise<Array>}
     */
    async buscaFuncionariosDesign() {
        return await funcionariosService.buscaFuncionariosDesign();
    },

    /**
     * Busca todos os estagiários da equipe DESIGN
     * @returns {Promise<Array>}
     */
    async buscaEstagiariosDesign() {
        return await estagiariosService.buscaEstagiariosDesign();
    },

    /**
     * Busca todos os responsáveis da equipe DESIGN (funcionários + estagiários)
     * @returns {Promise<Object>}
     */
    async buscaTodosResponsaveisDesign() {
        const [funcionarios, estagiarios] = await Promise.all([
            funcionariosService.buscaFuncionariosDesign(),
            estagiariosService.buscaEstagiariosDesign()
        ]);

        return {
            funcionarios,
            estagiarios
        };
    },

    /**
     * Busca todos os responsáveis de ambas as equipes
     * @returns {Promise<Object>}
     */
    async buscaTodosResponsaveis() {
        const [atan, design] = await Promise.all([
            this.buscaTodosResponsaveisAtan(),
            this.buscaTodosResponsaveisDesign()
        ]);

        return {
            atan,
            design
        };
    },

    /**
     * Busca responsáveis de uma demanda Melhoria específica
     * @param {number} idDemanda
     * @returns {Promise<Object|null>}
     */
    async buscaResponsaveisPorDemanda(idDemanda) {
        const responsaveis = await ResponsaveisMelhoria.findOne({
            where: { id_demanda: idDemanda },
            include: [
                {
                    model: Estagiarios,
                    as: 'estagiarioAtanInfo',
                    attributes: ['id', 'nome', 'matricula']
                },
                {
                    model: Estagiarios,
                    as: 'estagiarioAtanAuxInfo',
                    attributes: ['id', 'nome', 'matricula']
                },
                {
                    model: Estagiarios,
                    as: 'estagiarioDesignInfo',
                    attributes: ['id', 'nome', 'matricula']
                },
                {
                    model: Estagiarios,
                    as: 'estagiarioDesignAuxInfo',
                    attributes: ['id', 'nome', 'matricula']
                }
            ]
        });

        if (!responsaveis) return null;

        return {
            id: responsaveis.id,
            id_demanda: responsaveis.id_demanda,
            funci_atan: responsaveis.funci_atan,
            funci_atan_aux: responsaveis.funci_atan_aux,
            funci_design: responsaveis.funci_design,
            funci_design_aux: responsaveis.funci_design_aux,
            estagiario_atan_id: responsaveis.estagiario_atan,
            estagiario_atan_nome: responsaveis.estagiarioAtanInfo?.nome || null,
            estagiario_atan_aux_id: responsaveis.estagiario_atan_aux,
            estagiario_atan_aux_nome: responsaveis.estagiarioAtanAuxInfo?.nome || null,
            estagiario_design_id: responsaveis.estagiario_design,
            estagiario_design_nome: responsaveis.estagiarioDesignInfo?.nome || null,
            estagiario_design_aux_id: responsaveis.estagiario_design_aux,
            estagiario_design_aux_nome: responsaveis.estagiarioDesignAuxInfo?.nome || null
        };
    },

    /**
     * Cria ou atualiza responsáveis de uma demanda Melhoria
     * @param {number} idDemanda
     * @param {Object} dados - Objeto com os campos de responsáveis
     * @param {Object} transaction - Transação Sequelize opcional
     * @returns {Promise<Object>}
     */
    async atualizaResponsaveisDemanda(idDemanda, dados, transaction = null) {
        const {
            funci_atan,
            funci_atan_aux,
            funci_design,
            funci_design_aux,
            estagiario_atan_id,
            estagiario_atan_aux_id,
            estagiario_design_id,
            estagiario_design_aux_id
        } = dados;

        // Verificar se já existe registro de responsáveis para esta demanda
        let responsaveis = await ResponsaveisMelhoria.findOne({
            where: { id_demanda: idDemanda },
            transaction
        });

        const responsaveisData = {
            funci_atan: funci_atan || null,
            funci_atan_aux: funci_atan_aux || null,
            funci_design: funci_design || null,
            funci_design_aux: funci_design_aux || null,
            estagiario_atan: estagiario_atan_id || null,
            estagiario_atan_aux: estagiario_atan_aux_id || null,
            estagiario_design: estagiario_design_id || null,
            estagiario_design_aux: estagiario_design_aux_id || null
        };

        if (responsaveis) {
            // Atualizar registro existente
            await responsaveis.update(responsaveisData, { transaction });
        } else {
            // Criar novo registro
            responsaveisData.id_demanda = idDemanda;
            responsaveis = await ResponsaveisMelhoria.create(responsaveisData, { transaction });
        }

        return responsaveis;
    },

    /**
     * Remove responsáveis de uma demanda
     * @param {number} idDemanda
     * @param {Object} transaction - Transação Sequelize opcional
     * @returns {Promise<number>}
     */
    async removeResponsaveisPorDemanda(idDemanda, transaction = null) {
        return await ResponsaveisMelhoria.destroy({
            where: { id_demanda: idDemanda },
            transaction
        });
    },
};

module.exports = ResponsaveisService;