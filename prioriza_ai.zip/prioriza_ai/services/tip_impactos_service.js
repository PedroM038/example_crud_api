const tip_impactos = require('../models/tip_impactos');

class tip_impactos_service {
    static async buscaTodosImpactos() {
        try {
            const impactos = await tip_impactos.findAll({
                attributes: ['id', 'peso', 'pontos', 'legenda'],
                order: [['peso', 'ASC']]
            });
            return impactos;
        } catch (error) {
            console.error("Erro ao buscar impactos:", error);
            throw new Error("Erro ao buscar impactos");
        }
    }

    static async criaImpacto(impactoData) {
        try {
            const novoImpacto = await tip_impactos.create(impactoData);
            return novoImpacto;
        } catch (error) {
            console.error("Erro ao criar impacto:", error);
            throw new Error("Erro ao criar impacto");
        }
    }

    static async atualizaImpacto(id, impactoData) {
        try {
            const [updated] = await tip_impactos.update(impactoData, {
                where: { id: id }
            });
            if (updated) {
                const updatedImpacto = await tip_impactos.findByPk(id);
                return updatedImpacto;
            }
            throw new Error("Impacto não encontrado");
        } catch (error) {
            console.error("Erro ao atualizar impacto:", error);
            throw new Error("Erro ao atualizar impacto");
        }
    }
}

module.exports = tip_impactos_service;