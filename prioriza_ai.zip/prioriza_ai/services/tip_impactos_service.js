const { models } = require('../models/associations');

class TipImpactosService {

    static async buscarTodos(options = {}) {
        return models.TipImpactos.findAll({
            attributes: ['id', 'peso', 'pontos', 'legenda'],
            order: [['peso', 'ASC']],
            ...options
        });
    }

    static async criar(data, options = {}) {
        return models.TipImpactos.create(data, options);
    }

    static async atualizar(id, data, options = {}) {
        const [updated] = await models.TipImpactos.update(data, {
            where: { id },
            ...options
        });
        if (!updated) throw new Error('Impacto não encontrado');
        return models.TipImpactos.findByPk(id, options);
    }
}

module.exports = TipImpactosService;