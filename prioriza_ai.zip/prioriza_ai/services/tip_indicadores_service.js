const { models } = require('../models/associations');

class TipIndicadoresService {

    static async buscarTodos(options = {}) {
        return models.TipIndicadores.findAll({
            attributes: ['id', 'indicador', 'deletedAt'],
            order: [['indicador', 'ASC']],
            paranoid: false,
            ...options
        });
    }

    static async buscarAtivos(options = {}) {
        return models.TipIndicadores.findAll({
            attributes: ['id', 'indicador'],
            order: [['indicador', 'ASC']],
            ...options
        });
    }

    static async criar(data, options = {}) {
        return models.TipIndicadores.create(data, options);
    }

    static async atualizar(id, data, options = {}) {
        const [updated] = await models.TipIndicadores.update(data, {
            where: { id },
            ...options
        });
        if (!updated) throw new Error('Indicador não encontrado');
        return models.TipIndicadores.findByPk(id, options);
    }

    static async deletar(id, options = {}) {
        const deleted = await models.TipIndicadores.destroy({
            where: { id },
            ...options
        });
        if (!deleted) throw new Error('Indicador não encontrado');
    }

    static async restaurar(id, options = {}) {
        const restored = await models.TipIndicadores.restore({
            where: { id },
            ...options
        });
        if (!restored) throw new Error('Indicador não encontrado');
    }
}

module.exports = TipIndicadoresService;