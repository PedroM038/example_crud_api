const tip_indicadores = require('../models/tip_indicadores');

class tip_indicadores_service {
    static async buscaTodosIndicadores() {
        try {
            const indicadores = await tip_indicadores.findAll({
                attributes: ['id', 'indicador', 'deletedAt'],
                order: [['indicador', 'ASC']],
                paranoid: false
            });
            return indicadores;
        } catch (error) {
            console.error("Erro ao buscar indicadores:", error);
            throw new Error("Erro ao buscar indicadores");
        }
    }

    static async buscaTodosIndicadoresAtivos() {
        try {
            const indicadores = await tip_indicadores.findAll({
                attributes: ['id', 'indicador', 'deletedAt'],
                order: [['indicador', 'ASC']],
                paranoid: true
            });
            return indicadores;
        } catch (error) {
            console.error("Erro ao buscar indicadores:", error);
            throw new Error("Erro ao buscar indicadores");
        }
    }

    static async criaIndicador(indicadorData) {
        try {
            const novoIndicador = await tip_indicadores.create(indicadorData);
            return novoIndicador;
        } catch (error) {
            console.error("Erro ao criar indicador:", error);
            throw new Error("Erro ao criar indicador");
        }
    }

    static async atualizaIndicador(id, indicadorData) {
        try {
            const [updated] = await tip_indicadores.update(indicadorData, {
                where: { id: id }
            });
            if (updated) {
                const updatedIndicador = await tip_indicadores.findByPk(id);
                return updatedIndicador;
            }
            throw new Error("Indicador não encontrado");
        } catch (error) {
            console.error("Erro ao atualizar indicador:", error);
            throw new Error("Erro ao atualizar indicador");
        }
    }

    static async deletaIndicador(id) {
        try {
            const deleted = await tip_indicadores.destroy({
                where: { id: id }
            });
            if (deleted) {
                return { message: "Indicador deletado com sucesso" };
            }
            throw new Error("Indicador não encontrado");
        } catch (error) {
            console.error("Erro ao deletar indicador:", error);
            throw new Error("Erro ao deletar indicador");
        }
    }

    static async restauraIndicador(id) {
        try {
            const restored = await tip_indicadores.restore({
                where: { id: id }
            });
            if (restored) {
                return { message: "Indicador restaurado com sucesso" };
            }
            throw new Error("Indicador não encontrado ou não estava deletado");
        } catch (error) {
            console.error("Erro ao restaurar indicador:", error);
            throw new Error("Erro ao restaurar indicador");
        }
    }
}

module.exports = tip_indicadores_service;