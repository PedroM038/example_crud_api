const tip_areas = require('../models/tip_areas');

class tip_areas_service {

    static async buscaTodasAreas() {
        try {
            const areas = await tip_areas.findAll({
                attributes: ['id', 'area', 'deletedAt'],
                order: [['area', 'ASC']],
                paranoid: false
            });
            return areas;
        } catch (error) {
            console.error("Erro ao buscar áreas:", error);
            throw new Error("Erro ao buscar áreas");
        }
    }

    static async buscaTodasAreasAtivas() {
        try {
            const areas = await tip_areas.findAll({
                attributes: ['id', 'area', 'deletedAt'],
                order: [['area', 'ASC']],
                paranoid: true
            });
            return areas;
        } catch (error) {
            console.error("Erro ao buscar áreas:", error);
            throw new Error("Erro ao buscar áreas");
        }
    }

    static async criaArea(areaData) {
        try {
            const novaArea = await tip_areas.create(areaData);
            return novaArea;
        } catch (error) {
            console.error("Erro ao criar área:", error);
            throw new Error("Erro ao criar área");
        }
    }

    static async atualizaArea(id, areaData) {
        try {
            const [updated] = await tip_areas.update(areaData, {
                where: { id: id }
            });
            if (updated) {
                const updatedArea = await tip_areas.findByPk(id);
                return updatedArea;
            }
            throw new Error("Área não encontrada");
        } catch (error) {
            console.error("Erro ao atualizar área:", error);
            throw new Error("Erro ao atualizar área");
        }
    }

    static async deletaArea(id) {
        try {
            const deleted = await tip_areas.destroy({
                where: { id: id }
            });
            if (deleted) {
                return { message: "Área deletada com sucesso" };
            }
            throw new Error("Área não encontrada");
        } catch (error) {
            console.error("Erro ao deletar área:", error);
            throw new Error("Erro ao deletar área");
        }
    }

    static async restauraArea(id) {
        try {
            const restored = await tip_areas.restore({
                where: { id: id }
            });
            if (restored) {
                return { message: "Área restaurada com sucesso" };
            }
            throw new Error("Área não encontrada ou não estava deletada");
        } catch (error) {
            console.error("Erro ao restaurar área:", error);
            throw new Error("Erro ao restaurar área");
        }
    }
}

module.exports = tip_areas_service;