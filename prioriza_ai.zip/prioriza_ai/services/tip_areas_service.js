const { models } = require('../models/associations');

class TipAreasService {

    static async buscarTodas(options = {}) {
        return models.TipAreas.findAll({
            attributes: ['id', 'area', 'deletedAt'],
            order: [['area', 'ASC']],
            paranoid: false,
            ...options
        });
    }

    static async buscarAtivas(options = {}) {
        return models.TipAreas.findAll({
            attributes: ['id', 'area'],
            order: [['area', 'ASC']],
            ...options
        });
    }

    static async criar(data, options = {}) {
        return models.TipAreas.create(data, options);
    }

    static async atualizar(id, data, options = {}) {
        const [updated] = await models.TipAreas.update(data, {
            where: { id },
            ...options
        });
        if (!updated) throw new Error('Área não encontrada');
        return models.TipAreas.findByPk(id, options);
    }

    static async deletar(id, options = {}) {
        const deleted = await models.TipAreas.destroy({
            where: { id },
            ...options
        });
        if (!deleted) throw new Error('Área não encontrada');
    }

    static async restaurar(id, options = {}) {
        const restored = await models.TipAreas.restore({
            where: { id },
            ...options
        });
        if (!restored) throw new Error('Área não encontrada');
    }
}

module.exports = TipAreasService;