const tip_motivos = require('../models/tip_motivos');

class tip_motivos_service {

    static async buscaTodosMotivos() {
        try {
            const motivos = await tip_motivos.findAll({
                attributes: ['id', 'motivo', 'deletedAt'],
                order: [['motivo', 'ASC']],
                paranoid: false
            });
            return motivos;
        } catch (error) {
            console.error("Erro ao buscar motivos:", error);
            throw new Error("Erro ao buscar motivos");
        }
    }

    static async buscaTodosMotivosAtivos() {
        try {
            const motivos = await tip_motivos.findAll({
                attributes: ['id', 'motivo', 'deletedAt'],
                order: [['motivo', 'ASC']],
                paranoid: true
            });
            return motivos;
        } catch (error) {
            console.error("Erro ao buscar motivos:", error);
            throw new Error("Erro ao buscar motivos");
        }
    }

    static async criaMotivos(motivosData) {
        try {
            const novoMotivo = await tip_motivos.create(motivosData);
            return novoMotivo;
        } catch (error) {
            console.error("Erro ao criar motivo:", error);
            throw new Error("Erro ao criar motivo");
        }
    }

    static async atualizaMotivo(id, motivoData) {
        try {
            const [updated] = await tip_motivos.update(motivoData, {
                where: { id: id }
            });
            if (updated) {
                const updatedMotivo = await tip_motivos.findByPk(id);
                return updatedMotivo;
            }
            throw new Error("Motivo não encontrada");
        } catch (error) {
            console.error("Erro ao atualizar motivo:", error);
            throw new Error("Erro ao atualizar motivo");
        }
    }

    static async deletaMotivo(id) {
        try {
            const deleted = await tip_motivos.destroy({
                where: { id: id }
            });
            if (deleted) {
                return { message: "Motivo deletada com sucesso" };
            }
            throw new Error("Motivo não encontrado");
        } catch (error) {
            console.error("Erro ao deletar motivo:", error);
            throw new Error("Erro ao deletar motivo");
        }
    }

    static async restauraMotivo(id) {
        try {
            const restored = await tip_motivos.restore({
                where: { id: id }
            });
            if (restored) {
                return { message: "Motivo restaurada com sucesso" };
            }
            throw new Error("Motivo não encontrada ou não estava deletada");
        } catch (error) {
            console.error("Erro ao restaurar motivo:", error);
            throw new Error("Erro ao restaurar motivo");
        }
    }
}

module.exports = tip_motivos_service;