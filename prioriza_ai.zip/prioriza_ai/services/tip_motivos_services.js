const { models } = require('../models/associations');

class TipMotivosService {

    static async buscarTodos(options = {}) {
        return models.TipMotivos.findAll({
            attributes: ['id', 'motivo', 'deletedAt'],
            order: [['motivo', 'ASC']],
            paranoid: false,
            ...options
        });
    }

    static async buscarAtivos(options = {}) {
        return models.TipMotivos.findAll({
            attributes: ['id', 'motivo'],
            order: [['motivo', 'ASC']],
            ...options
        });
    }

    static async criar(data, options = {}) {
        return models.TipMotivos.create(data, options);
    }

    static async atualizar(id, data, options = {}) {
        const [updated] = await models.TipMotivos.update(data, {
            where: { id },
            ...options
        });
        if (!updated) throw new Error('Motivo não encontrado');
        return models.TipMotivos.findByPk(id, options);
    }

    static async deletar(id, options = {}) {
        const deleted = await models.TipMotivos.destroy({
            where: { id },
            ...options
        });
        if (!deleted) throw new Error('Motivo não encontrado');
    }

    static async restaurar(id, options = {}) {
        const restored = await models.TipMotivos.restore({
            where: { id },
            ...options
        });
        if (!restored) throw new Error('Motivo não encontrado');
    }
}

module.exports = TipMotivosService;