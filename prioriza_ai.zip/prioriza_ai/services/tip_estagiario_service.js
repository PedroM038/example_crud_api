/**
 * @file services/tip_estagiario_service.js
 * @description Service para operações relacionadas ao model
 * tip_estagiarios
 */

const tip_estagiarios = require('../models/tip_estagiarios');

class tip_estagiarios_service {

    static async buscaTodosEstagiarios() {
        try{
            const estagiarios = await tip_estagiarios.findAll({
                attributes: ['id', 'equipe', 'matricula', 'nome', 'deletedAt'],
                paranoid: false
            })
            return estagiarios
        } catch (error) {
            console.error("Erro ao buscar os estagiários", error);
            throw new Error("Erro ao buscar os estagiários");
        }
    }

    static async buscaTodosEstagiariosAtivos() {
        try{
            const estagiarios = await tip_estagiarios.findAll({
                attributes: ['id', 'equipe', 'matricula', 'nome', 'deletedAt'],
                paranoid: true
            })
            return estagiarios
        } catch (error) {
            console.error("Erro ao buscar os estagiários", error);
            throw new Error("Erro ao buscar os estagiários");
        }
    }

    static async criaEstagiario(estagiario) {
        try {
            const novoEstagiario = await tip_estagiarios.create(estagiario);
            return novoEstagiario;
        } catch (error) {
            console.error("Erro ao criar estagiário: ", error);
            throw new Error("Erro ao criar estagiário");
        }
    }

    static async atualizaEstagiario(id, novosDados) {
        try {
            const [updated] = await tip_estagiarios.update(novosDados, {
                where: {id: id}
            });
            if (updated) {
                const estagiarioAtualizado = await tip_estagiarios.findByPk(id);
                return estagiarioAtualizado;
            }
            throw new Error("Estagiário não encontrado");
        } catch (error) {
            console.error("Erro ao atualizar o estagiário: ", error);
            throw new Error("Erro ao atualizar o estagiário");
        }
    }

    static async deletaEstagiario(id) {
        try {
            const deleted = await tip_estagiarios.destroy({
                where: { id: id }
            });
            if (deleted) {
                return { message: "Estagiário deletado com sucesso" };
            }
            throw new Error("Estagiário não encontrado");
        } catch (error) {
            console.error("Erro ao deletar estagiário:", error);
            throw new Error("Erro ao deletar estagiário");
        }
    }

    static async restauraEstagiario(id) {
        try {
            const restored = await tip_estagiarios.restore({
                where: { id: id }
            });
            if (restored) {
                return { message: "Estagiário restaurado com sucesso" };
            }
            throw new Error("Estagiário não encontrado ou não estava deletado");
        } catch (error) {
            console.error("Erro ao restaurar estagiário:", error);
            throw new Error("Erro ao restaurar estagiário");
        }
    }
}

module.exports = tip_estagiarios_service