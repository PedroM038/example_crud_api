/**
 * @file services/tip_estagiario_service.js
 * @description Service para operações de estagiários.
 */

const { models } = require('../models/associations');

class TipEstagiariosService {

    static async buscarTodos(options = {}) {
        return models.TipEstagiarios.findAll({
            attributes: ['id', 'equipe', 'matricula', 'nome', 'deletedAt'],
            paranoid: false,
            ...options
        });
    }

    static async buscarAtivos(options = {}) {
        return models.TipEstagiarios.findAll({
            attributes: ['id', 'equipe', 'matricula', 'nome'],
            ...options
        });
    }

    /**
     * Busca estagiários ativos por equipe
     * @param {'Automação'|'Design'} equipe
     */
    static async buscarPorEquipe(equipe, options = {}) {
        const { where = {}, ...restOptions } = options;
        return models.TipEstagiarios.findAll({
            attributes: ['id', 'equipe', 'matricula', 'nome'],
            where: { equipe, ...where },
            order: [['nome', 'ASC']],
            ...restOptions
        });
    }

    static async criar(data, options = {}) {
        return models.TipEstagiarios.create(data, options);
    }

    static async atualizar(id, data, options = {}) {
        const [updated] = await models.TipEstagiarios.update(data, {
            where: { id },
            ...options
        });
        if (!updated) throw new Error('Estagiário não encontrado');
        return models.TipEstagiarios.findByPk(id, options);
    }

    static async deletar(id, options = {}) {
        const deleted = await models.TipEstagiarios.destroy({
            where: { id },
            ...options
        });
        if (!deleted) throw new Error('Estagiário não encontrado');
    }

    static async restaurar(id, options = {}) {
        const restored = await models.TipEstagiarios.restore({
            where: { id },
            ...options
        });
        if (!restored) throw new Error('Estagiário não encontrado');
    }
}

module.exports = TipEstagiariosService;