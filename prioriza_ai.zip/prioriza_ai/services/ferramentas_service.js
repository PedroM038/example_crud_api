/**
 * @file services/ferramentas_service.js
 * @description Serviço para buscar ferramentas via API CESUP (rede interna).
 * @author Pedro e Rafaela
 */

const axios = require('axios');

// Configurações
const CONFIG = {
    apiUrl: 'https://cesupsuprimentos.intranet.bb.com.br/api/apps',
    timeout: 5000,
    cacheDuration: 5 * 60 * 1000 // 5 minutos
};

// Cache simples
let cache = { data: null, timestamp: null };

class FerramentasService {

    /**
     * Busca todas as ferramentas (com cache)
     * @param {string} cookies - Cookies para autenticação na API interna
     * @returns {Promise<Array>} Lista de ferramentas
     */
    static async buscarTodas(cookies = '') {
        // Retorna cache se válido
        if (this._cacheValido()) {
            return cache.data;
        }

        try {
            const response = await axios.get(CONFIG.apiUrl, {
                timeout: CONFIG.timeout,
                headers: {
                    'Accept': 'application/json',
                    'Cookie': cookies
                }
            });

            const ferramentas = this._formatarResposta(response.data);
            this._atualizarCache(ferramentas);
            return ferramentas;

        } catch (error) {
            // Fallback: cache expirado
            if (cache.data) {
                console.warn('[FerramentasService] API indisponível, usando cache');
                return cache.data;
            }

            // Sem cache disponível: retorna vazio (não quebra a aplicação)
            console.warn('[FerramentasService] API CESUP indisponível - verifique a conexão com a rede interna');
            return [];
        }
    }

    /**
     * Busca ferramenta por ID
     * @param {number} id - ID da ferramenta
     * @param {string} cookies - Cookies para autenticação
     * @returns {Promise<Object|null>} Ferramenta ou null
     */
    static async buscarPorId(id, cookies = '') {
        const ferramentas = await this.buscarTodas(cookies);
        return ferramentas.find(f => f.id === parseInt(id)) || null;
    }

    /**
     * Limpa o cache (força nova busca na próxima chamada)
     */
    static limparCache() {
        cache = { data: null, timestamp: null };
    }

    /**
     * Verifica se o cache ainda é válido
     * @private
     */
    static _cacheValido() {
        return cache.data && cache.timestamp && 
               (Date.now() - cache.timestamp < CONFIG.cacheDuration);
    }

    /**
     * Atualiza o cache
     * @private
     */
    static _atualizarCache(data) {
        cache = { data, timestamp: Date.now() };
    }

    /**
     * Formata resposta da API para o padrão da aplicação
     * @private
     */
    static _formatarResposta(data) {
        return data
            .map(item => ({
                id: item.ID,
                ferramenta: item.Nome,
                urlAplicacao: item.UrlAplicacao,
                linguagem: item.Linguagem,
                urlRepositorio: item.UrlRepositorio,
                devResponsavel: item.DevResponsavel,
                funcisUsuarios: item.FuncisUsuarios,
                servidorHospedagem: item.ServidorHospedagem?.Apelido || null,
                servidorBd: item.ServidorBd?.Apelido || null
            }))
            .sort((a, b) => a.ferramenta.localeCompare(b.ferramenta));
    }
}

module.exports = FerramentasService;