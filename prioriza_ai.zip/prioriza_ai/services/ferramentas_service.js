/**
 * @file services/ferramentaService.js
 * @description Service para operações relacionadas às ferramentas.
 * Agora busca dados via API CESUP ao invés de tabela local.
 * @author Pedro e Rafaela
 */

const axios = require('axios');

// URL base da API CESUP
const API_CESUP_URL = "https://cesupsuprimentos.intranet.bb.com.br/api/apps";

// Cache simples para evitar requisições repetidas
let cacheFerramentas = null;
let cacheTimestamp = null;
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutos em milissegundos

class FerramentaService {

    /**
     * Busca todas as ferramentas da API CESUP
     * @param {string} cookies - Cookies da requisição para autenticação
     * @returns {Promise<Array>} Lista de ferramentas formatadas
     */
    static async buscaTodasFerramentas(cookies = '') {
        try {
            // Verifica se o cache ainda é válido
            if (cacheFerramentas && cacheTimestamp && (Date.now() - cacheTimestamp < CACHE_DURATION)) {
                return cacheFerramentas;
            }

            const response = await axios.get(API_CESUP_URL, {
                timeout: 5000,
                headers: {
                    'Accept': 'application/json',
                    'Cookie': cookies,
                },
            });

            // Mapeia os dados da API para o formato esperado pela aplicação
            const ferramentas = response.data.map(item => ({
                id: item.ID,
                ferramenta: item.Nome,
                urlAplicacao: item.UrlAplicacao,
                linguagem: item.Linguagem,
                urlRepositorio: item.UrlRepositorio,
                devResponsavel: item.DevResponsavel,
                funcisUsuarios: item.FuncisUsuarios,
                servidorHospedagem: item.ServidorHospedagem?.Apelido || null,
                servidorBd: item.ServidorBd?.Apelido || null
            }));

            // Ordena por nome da ferramenta
            ferramentas.sort((a, b) => a.ferramenta.localeCompare(b.ferramenta));

            // Atualiza o cache
            cacheFerramentas = ferramentas;
            cacheTimestamp = Date.now();

            return ferramentas;
        } catch (error) {
            console.error("Erro ao buscar ferramentas da API CESUP:", error.message);
            
            // Se houver cache expirado, retorna ele como fallback
            if (cacheFerramentas) {
                console.warn("Usando cache expirado como fallback");
                return cacheFerramentas;
            }
            
            throw new Error("Erro ao buscar ferramentas da API: " + error.message);
        }
    }

    /**
     * Busca ferramenta por ID na API CESUP
     * @param {number} id - ID da ferramenta
     * @param {string} cookies - Cookies da requisição para autenticação
     * @returns {Promise<Object|null>} Ferramenta encontrada ou null
     */
    static async buscaFerramentaPorId(id, cookies = '') {
        try {
            const ferramentas = await this.buscaTodasFerramentas(cookies);
            const ferramenta = ferramentas.find(f => f.id === parseInt(id));
            return ferramenta || null;
        } catch (error) {
            console.error("Erro ao buscar ferramenta por ID:", error.message);
            throw new Error("Erro ao buscar ferramenta por ID: " + error.message);
        }
    }

    /**
     * Busca apenas o nome da ferramenta por ID
     * Útil para mapeamento em outras consultas
     * @param {number} id - ID da ferramenta
     * @param {string} cookies - Cookies da requisição para autenticação
     * @returns {Promise<string|null>} Nome da ferramenta ou null
     */
    static async buscaNomeFerramentaPorId(id, cookies = '') {
        try {
            const ferramenta = await this.buscaFerramentaPorId(id, cookies);
            return ferramenta ? ferramenta.ferramenta : null;
        } catch (error) {
            console.error("Erro ao buscar nome da ferramenta:", error.message);
            return null;
        }
    }

    /**
     * Limpa o cache de ferramentas
     * Útil para forçar uma nova busca na API
     */
    static limpaCache() {
        cacheFerramentas = null;
        cacheTimestamp = null;
    }
}

module.exports = FerramentaService;