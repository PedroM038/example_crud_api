
const tip_repeticoes = require('../models/tip_repeticoes');

class tip_repeticoes_service {
    static async buscaTodasRepeticoes() {
        try {
            const repeticoes = await tip_repeticoes.findAll({
                attributes: ['id', 'repeticao', 'repeticao_freq', 'calc_repeticao'],
                order: [['calc_repeticao', 'ASC']]
            });
            return repeticoes;
        } catch (error) {
            console.error("Erro ao buscar repetições:", error);
            throw new Error("Erro ao buscar repetições");
        }
    }

    static async criaRepeticao(repeticaoData) {
        try {
            const novaRepeticao = await tip_repeticoes.create(repeticaoData);
            return novaRepeticao;
        } catch (error) {
            console.error("Erro ao criar repetição:", error);
            throw new Error("Erro ao criar repetição");
        }
    }

    static async atualizaRepeticao(id, repeticaoData) {
        try {
            const [updated] = await tip_repeticoes.update(repeticaoData, {
                where: { id: id }
            });
            if (updated) {
                const updatedRepeticao = await tip_repeticoes.findByPk(id);
                return updatedRepeticao;
            }
            throw new Error("Repetição não encontrada");
        } catch (error) {
            console.error("Erro ao atualizar repetição:", error);
            throw new Error("Erro ao atualizar repetição");
        }
    }
}

module.exports = tip_repeticoes_service;