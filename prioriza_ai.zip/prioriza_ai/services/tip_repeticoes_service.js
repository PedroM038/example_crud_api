
const { models } = require('../models/associations');

class TipRepeticoesService {

    static async buscarTodas(options = {}) {
        return models.TipRepeticoes.findAll({
            attributes: ['id', 'repeticao', 'repeticao_freq', 'calc_repeticao'],
            order: [['calc_repeticao', 'ASC']],
            ...options
        });
    }

    static async criar(data, options = {}) {
        return models.TipRepeticoes.create(data, options);
    }

    static async atualizar(id, data, options = {}) {
        const [updated] = await models.TipRepeticoes.update(data, {
            where: { id },
            ...options
        });
        if (!updated) throw new Error('Repetição não encontrada');
        return models.TipRepeticoes.findByPk(id, options);
    }
}

module.exports = TipRepeticoesService;