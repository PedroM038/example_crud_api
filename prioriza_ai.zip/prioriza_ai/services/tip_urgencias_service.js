const { models } = require('../models/associations');

class TipUrgenciasService {

    static async buscarTodas(options = {}) {
        return models.TipUrgencias.findAll({
            attributes: ['id', 'peso', 'pontos', 'legenda'],
            order: [['peso', 'ASC']],
            ...options
        });
    }

    static async criar(data, options = {}) {
        return models.TipUrgencias.create(data, options);
    }

    static async atualizar(id, data, options = {}) {
        const [updated] = await models.TipUrgencias.update(data, {
            where: { id },
            ...options
        });
        if (!updated) throw new Error('Urgência não encontrada');
        return models.TipUrgencias.findByPk(id, options);
    }
}

module.exports = TipUrgenciasService;