/**
 * @file services/urgenciaService.js
 * @description Service para operações relacionadas a urgência.
 * @author Pedro e Rafaela
 */

const tip_urgencia = require('../models/tip_urgencias');

class tip_urgencia_service {
    // Busca todas as urgências
    static async buscaTodasUrgencias() {
        try {
            const urgencias = await tip_urgencia.findAll({
                attributes: ['id', 'peso', 'pontos', 'legenda'],
                order: [['peso', 'ASC']]
            });
            return urgencias;
        } catch (error) {
            console.error("Erro ao buscar urgências:", error);
            throw new Error("Erro ao buscar urgências");
        }
    }

    // Cria nova urgência
    static async criaUrgencia(urgenciaData) {
        try {
            const novaUrgencia = await tip_urgencia.create(urgenciaData);
            return novaUrgencia;
        } catch (error) {
            console.error("Erro ao criar urgência:", error);
            throw new Error("Erro ao criar urgência");
        }
    }

    // Atualiza urgência existente
    static async atualizaUrgencia(id, urgenciaData) {
        try {
            const [updated] = await tip_urgencia.update(urgenciaData, {
                where: { id: id }
            });
            if (updated) {
                const updatedUrgencia = await tip_urgencia.findByPk(id);
                return updatedUrgencia;
            }
            throw new Error("Urgência não encontrada");
        }
        catch (error) {
            console.error("Erro ao atualizar urgência:", error);
            throw new Error("Erro ao atualizar urgência");
        }
    }
}

module.exports = tip_urgencia_service;