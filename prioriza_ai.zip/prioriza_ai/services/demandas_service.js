/**
 * @file services/demandaService.js
 * @description Serviço para gerenciar as operações relacionadas às demandas.
 * Inclui busca de demandas, atualização de dados, softDelete, etc.
 * @author Pedro e Rafaela
 */

const Demanda = require('../models/demandas');
const BugDefeito = require('../models/demandas_bug_defeito');
const Melhoria = require('../models/demandas_melhoria');
const matrizGuthieService = require('./matriz_guthie_service');
const horasFteService = require('./horas_fte_service');
const BugDefeitoService = require('./bug_defeito_service');
const MelhoriaService = require('./melhoria_service');
const { Op } = require('sequelize');

class DemandaService {

    // Busca todas as demandas ativas
    static async buscaDemandasAtivas() {
        try {

            // Buscar melhorias e bugs/defeitos já mapeada pelos services específicos
            const [melhorias, bugsDefeitos] = await Promise.all([
                MelhoriaService.buscaTodasDemandas(),
                BugDefeitoService.buscaTodasDemandas()
            ]);

            // Buscar as demais demandas ativas (outras tipologias)
            const demaisDemandasRaw = await Demanda.findAll({
                where: {
                    ativa: true,
                    tipologia: { [Op.notIn]: ['Bug', 'Defeito', 'Melhoria'] }
                }
            });

            const demaisDemandas = demaisDemandasRaw.map(demanda => ({
                id_demanda: demanda.id_demanda,
                nome: demanda.nome,
                semestre: demanda.semestre,
                ano: demanda.ano,
                tipologia: demanda.tipologia,
                numero_gd: demanda.numero_gd,
                ativa: demanda.ativa,
                score: null,
                prioridade_guthie: null,
                prioridade_comite: null,
                status: null,
                createdAt: demanda.createdAt
            }));

            // Combina todas as demandas em um único array e ordena por data de criação (mais recentes primeiro)
            const todasDemandas = [...melhorias, ...bugsDefeitos, ...demaisDemandas];
            return todasDemandas.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        } catch (error) {
            console.error("Erro ao buscar demandas ativas:", error);
            throw new Error("Erro ao buscar demandas ativas");
        }
    }

    // Busca demanda por ID
    static async buscaDemandaPorId(id) {
        try {
            // traz todos os campos da demanda se ela for encontrada e estiver ativa
            // caso contrário, retorna null
            const demanda = await Demanda.findOne({
                where: { id_demanda: id, ativa: true }
            });
            if (!demanda) {
                throw new Error("Demanda não encontrada");
            }
            return demanda;
        } catch (error) {
            console.error("Erro ao buscar demanda por ID:", error);
            throw new Error("Erro ao buscar demanda por ID");
        }
    }

    // Busca por tipologia
    static async buscaDemandasPorTipologia(tipologia) {
        try {
            const demandas = await Demanda.findAll({
                where: { tipologia: tipologia },
                order: [['id_demanda', 'ASC']]
            });
            return demandas;
        } catch (error) {
            console.error("Erro ao buscar demandas por tipologia:", error);
            throw new Error("Erro ao buscar demandas por tipologia");
        }
    }

    // Atualiza dados da demanda
    static async atualizaDemanda(id, dadosAtualizados) {
        try {
            const [updated] = await Demanda.update(dadosAtualizados, {
                where: { id_demanda: id }
            });
            if (updated) {
                const demandaAtualizada = await Demanda.findByPk(id);
                return demandaAtualizada;
            }
            throw new Error("Demanda não encontrada");
        }
        catch (error) {
            console.error("Erro ao atualizar demanda:", error);
            throw new Error("Erro ao atualizar demanda");
        }
    }

    // Soft delete da demanda
    // retorna o id da demanda deletada
    static async softDeleteDemanda(id) {
        try {
            const [updated] = await Demanda.update({ ativa: false }, {
                where: { id_demanda: id }
            });
            if (updated) {
                // Retorna o id da demanda desativada
                return id;
            }
            throw new Error("Demanda não encontrada");
        }
        catch (error) {
            console.error("Erro ao deletar demanda:", error);
            throw new Error("Erro ao deletar demanda");
        }
    }

    /**
     * @param {*} dadosDemanda 
     * @returns 
     */
    static async criaDemanda(dadosDemanda) {
        try {
            // Validações de dados primeiro
            if (!dadosDemanda.tipologia || !dadosDemanda.numeroGd || !dadosDemanda.nomeDemanda) {
                throw new Error("Todos os campos são obrigatórios.");
            }

            if (dadosDemanda.numeroGd.length > 11) {
                throw new Error("Número GD deve ter no máximo 11 caracteres.");
            }

            // Verifica se o número GD está no formato correto
            const regexNumeroGd = /^DEMN\d{7}$/;
            if (!regexNumeroGd.test(dadosDemanda.numeroGd)) {
                throw new Error("Número GD deve estar no formato DEMN0000000 (DEMN seguido de 7 dígitos).");
            }

            // Pesquisa se já existe uma demanda com o mesmo número GD e estar ativa
            // Se existir, lança erro
            const demandaExistente = await Demanda.findOne({
                where: { numero_gd: dadosDemanda.numeroGd, ativa: true }
            });

            if (demandaExistente) {
                throw new Error("Já existe uma demanda com o mesmo número GD.");
            }

            // Formata os dados da demanda para o modelo
            const dadosFormatados = {
                tipologia: dadosDemanda.tipologia,
                numero_gd: dadosDemanda.numeroGd,
                nome: dadosDemanda.nomeDemanda,
                ano: dadosDemanda.ano,
                semestre: dadosDemanda.semestre,
            };

            // Cria nova demanda
            let novaDemanda = await Demanda.create(dadosFormatados);
            const idNovaDemanda = novaDemanda.id_demanda;

            // Cria registro específico baseado na tipologia
            if (dadosDemanda.tipologia === 'Bug' || dadosDemanda.tipologia === 'Defeito') {
                await this.criaDetalheBugDefeito(novaDemanda.id_demanda);
                novaDemanda = await BugDefeitoService.buscaDemandaPorId(idNovaDemanda);
            } else if (dadosDemanda.tipologia === 'Melhoria') {
                await this.criaDetalheMelhoria(novaDemanda.id_demanda);
                novaDemanda = await MelhoriaService.buscaDemandaPorId(idNovaDemanda);
            }

            return novaDemanda;

        } catch (error) {
            console.error("Erro ao criar nova demanda:", error);
            throw error;
        }
    }

    /**
     * Cria o registro específico para demandas do tipo Bug/Defeito
     * com campos vazios inicialmente.
     * @param {number} idDemanda 
     * @returns 
     */
    static async criaDetalheBugDefeito(idDemanda) {
        try {
            const detalhe = await BugDefeito.create({
                id_demanda: idDemanda,
            });
            return detalhe;
        } catch (error) {
            console.error("Erro ao criar detalhe Bug/Defeito:", error);
            throw new Error("Erro ao criar detalhe Bug/Defeito");
        }
    }

    /**
     * Busca demandas do tipo Melhoria que foram priorizadas pelo comitê.
     * Filtra apenas demandas ativas com priorizacao_comite = 'Sim'.
     * @returns {Array} Lista de demandas priorizadas
     */
    static async buscaDemandasPriorizadas() {
        try {
            // Buscar apenas melhorias que possuem priorizacao_comite = 'Sim'
            const todasMelhorias = await MelhoriaService.buscaTodasDemandas();
            
            // Filtrar apenas as que têm priorizacao_comite = 'Sim' (case insensitive)
            const demandasPriorizadas = todasMelhorias.filter(demanda => 
                demanda.priorizacao_comite?.toLowerCase() === 'sim'
            );

            return demandasPriorizadas.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        } catch (error) {
            console.error("Erro ao buscar demandas priorizadas:", error);
            throw new Error("Erro ao buscar demandas priorizadas");
        }
    }

    /**
     * Cria o registro específico para demandas do tipo Melhoria
     * com campos vazios inicialmente, incluindo matriz Guthie e horas FTE.
     * @param {number} idDemanda 
     * @returns 
     */
    static async criaDetalheMelhoria(idDemanda) {
        try {
            // Criar detalhe da melhoria
            const detalhe = await Melhoria.create({
                id_demanda: idDemanda,
            });

            // Criar registros auxiliares (matriz Guthie e horas FTE)
            await matrizGuthieService.create(idDemanda);
            await horasFteService.create(idDemanda);

            return detalhe;
        } catch (error) {
            console.error("Erro ao criar detalhe Melhoria:", error);
            throw new Error("Erro ao criar detalhe Melhoria");
        }
    }
}

module.exports = DemandaService;