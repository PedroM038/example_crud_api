/**
 * @file services/demandas_service.js
 * @description Serviço principal para gerenciar demandas.
 * Ponto de entrada que unifica as tipologias (Melhoria, Bug, Defeito).
 */

const { models, sequelize } = require('../models/associations');
const { Op } = require('sequelize');

// Services das tipologias específicas
const BugDefeitoService = require('./bug_defeito_service');
const MelhoriaService = require('./melhoria_service');

// Tipologias que possuem tabelas de detalhe específicas
const TIPOLOGIAS_COM_DETALHE = ['Bug', 'Defeito', 'Melhoria'];

class DemandaService {

    // ==================== VALIDAÇÕES ====================

    /**
     * Valida os dados obrigatórios para criação de demanda
     */
    static _validarDadosCriacao(dados) {
        const { tipologia, numeroGd, nomeDemanda } = dados;

        if (!tipologia || !numeroGd || !nomeDemanda) {
            throw new Error('Campos obrigatórios: tipologia, numeroGd, nomeDemanda');
        }

        // Valida formato do número GD: DEMN seguido de 7 dígitos
        const regexNumeroGd = /^DEMN\d{7}$/;
        if (!regexNumeroGd.test(numeroGd)) {
            throw new Error('Número GD deve estar no formato DEMN0000000 (DEMN seguido de 7 dígitos)');
        }
    }

    /**
     * Verifica se já existe demanda ativa com o mesmo número GD
     */
    static async _verificarDuplicidade(numeroGd, options = {}) {
        const existente = await models.Demandas.findOne({
            where: { numero_gd: numeroGd, ativa: true },
            ...options
        });

        if (existente) {
            throw new Error('Já existe uma demanda ativa com este número GD');
        }
    }

    // ==================== BUSCA ====================

    /**
     * Busca todas as demandas ativas com filtros opcionais
     * @param {Object} filtros - { ano, semestre, tipologia }
     */
    static async buscarAtivas(filtros = {}) {
        const { ano, semestre, tipologia } = filtros;

        // Se filtro por tipologia específica, delega ao service apropriado
        if (tipologia) {
            if (tipologia === 'Melhoria') {
                return MelhoriaService.buscarTodas({ ano, semestre });
            }
            if (tipologia === 'Bug' || tipologia === 'Defeito') {
                return BugDefeitoService.buscarTodas({ ano, semestre });
            }
            // Outras tipologias: busca direto
            return this._buscarOutrasTipologias({ ano, semestre, tipologia });
        }

        // Busca todas as tipologias em paralelo
        const [melhorias, bugsDefeitos, outras] = await Promise.all([
            MelhoriaService.buscarTodas({ ano, semestre }),
            BugDefeitoService.buscarTodas({ ano, semestre }),
            this._buscarOutrasTipologias({ ano, semestre })
        ]);

        // Combina e ordena por data de criação (mais recentes primeiro)
        const todasDemandas = [...melhorias, ...bugsDefeitos, ...outras];
        return todasDemandas.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    }

    /**
     * Busca demandas que não são Bug, Defeito ou Melhoria
     */
    static async _buscarOutrasTipologias(filtros = {}) {
        const { ano, semestre, tipologia } = filtros;

        const where = {
            ativa: true,
            tipologia: tipologia 
                ? tipologia 
                : { [Op.notIn]: TIPOLOGIAS_COM_DETALHE }
        };

        if (ano) where.ano = ano;
        if (semestre) where.semestre = semestre;

        const demandas = await models.Demandas.findAll({
            where,
            order: [['createdAt', 'DESC']]
        });

        // Mapeia para formato padronizado (sem dados de detalhe)
        return demandas.map(d => ({
            id_demanda: d.id_demanda,
            nome: d.nome,
            semestre: d.semestre,
            ano: d.ano,
            tipologia: d.tipologia,
            numero_gd: d.numero_gd,
            ativa: d.ativa,
            score: null,
            prioridade_guthie: null,
            prioridade_comite: null,
            status: null,
            createdAt: d.createdAt
        }));
    }

    /**
     * Busca demanda por ID (apenas dados básicos da tabela principal)
     */
    static async buscarPorId(id, options = {}) {
        const demanda = await models.Demandas.findOne({
            where: { id_demanda: id, ativa: true },
            ...options
        });

        if (!demanda) {
            throw new Error('Demanda não encontrada');
        }

        return demanda;
    }

    /**
     * Busca demanda completa por ID, delegando ao service da tipologia
     */
    static async buscarCompletaPorId(id) {
        const demandaBase = await this.buscarPorId(id);
        const { tipologia } = demandaBase;

        if (tipologia === 'Melhoria') {
            return MelhoriaService.buscarPorId(id);
        }

        if (tipologia === 'Bug' || tipologia === 'Defeito') {
            return BugDefeitoService.buscarPorId(id);
        }

        // Outras tipologias: retorna apenas dados básicos
        return demandaBase;
    }

    /**
     * Busca demandas por tipologia
     */
    static async buscarPorTipologia(tipologia, options = {}) {
        return models.Demandas.findAll({
            where: { tipologia, ativa: true },
            order: [['id_demanda', 'ASC']],
            ...options
        });
    }

    /**
     * Busca melhorias priorizadas pelo comitê
     */
    static async buscarPriorizadas(filtros = {}) {
        // Usa o filtro direto do MelhoriaService em vez de filtrar depois
        const melhorias = await MelhoriaService.buscarTodas({
            ...filtros,
            priorizacaoComite: 'Sim'
        });

        return melhorias.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    }

    // ==================== CRIAÇÃO ====================

    /**
     * Cria nova demanda com suporte a transaction
     * @param {Object} dados - { tipologia, numeroGd, nomeDemanda, ano, semestre }
     * @param {Object} options - { transaction }
     */
    static async criar(dados, options = {}) {
        // Validações síncronas
        this._validarDadosCriacao(dados);

        // Se não há transaction externa, cria uma interna para atomicidade
        const transacaoExterna = !!options.transaction;
        const transaction = options.transaction || await sequelize.transaction();

        try {
            // Verificar duplicidade dentro da transaction
            await this._verificarDuplicidade(dados.numeroGd, { transaction });

            // Criar demanda principal
            const novaDemanda = await models.Demandas.create({
                tipologia: dados.tipologia,
                numero_gd: dados.numeroGd,
                nome: dados.nomeDemanda,
                ano: dados.ano,
                semestre: dados.semestre
            }, { transaction });

            const idDemanda = novaDemanda.id_demanda;

            // Criar detalhe específico da tipologia
            await this._criarDetalheTipologia(idDemanda, dados.tipologia, { transaction });

            // Commit se transaction interna
            if (!transacaoExterna) {
                await transaction.commit();
            }

            // Retorna demanda completa com detalhes
            return this.buscarCompletaPorId(idDemanda);

        } catch (error) {
            // Rollback se transaction interna
            if (!transacaoExterna) {
                await transaction.rollback();
            }
            throw error;
        }
    }

    /**
     * Cria o registro de detalhe específico da tipologia
     */
    static async _criarDetalheTipologia(idDemanda, tipologia, options = {}) {
        if (tipologia === 'Bug' || tipologia === 'Defeito') {
            return models.DemandasBugDefeito.create(
                { id_demanda: idDemanda },
                options
            );
        }

        if (tipologia === 'Melhoria') {
            return models.DemandasMelhoria.create({ id_demanda: idDemanda }, options);
        }

        // Outras tipologias não têm tabela de detalhe
        return null;
    }

    // ==================== ATUALIZAÇÃO ====================

    /**
     * Atualiza dados básicos da demanda (tabela principal)
     */
    static async atualizar(id, dados, options = {}) {
        const [linhasAfetadas] = await models.Demandas.update(dados, {
            where: { id_demanda: id },
            ...options
        });

        if (linhasAfetadas === 0) {
            throw new Error('Demanda não encontrada');
        }

        return this.buscarPorId(id, options);
    }

    // ==================== DESATIVAÇÃO ====================

    /**
     * Soft delete - desativa a demanda
     * @returns {number} ID da demanda desativada
     */
    static async desativar(id, options = {}) {
        const [linhasAfetadas] = await models.Demandas.update(
            { ativa: false },
            { where: { id_demanda: id }, ...options }
        );

        if (linhasAfetadas === 0) {
            throw new Error('Demanda não encontrada');
        }

        return id;
    }
}

module.exports = DemandaService;