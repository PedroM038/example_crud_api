const { HorasFTE, Tempo, Repeticao } = require('../models/associations');

/**
 * Service para operações CRUD nas horas FTE.
 */
const horasFteService = {
    // Lista todos os registros de horas FTE, incluindo associações
    async listAll() {
        return HorasFTE.findAll({
            include: [
                { model: Tempo, as: 'tempoInfo' },
                { model: Repeticao, as: 'repeticaoInfo' }
            ]
        });
    },

    // Busca um registro específico por id
    async getById(id) {
        return HorasFTE.findByPk(id, {
            include: [
                { model: Tempo, as: 'tempoInfo' },
                { model: Repeticao, as: 'repeticaoInfo' }
            ]
        });
    },

    // Busca um registro específico por id_demanda
    async getByDemanda(id_demanda) {
        return HorasFTE.findOne({
            where: { id_demanda },
            include: [
                { model: Tempo, as: 'tempoInfo' },
                { model: Repeticao, as: 'repeticaoInfo' }
            ]
        });
    },

    // Cria um novo registro de horas FTE com dados nulos
    async create(idDemanda) {
        return HorasFTE.create({
            id_demanda: idDemanda,
            quantidade_funci: null,
            quantidade_tempo: null,
            quantidade_repeticao: null,
            unidade_tempo: null,
            unidade_repeticao: null,
            horas_ano: null,
            fte_ano: null
        });
    },

    // Atualiza um registro existente
    async update(id, data) {
        const horasFte = await HorasFTE.findByPk(id);
        if (!horasFte) return null;
        await horasFte.update(data);
        return horasFte;
    },

    // Atualiza um registro por id_demanda
    async updateByDemanda(id_demanda, data) {
        const horasFte = await HorasFTE.findOne({ where: { id_demanda } });
        if (!horasFte) return null;
        await horasFte.update(data);
        return horasFte;
    },

    // Deleta um registro
    async remove(id) {
        const horasFte = await HorasFTE.findByPk(id);
        if (!horasFte) return null;
        await horasFte.destroy();
        return true;
    },

    // Deleta um registro por id_demanda
    async removeByDemanda(id_demanda) {
        const horasFte = await HorasFTE.findOne({ where: { id_demanda } });
        if (!horasFte) return null;
        await horasFte.destroy();
        return true;
    }
};

module.exports = horasFteService;