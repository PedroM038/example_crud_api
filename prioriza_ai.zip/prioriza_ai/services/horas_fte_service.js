/**
 * @file services/horas_fte_service.js
 * @description Serviço para operações de Horas FTE (cálculo de economia de tempo).
 * @author Pedro e Rafaela
 */

const { models } = require('../models/associations');

// Includes padrão para consultas com informações completas
const INCLUDES_COMPLETO = [
    { model: models.TipTempos, as: 'tempoInfo' },
    { model: models.TipRepeticoes, as: 'repeticaoInfo' }
];

class HorasFteService {

    /**
     * Busca todos os registros de horas FTE
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Array>} Lista de registros com associações
     */
    static async buscarTodos(options = {}) {
        return models.HorasFte.findAll({
            include: INCLUDES_COMPLETO,
            ...options
        });
    }

    /**
     * Busca horas FTE por ID da demanda
     * @param {number} idDemanda - ID da demanda
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Object|null>} Registro ou null
     */
    static async buscarPorDemanda(idDemanda, options = {}) {
        return models.HorasFte.findOne({
            where: { id_demanda: idDemanda },
            include: INCLUDES_COMPLETO,
            ...options
        });
    }

    /**
     * Busca ou cria registro de horas FTE para uma demanda
     * @param {number} idDemanda - ID da demanda
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Object>} Registro existente ou novo
     */
    static async buscarOuCriar(idDemanda, options = {}) {
        const [registro] = await models.HorasFte.findOrCreate({
            where: { id_demanda: idDemanda },
            defaults: {
                id_demanda: idDemanda,
                quantidade_funci: null,
                quantidade_tempo: null,
                quantidade_repeticao: null,
                unidade_tempo: null,
                unidade_repeticao: null,
                horas_ano: null,
                fte_ano: null
            },
            ...options
        });
        return registro;
    }

    /**
     * Salva (cria ou atualiza) horas FTE de uma demanda
     * @param {number} idDemanda - ID da demanda
     * @param {Object} dados - Dados das horas FTE
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<Object>} Registro salvo
     */
    static async salvar(idDemanda, dados, options = {}) {
        const [registro, criado] = await models.HorasFte.findOrCreate({
            where: { id_demanda: idDemanda },
            defaults: { id_demanda: idDemanda, ...dados },
            ...options
        });

        if (!criado) {
            await registro.update(dados, options);
        }

        return registro;
    }

    /**
     * Remove horas FTE de uma demanda
     * @param {number} idDemanda - ID da demanda
     * @param {Object} options - Opções do Sequelize (transaction, etc)
     * @returns {Promise<number>} Número de registros removidos
     */
    static async removerPorDemanda(idDemanda, options = {}) {
        return models.HorasFte.destroy({
            where: { id_demanda: idDemanda },
            ...options
        });
    }
}

module.exports = HorasFteService;