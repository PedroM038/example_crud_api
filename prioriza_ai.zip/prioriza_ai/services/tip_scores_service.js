const tip_scores = require('../models/tip_scores');

class tip_scores_service {

    static async buscaTodosScores() {
        try {
            const scores = await tip_scores.findAll({
                attributes: ['id', 'classificacao', 'score_minimo', 'score_maximo'],
                order: [['score_minimo', 'ASC']]
            });
            return scores;
        } catch (error) {
            console.error("Erro ao buscar scores:", error);
            throw new Error("Erro ao buscar scores");
        }
    }

    static async criaScore(scoreData) {
        try {
            const novoScore = await tip_scores.create(scoreData);
            return novoScore;
        } catch (error) {
            console.error("Erro ao criar tip_scores:", error);
            throw new Error("Erro ao criar tip_scores");
        }
    }

    static async atualizaScore(id, scoreData) {
        try {
            const [updated] = await tip_scores.update(scoreData, {
                where: { id: id }
            });
            if (updated) {
                const updatedScore = await tip_scores.findByPk(id);
                return updatedScore;
            }
            throw new Error("tip_scores não encontrado");
        } catch (error) {
            console.error("Erro ao atualizar tip_scores:", error);
            throw new Error("Erro ao atualizar tip_scores");
        }
    }
}

module.exports = tip_scores_service;