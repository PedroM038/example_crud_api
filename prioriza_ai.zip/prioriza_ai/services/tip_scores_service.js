const { models } = require('../models/associations');

class TipScoresService {

    static async buscarTodos(options = {}) {
        return models.TipScores.findAll({
            attributes: ['id', 'classificacao', 'score_minimo', 'score_maximo'],
            order: [['score_minimo', 'ASC']],
            ...options
        });
    }

    static async criar(data, options = {}) {
        return models.TipScores.create(data, options);
    }

    static async atualizar(id, data, options = {}) {
        const [updated] = await models.TipScores.update(data, {
            where: { id },
            ...options
        });
        if (!updated) throw new Error('Score não encontrado');
        return models.TipScores.findByPk(id, options);
    }
}

module.exports = TipScoresService;