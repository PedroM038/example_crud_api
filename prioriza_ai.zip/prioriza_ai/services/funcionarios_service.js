/**
 * @file services/funcionarios_service.js
 * @description Consulta funcionários da tabela externa ARH.cad_funci.
 */

const { query } = require('../database');

// Constantes para UORs das equipes
const UOR = {
    ATAN: 286527,
    DESIGN: 286521
};

class FuncionariosService {

    /**
     * Busca funcionários por UOR (consulta tabela externa ARH)
     */
    static async buscarPorUor(uor) {
        const sql = `
            SELECT guerra AS nome, matricula
            FROM ARH.cad_funci
            WHERE uor_trabalho = ?
            ORDER BY nome ASC
        `;
        const resultado = await query(sql, [uor]);
        return resultado || [];
    }

    /**
     * Busca funcionários da equipe ATAN
     */
    static async buscarAtan() {
        return this.buscarPorUor(UOR.ATAN);
    }

    /**
     * Busca funcionários da equipe Design
     */
    static async buscarDesign() {
        return this.buscarPorUor(UOR.DESIGN);
    }
}

module.exports = FuncionariosService;
module.exports.UOR = UOR;