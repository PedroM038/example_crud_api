/**
 * @file services/funcionarios_service.js
 * @description Service responsável por trazer os funcionários que podem
 * ser selecionados.
 * @author Pedro e Rafaela
 */

const { query } = require('../database/conexao');

const FuncionariosService = {

    // Constantes para UORs
    UOR_ATAN: 286527,
    UOR_DESIGN: 286521,

    /**
     * Busca funcionários através de consulta à base de dados
     * @param {number} uor - Código da UOR
     * @returns {Promise<Array>}
     */
    async buscaFuncionarios(uor) {
        try {
            const sql = `
                SELECT guerra AS nome, matricula
                FROM ARH.cad_funci
                WHERE uor_trabalho = ?
                ORDER BY nome ASC
            `;
            const resultado = await query(sql, [uor]);
            return resultado || [];
        } catch (error) {
            console.error(`Erro ao buscar funcionários da UOR ${uor}:`, error.message);
            return [];
        }
    },

    /**
     * Busca funcionários da equipe ATAN
     * @returns {Promise<Array>}
     */
    async buscaFuncionariosAtan() {
        return await this.buscaFuncionarios(this.UOR_ATAN);
    },

    /**
     * Busca funcionários da equipe DESIGN
     * @returns {Promise<Array>}
     */
    async buscaFuncionariosDesign() {
        return await this.buscaFuncionarios(this.UOR_DESIGN);
    },
};

module.exports = FuncionariosService;