# Prioriza aí - Cesup Suprimentos

Aplicação Web focada na priorização e gestão de Demandas.

## 📋 Descrição

O prioriza aí é uma aplicação feita a partir do projeto padrão Node.js, e tem como principal foco a priorização e gestão de demandas das equipes ATAN e Design.

## Documentação

Veja a documentação do projeto em docs/

## 🚀 Funcionalidades e Estrutura

- ✅ Autenticação via SSO do Banco do Brasil
- ✅ Sessões persistentes em banco de dados
- ✅ Uso de Sequelize para controle de tabelas e models
- ✅ Arquitetura modelada no MVC (Model-View-Controller)

## 🏗️ Arquitetura do Projeto

```
onboarding-gestao-de-eventos/
├───.vscode                             // Configurações do Vs Code
├───controllers                         // Controladores da aplicação
├───services                            // Manipulação dos Models e lógica de negócio
├───database                            // Configs da base de dados e Sequelize
├───middlewares                         // Middlewares gerais da aplicação
├───models                              // Representações das entidades (Sequelize)
├───node_modules                        // Toda a bagaceira do Node (Dependências)
├───public                              // Arquivos estáticos 
│   ├───css                             
│   │   ├───fontawesome
│   │   └───webfonts
│   ├───images
│   └───js                              // JS's do Front. Controla dados no DOM.
├───routes                              // Rotas da aplicação
├───ssl                                 // Certificados de redes
└───views                               // Páginas e templates parciais
    └───partials                        // Apenas para uso de includes
```

## 📦 Instalação

### Pré-requisitos

- Node.js (De preferência uma versão recente)
- Acesso à rede interna do BB

### Passos de instalação

1. **Clone o repositório:**

2. **Instale as dependências:**
```bash
npm install ou npm i
```

3. **Configure as variáveis de ambiente:**
Altere o arquivo .env na raiz do projeto:
```env
DATABASE=...
HOSTSQL=...
USER_DB=...
PASS_DB=...
DB_PORT=...
SESSION_SECRET= Pode colocar qualquer senha aqui
PORT= Porta qualquer livre
NODE_ENV= development ou production
...
```

4. **Prepare os certificados SSL:**
Coloque os arquivos `key.pem` e `server.crt` na pasta `ssl/`

O servidor estará disponível em: `https://localhost.bb.com.br:PortaDoENV`

Você também pode usar o modo Debug do VsCode!
Entre no modo Debug (Ctrl + shift + D) e execute primeiro Launch Program e depois Launch Chrome. Pronto, você pode debugar seguramente sua aplicação!

**Desenvolvido por Cesup Suprimentos**

** OBS: Tailwind css**

Para adicionar estilos CSS do Tailwind CSS ou do Flowbite, adicione o import no arquivo input.css, depois compile com o comando:

`npx @tailwindcss/cli -i ./public/css/input.css -o ./public/css/output.css --watch`

Apenas faça isso caso precise realizar alguma modificação na estrutura atual do tailwind ou uma adição de configurações.
