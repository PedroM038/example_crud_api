/* 
    * @file routes/gestao_routes.js
    * @description Rotas de gestão das tabelas auxiliares (áreas, status, tags, etc.)
    * Todas as rotas requerem permissão 'editar_tabelas_auxiliares'
    * @author Pedro e Rafaela
*/

const router = require("express").Router();

/* ========================= Importando os middlewares =========================*/
const { verificaPermissao } = require("../middlewares");

/* ========================= Importando os controladores =========================*/
const GestaoCtl = require("../controllers/gestao_controller");

/* ========================= Middleware de permissão para todas as rotas =========================*/
router.use(verificaPermissao('editar_tabelas_auxiliares'));

/* ========================= Página principal de gestão =========================*/
router.get("/", GestaoCtl.index);

/* ======================== Rotas de gestão de áreas ========================= */
router.get("/areas", GestaoCtl.listarAreas);
router.post("/areas", GestaoCtl.criarArea);
router.put("/areas/:id", GestaoCtl.atualizarArea);
router.delete("/areas/:id", GestaoCtl.deletarArea);
router.patch("/areas/:id/restaurar", GestaoCtl.restaurarArea);

/* ======================== Rotas de gestão de motivos ========================= */
router.get("/motivos", GestaoCtl.listarMotivos);
router.post("/motivos", GestaoCtl.criarMotivo);
router.put("/motivos/:id", GestaoCtl.atualizarMotivo);
router.delete("/motivos/:id", GestaoCtl.deletarMotivo);
router.patch("/motivos/:id/restaurar", GestaoCtl.restaurarMotivo);

/* ======================== Rotas de gestão de andamentos (fases/etapas) ========================= */
router.get("/andamentos", GestaoCtl.listarAndamentos);
router.post("/andamentos", GestaoCtl.criarAndamento);
router.put("/andamentos/:id", GestaoCtl.atualizarAndamento);
router.delete("/andamentos/:id", GestaoCtl.deletarAndamento);
router.patch("/andamentos/:id/restaurar", GestaoCtl.restaurarAndamento);

/* ======================== Rotas de gestão de estagiários ========================= */
router.get("/estagiarios", GestaoCtl.listarEstagiarios);
router.post("/estagiarios", GestaoCtl.criarEstagiario);
router.put("/estagiarios/:id", GestaoCtl.atualizarEstagiario);
router.delete("/estagiarios/:id", GestaoCtl.deletarEstagiario);
router.patch("/estagiarios/:id/restaurar", GestaoCtl.restaurarEstagiario);

/* ======================== Rotas de gestão de indicadores ========================= */
router.get("/indicadores", GestaoCtl.listarIndicadores);
router.post("/indicadores", GestaoCtl.criarIndicador);
router.put("/indicadores/:id", GestaoCtl.atualizarIndicador);
router.delete("/indicadores/:id", GestaoCtl.deletarIndicador);
router.patch("/indicadores/:id/restaurar", GestaoCtl.restaurarIndicador);

/* ======================== Rotas de gestão de inviabilidades ========================= */
router.get("/inviabilidades", GestaoCtl.listarInviabilidades);
router.post("/inviabilidades", GestaoCtl.criarInviabilidade);
router.put("/inviabilidades/:id", GestaoCtl.atualizarInviabilidade);
router.delete("/inviabilidades/:id", GestaoCtl.deletarInviabilidade);
router.patch("/inviabilidades/:id/restaurar", GestaoCtl.restaurarInviabilidade);

/* ======================== Rotas de gestão de status ========================= */
router.get("/status", GestaoCtl.listarStatus);
router.post("/status", GestaoCtl.criarStatus);
router.put("/status/:id", GestaoCtl.atualizarStatus);
router.delete("/status/:id", GestaoCtl.deletarStatus);
router.patch("/status/:id/restaurar", GestaoCtl.restaurarStatus);

/* ======================== Rotas de gestão de tags ========================= */
router.get("/tags", GestaoCtl.listarTags);
router.post("/tags", GestaoCtl.criarTag);
router.put("/tags/:id", GestaoCtl.atualizarTag);
router.delete("/tags/:id", GestaoCtl.deletarTag);
router.patch("/tags/:id/restaurar", GestaoCtl.restaurarTag);

module.exports = router;
