/* 
    * @file routes/index_routes.js
    * @description Rotas principais do aplicativo (demandas, observações, andamento, ferramentas)
    * @author Pedro e Rafaela
*/

const router = require("express").Router();

/* ========================= Importando os controladores =========================*/
const DemandasCtl = require("../controllers/demandas_controller");
const BugDefeitoCtl = require("../controllers/bug_defeito_controller");
const MelhoriaCtl = require("../controllers/melhoria_controller");
const ObservacoesCtl = require("../controllers/observacoes_controller");
const AndamentoCtl = require("../controllers/andamento_controller");
const FerramentasCtl = require("../controllers/ferramentas_controller");

/* ========================= Rotas principais =========================*/
router.get("/", DemandasCtl.index);
router.get("/index", DemandasCtl.index);

/* ======================== API Filtros de Demandas ========================= */
router.get("/api/demandas/priorizadas", DemandasCtl.buscarPriorizadas);
router.get("/api/demandas/todas", DemandasCtl.buscarTodas);

/* ======================== Soft delete demanda ========================= */
router.post("/excluir-demanda/:id", DemandasCtl.excluirDemanda);

/* ======================== Form nova demanda ========================= */
router.get("/demanda/nova", DemandasCtl.criarDemandaForm);
router.post("/demanda/inserir", DemandasCtl.criarDemanda);

/* ======================== Form editar e ver demanda bug / defeito ========================= */
router.get("/demanda/editar-bug-defeito/:id", BugDefeitoCtl.editarForm);
router.put("/demanda/editar-bug-defeito/:id", BugDefeitoCtl.editarDemanda);
router.get("/demanda/visualizar-bug-defeito/:id", BugDefeitoCtl.verDemanda);

/* ======================== Form editar e ver demanda melhoria ========================= */
router.get("/demanda/editar-melhoria/:id", MelhoriaCtl.editarForm);
router.put("/demanda/editar-melhoria/:id", MelhoriaCtl.editarDemanda);
router.get("/demanda/visualizar-melhoria/:id", MelhoriaCtl.verDemanda);

/* ======================== Modal Observacoes ========================= */
router.get("/demanda/observacoes/:idDemanda", ObservacoesCtl.observacoesForm);
router.post("/demanda/observacoes/inserir", ObservacoesCtl.inserir);

/* ======================== Andamento da Demanda ========================= */
router.get("/demanda/andamento/:idDemanda", AndamentoCtl.andamentoForm);
router.put("/demanda/andamento/:idDemanda", AndamentoCtl.sincronizar);
router.post("/demanda/andamento/:idDemanda", AndamentoCtl.adicionar);
router.delete("/demanda/andamento/:idDemanda/:idAndamento", AndamentoCtl.remover);
router.get("/demanda/andamento/:idDemanda/progresso", AndamentoCtl.progresso);

/* ======================== API Ferramentas (CESUP) ========================= */
router.get("/api/ferramentas", FerramentasCtl.listarFerramentas);
router.get("/api/ferramentas/:id", FerramentasCtl.buscarFerramentaPorId);
router.post("/api/ferramentas/limpar-cache", FerramentasCtl.limparCache);

module.exports = router;
