/* 
    * @file routes/index_routes.js
    * @description Rotas principais do aplicativo (demandas, observações, andamento, ferramentas)
    * @author Pedro e Rafaela
*/

const router = require("express").Router();

/* ========================= Importando os controladores =========================*/
const DemandasCtl = require("../controllers/demandas_controller");
const BugDefeitoCtl = require("../controllers/bug_defeito_controller");
const MelhoriaCtl = require("../controllers/melhoria_controller");
const ObservacoesCtl = require("../controllers/observacoes_controller");
const AndamentoCtl = require("../controllers/andamento_controller");
const FerramentasCtl = require("../controllers/ferramentas_controller");
const PrecificacaoCtl = require("../controllers/precificacao_controller");
const TagsCtl = require("../controllers/tags_controller");

/* ========================= Rotas principais =========================*/
router.get("/", DemandasCtl.index);
router.get("/index", DemandasCtl.index);

/* ======================== API Filtros de Demandas ========================= */
router.get("/api/demandas/priorizadas", DemandasCtl.buscarPriorizadas);
router.get("/api/demandas/todas", DemandasCtl.buscarTodas);

/* ======================== Soft delete demanda ========================= */
router.post("/excluir-demanda/:id", DemandasCtl.excluirDemanda);

/* ======================== Form nova demanda ========================= */
router.get("/demanda/nova", DemandasCtl.criarDemandaForm);
router.post("/demanda/inserir", DemandasCtl.criarDemanda);

/* ======================== Bug/Defeito - Visualização e Formulário ========================= */
router.get("/demanda/editar-bug-defeito/:id", BugDefeitoCtl.editarForm);
router.get("/demanda/visualizar-bug-defeito/:id", BugDefeitoCtl.verDemanda);

/* ======================== Bug/Defeito - API Granular ========================= */
router.get("/api/bug-defeito/:id", BugDefeitoCtl.verDemanda);
router.get("/api/bug-defeito/:id/formulario", BugDefeitoCtl.editarForm);
router.put("/api/bug-defeito/:id/dados", BugDefeitoCtl.editarDados);
router.put("/api/bug-defeito/:id/detalhe", BugDefeitoCtl.editarDetalhe);
router.get("/api/bug-defeito/:id/motivos", BugDefeitoCtl.buscarMotivos);
router.put("/api/bug-defeito/:id/motivos", BugDefeitoCtl.sincronizarMotivos);

/* ======================== Melhoria - Visualização e Formulário ========================= */
router.get("/demanda/editar-melhoria/:id", MelhoriaCtl.buscarFormulario);
router.get("/demanda/visualizar-melhoria/:id", MelhoriaCtl.buscar);

/* ======================== Melhoria - API Granular ========================= */
router.get("/api/melhoria", MelhoriaCtl.listar);
router.get("/api/melhoria/:id", MelhoriaCtl.buscar);
router.get("/api/melhoria/:id/formulario", MelhoriaCtl.buscarFormulario);
router.put("/api/melhoria/:id/dados", MelhoriaCtl.editarDados);
router.put("/api/melhoria/:id/detalhe", MelhoriaCtl.editarDetalhe);
router.put("/api/melhoria/:id/responsaveis", MelhoriaCtl.editarResponsaveis);
router.put("/api/melhoria/:id/guthie", MelhoriaCtl.editarGuthie);
router.put("/api/melhoria/:id/horas-fte", MelhoriaCtl.editarHorasFte);
router.get("/api/melhoria/responsaveis/opcoes", MelhoriaCtl.buscarOpcoesResponsaveis);
router.get("/api/melhoria/guthie/opcoes", MelhoriaCtl.buscarOpcoesGuthie);
router.get("/api/melhoria/horas-fte/opcoes", MelhoriaCtl.buscarOpcoesHorasFte);

/* ======================== Precificação (Reutilizável) ========================= */
router.get("/api/demandas/:id/precificacao", PrecificacaoCtl.buscar);
router.put("/api/demandas/:id/precificacao", PrecificacaoCtl.atualizar);
router.delete("/api/demandas/:id/precificacao", PrecificacaoCtl.remover);
router.get("/api/precificacao/opcoes", PrecificacaoCtl.listarOpcoes);
router.get("/api/demandas/:id/precificacao/completo", PrecificacaoCtl.buscarComOpcoes);

/* ======================== Tags (Reutilizável) ========================= */
router.get("/api/demandas/:id/tags", TagsCtl.buscar);
router.put("/api/demandas/:id/tags", TagsCtl.sincronizar);
router.get("/api/tags/opcoes", TagsCtl.buscarOpcoes);
router.get("/api/demandas/:id/tags/completo", TagsCtl.buscarComOpcoes);

/* ======================== Modal Observacoes ========================= */
router.get("/demanda/observacoes/:idDemanda", ObservacoesCtl.observacoesForm);
router.post("/demanda/observacoes/inserir", ObservacoesCtl.inserir);

/* ======================== Andamento da Demanda ========================= */
router.get("/demanda/andamento/:idDemanda", AndamentoCtl.andamentoForm);
router.put("/demanda/andamento/:idDemanda", AndamentoCtl.sincronizar);
router.post("/demanda/andamento/:idDemanda", AndamentoCtl.adicionar);
router.delete("/demanda/andamento/:idDemanda/:idAndamento", AndamentoCtl.remover);
router.get("/demanda/andamento/:idDemanda/progresso", AndamentoCtl.progresso);

/* ======================== API Ferramentas (CESUP) ========================= */
router.get("/api/ferramentas", FerramentasCtl.listarFerramentas);
router.get("/api/ferramentas/:id", FerramentasCtl.buscarFerramentaPorId);
router.post("/api/ferramentas/limpar-cache", FerramentasCtl.limparCache);

module.exports = router;
