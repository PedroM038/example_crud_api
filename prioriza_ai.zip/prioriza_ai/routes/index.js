/* 
    * @file routes/index.js
    * @description Arquivo principal de rotas - importa e configura todos os módulos de rotas
    * @author Pedro e Rafaela
*/

const router = require("express").Router();

/* ========================= Importando os módulos de rotas =========================*/
const indexRoutes = require("./index_routes");
const gestaoRoutes = require("./gestao_routes");

/* ========================= Configurando as rotas =========================*/
router.use("/", indexRoutes);
router.use("/gestao", gestaoRoutes);

module.exports = router;
