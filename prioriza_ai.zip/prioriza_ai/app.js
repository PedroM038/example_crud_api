/**
 * ================================================================================
 * DE QUE SERVEM MILHARES DE LINHAS DE CÓDIGO SE A ÚNICA VARIÁVEL QUE 
 * EU NÃO CONSIGO DEBUGAR É O VAZIO NO MEU PEITO?
 * ================================================================================
*/

/* 
    * @file app.js
    * Inicializa o servidor HTTPS para a aplicação
    * Configura o certificado SSL e a porta do servidor
    * Inicia o servidor HTTPS na porta especificada
    * Se você está perdido, leia o README.md!
    * @author Pedro
*/

// overrides previne que as variáveis de ambiente sejam sobrescritas por valores do sistema
// quiet previne que mensagens de log sejam exibidas ao carregar o dotenv
require("dotenv").config({ overrides: true, quiet: true } );

const fs = require("fs");
const https = require("https");
const app = require("./server");

// Verificar se os arquivos SSL existem
const sslKeyPath = "./ssl/server.key";
const sslCertPath = "./ssl/server.cer";

if (!fs.existsSync(sslKeyPath)) {
    console.error(`Arquivo SSL não encontrado: ${sslKeyPath}`);
    process.exit(1);
}

if (!fs.existsSync(sslCertPath)) {
    console.error(`Arquivo SSL não encontrado: ${sslCertPath}`);
    process.exit(1);
}

// Ler os arquivos SSL
// Os certificados SSL são necessários para criar um servidor HTTPS seguro
// Lembre-se de atualizar os arquivos de certificado SSL conforme necessário

const key = fs.readFileSync(sslKeyPath, "utf8");
const cert = fs.readFileSync(sslCertPath, "utf8");
const credentials = { key, cert };
const httpsPort = process.env.PORT || 2025;

const httpsServer = https.createServer(credentials, app);

// Configurações do servidor
httpsServer.keepAliveTimeout = 5000;
httpsServer.headersTimeout = 6000;

httpsServer.listen(httpsPort, () => {
    console.log(`🚀 HTTPS Server running on port ${httpsPort}`);
    console.log(`🌐 Access: https://localhost.bb.com.br:${httpsPort}`);
    console.log(`📝 Environment: ${process.env.NODE_ENV || 'development'}`);
});

// Tratamento de erros do servidor
httpsServer.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
        console.error(`❌ Porta ${httpsPort} já está em uso`);
    } else {
        console.error('❌ Erro no servidor HTTPS:', err);
    }
    process.exit(1);
});

// Graceful shutdown (fechamento suave do servidor)
process.on('SIGTERM', () => {
    console.log('SIGTERM recebido, fechando servidor HTTPS...');
    httpsServer.close(() => {
        console.log('Servidor HTTPS fechado');
        process.exit(0);
    });
});

process.on('SIGINT', () => {
    console.log('SIGINT recebido, fechando servidor HTTPS...');
    httpsServer.close(() => {
        console.log('Servidor HTTPS fechado');
        process.exit(0);
    });
});