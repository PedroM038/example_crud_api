/**
 * @file app.js
 * @description Configuração da aplicação Express (middlewares, rotas, views)
 * @author Pedro
 */

require("dotenv").config();

const express = require("express");
const path = require("path");
const cookieParser = require("cookie-parser");
const logger = require("morgan");
const flash = require("express-flash");
const routes = require("./routes");

const {
    sessionConfig,
    corsConfig,
    securityHeaders,
    captureClientIp,
    autenticaUsuario,
    notFoundHandler,
    errorHandler
} = require("./middlewares");

const { initDatabase } = require("./database");

const app = express();

// Inicialização do banco de dados
initDatabase()
    .then(success => {
        if (success) {
            console.log('🚀 Banco de dados inicializado com sucesso');
        } else {
            console.error('❌ Falha ao inicializar banco de dados');
            process.exit(1);
        }
    })
    .catch(error => {
        console.error('❌ Erro crítico na inicialização:', error);
        process.exit(1);
    });

// Middlewares de sessão e parsing
app.use(sessionConfig);
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: false, limit: '10mb' }));
app.use(cookieParser());

// Logging apenas em desenvolvimento
if (process.env.NODE_ENV !== 'production') {
    app.use(logger("dev"));
}

app.use(flash());
app.use(corsConfig);
app.use(securityHeaders);
app.use(captureClientIp);
app.use(autenticaUsuario);

// Views e arquivos estáticos
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");
app.use(express.static(path.join(__dirname, "public"), {
    maxAge: process.env.NODE_ENV === 'production' ? '1d' : 0,
    etag: false
}));

// Rotas centralizadas
app.use("/", routes);

// Tratamento de erros
app.use(notFoundHandler);
app.use(errorHandler);

module.exports = app;