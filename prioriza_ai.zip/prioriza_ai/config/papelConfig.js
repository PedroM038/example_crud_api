/**
 * @file config/papelConfig.js
 * @description Configuração de papéis e permissões baseado em UOR  
 * * Define quais UORs têm acesso a quais funcionalidades do sistema
 * @author Pedro e Rafaela
 */

const PAPEIS_USUARIO = {
    
    // Administrador - Acesso total
    ADMIN: {
        nome: 'admin',
        uors: ['286527', '286521'], // UOR de administradores, ATAN e Design
        permissoes: [
            'acessar_gestao',
            'editar_tabelas_auxiliares',
            'editar_demanda'
        ]
    },
    
    // Usuário padrão - Sem acesso à gestão
    USUARIO_PADRAO: {
        nome: 'usuario_padrao',
        uors: [], // Qualquer UOR não mapeada acima
        permissoes: [
            'visualizar_demandas',
            'criar_demandas'
        ]
    }
};

/**
 * Determina o papel do usuário baseado na UOR
 * @param {string} uor - Unidade Organizacional do usuário
 * @returns {Object} Objeto com informações do papel e permissões
 */
function determinarPapelPorUor(uor) {
    for (const [chave, papel] of Object.entries(PAPEIS_USUARIO)) {
        if (papel.uors.includes(uor)) {
            return papel;
        }
    }
    
    // Se nenhuma UOR específica foi encontrada, retorna usuário padrão
    return PAPEIS_USUARIO.USUARIO_PADRAO;
}

/**
 * Verifica se um usuário tem uma permissão específica
 * @param {string} uor - UOR do usuário
 * @param {string} permissao - Permissão a verificar
 * @returns {boolean} True se o usuário tem a permissão
 */
function temPermissao(uor, permissao) {
    const papel = determinarPapelPorUor(uor);
    return papel.permissoes.includes(permissao);
}

/**
 * Verifica se um usuário tem alguma das permissões fornecidas
 * @param {string} uor - UOR do usuário
 * @param {Array} permissoes - Array de permissões a verificar
 * @returns {boolean} True se o usuário tem alguma das permissões
 */
function temAlgumaPermissao(uor, permissoes) {
    const papel = determinarPapelPorUor(uor);
    return permissoes.some(permissao => papel.permissoes.includes(permissao));
}

module.exports = {
    PAPEIS_USUARIO,
    determinarPapelPorUor,
    temPermissao,
    temAlgumaPermissao
};
