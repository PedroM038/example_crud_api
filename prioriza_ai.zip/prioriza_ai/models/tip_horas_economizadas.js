/**
 * @file models/tip_horas_economizadas.js
 * @description Modelo Sequelize para a tabela 'tip_horas_economizadas'.
 * Este modelo representa as horas economizadas em uma demanda.
 * Usamos para o cálculo de pontos e pesos na matriz Guthie.
 * @author Pedro e Rafaela
 */
const { DataTypes } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const TipHorasEconomizadas = sequelize.define('TipHorasEconomizadas', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    peso: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    pontos: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    legenda: {
        type: DataTypes.STRING(250),
        allowNull: false,
    },
    createdAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'createdAt'
    },
    updatedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'updatedAt'
    }
}, {
    tableName: 'tip_horas_economizadas',
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci',
    timestamps: true
});

module.exports = TipHorasEconomizadas;