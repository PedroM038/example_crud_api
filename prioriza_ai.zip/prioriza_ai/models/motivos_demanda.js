/**
 * @file models/motivos_demanda.js
 * @description Modelo Sequelize para a tabela intermediária 'motivos_demanda'.
 * Esta tabela permite a relacionar demandas_bug_defeito e tip_motivos,
 * possibilitando que uma demanda Bug/Defeito tenha múltiplos motivos associados.
 * Pense em motivo como uma tag ou categoria que ajuda a classificar e entender melhor
 * a natureza do Bug/Defeito reportado.
 * @author Pedro e Rafaela
 */

const { DataTypes } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const MotivosDemanda = sequelize.define('MotivosDemanda', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    id_demanda: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'demandas',
            key: 'id_demanda'
        },
    },
    motivo_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'tip_motivos',
            key: 'id'
        },
    },
    createdAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'createdAt'
    },
    updatedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'updatedAt'
    }
}, {
    tableName: 'motivos_demanda',
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci',
    timestamps: true,
    /**
     * Nesse modelo decidi trabalhar com índices compostos para testar performance
     * e garantir unicidade na combinação de id_demanda e motivo_id.
     * Isso evita duplicações e melhora a eficiência nas consultas.
     */
    indexes: [
        {
            unique: true,
            fields: ['id_demanda', 'motivo_id'],
            name: 'idx_demanda_motivo_unique'
        },
        {
            fields: ['id_demanda'],
            name: 'idx_motivos_demanda_id_demanda'
        },
        {
            fields: ['motivo_id'],
            name: 'idx_motivos_demanda_motivo_id'
        }
    ]
});

module.exports = MotivosDemanda;
