/**
 * @file models/motivos_demanda.js
 * @description Modelo Sequelize para a tabela intermediária 'motivos_demanda'.
 * Esta tabela permite a relação N:N entre demandas_bug_defeito e tip_motivos,
 * possibilitando que uma demanda Bug/Defeito tenha múltiplos motivos associados.
 * @author Pedro e Rafaela
 */

const { DataTypes } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const MotivosDemanda = sequelize.define('MotivosDemanda', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    id_demanda: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'demandas',
            key: 'id_demanda'
        },
        comment: 'ID da demanda Bug/Defeito'
    },
    motivo_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'tip_motivos',
            key: 'id'
        },
        comment: 'ID do motivo na tabela tip_motivos'
    }
}, {
    tableName: 'motivos_demanda',
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci',
    timestamps: true,
    indexes: [
        {
            unique: true,
            fields: ['id_demanda', 'motivo_id'],
            name: 'idx_demanda_motivo_unique'
        },
        {
            fields: ['id_demanda'],
            name: 'idx_motivos_demanda_id_demanda'
        },
        {
            fields: ['motivo_id'],
            name: 'idx_motivos_demanda_motivo_id'
        }
    ]
});

module.exports = MotivosDemanda;
