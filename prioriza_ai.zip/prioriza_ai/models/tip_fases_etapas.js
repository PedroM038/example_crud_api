const { DataTypes } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const tip_fases_etapas = sequelize.define('tip_fases_etapas', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    etapa: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    fase: {
        type: DataTypes.STRING(100),
        allowNull: false
    },
    percentual: {
        type: DataTypes.DECIMAL(4,2),
        allowNull: false
    }
}, {
    timestamps: true,
    paranoid: true,
    tableName: 'tip_fases_etapas',
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci',
    comment: 'Tabela de definição sobre o andamento de uma demanda. Cada etapa pode ter várias fases. o Percentual diz a respeito sobre o quanto aquela fase respresenta no andamento da etapa.'
});

module.exports = tip_fases_etapas;