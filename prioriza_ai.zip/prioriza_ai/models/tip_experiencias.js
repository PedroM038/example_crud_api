/**
 * @file models/tip_experiencias.js
 * @description Modelo Sequelize para a tabela 'tip_experiencias'.
 * Basicamente, este modelo é associado a um item da matriz-guthie, possibilitando o
 * cálculo posterior de pontos e pesos para as demandas.
 * @author Pedro e Rafaela
 */

const { DataTypes } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const Experiencia = sequelize.define('Experiencia', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    peso: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    pontos: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    legenda: {
        type: DataTypes.STRING(255),
        allowNull: false
    }
}, {
    tableName: 'tip_experiencias',
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci'
});

module.exports = Experiencia;