/**
 * @file models/andamento.js
 * @description Modelo que representa a tabela de andamento. A noção de andamento
 * de uma demanda está ligada diretamente com as fases e etapas. Essa tabela irá
 * relacionar uma demanda com uma fases e etapas definidas no model tip_fases_etapas.js.
 */

const { DataTypes } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const Andamento = sequelize.define('Andamento', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    id_demanda: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'demandas',
            key: 'id_demanda'
        }
    },
    fase_etapa: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'tip_fases_etapas',
            key: 'id'
        }
    },
    matricula: {
        type: DataTypes.STRING(8),
        allowNull: true,
        defaultValue: null,
        comment: 'Matrícula da pessoa que inseriu o andamento. Serve para logs'        
    },
}, {
    tableName: 'andamento',
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci',
    timestamps: true
});

module.exports = Andamento;