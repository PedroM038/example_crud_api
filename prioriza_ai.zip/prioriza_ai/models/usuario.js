/*
 * @file utils/userHelper.js
 * @description Helper para trabalhar com dados do usuário. Para usar, use a função getUserData passando a sessão do usuário.
 * Retorna um objeto com os dados do usuário ou null se não houver dados.
 */

class Usuario {
    // Extrai dados do usuário da sessão
    static buscaDadosUsuario(session) {
        if (!session) {
            return null;
        }
        
        return {
            chave: session.chave,
            nome: session.nome,
            nomeGuerra: session.nomeguerra,
            prefixo: session.prefixo,
            comissao: session.comissao,
            uor: session.uor,
            cargo: session.cargo
        };
    }
}

module.exports = Usuario;