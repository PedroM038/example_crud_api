/**
 * @file models/demandas.js
 * @description Modelo Sequelize para a tabela 'demandas'.
 * Este modelo representa as demandas do tipo geral, que podem ser bugs, melhorias ou outros tipos de demandas.
 * Ele contém informações básicas sobre cada demanda, como tipologia, número de GD, nome e status de atividade.
 * 
 * As demandas são a base para outras tabelas, como 'demandas_melhoria' e 'demandas_bug_defeito', que estendem suas funcionalidades.
 * @author Pedro e Rafaela
 */

const { DataTypes } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const Demandas = sequelize.define('Demandas', {
    id_demanda: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    tipologia: {
        type: DataTypes.STRING(30),
        allowNull: false,
    },
    numero_gd: {
        type: DataTypes.STRING(15),
        allowNull: false,
    },
    nome: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    ano: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            isInt: true,
            min: 2020, // Exemplo de validação para garantir que o ano seja razoável
            max: new Date().getFullYear() // Ano atual como limite máximo
        }
    },
    semestre: {
        type: DataTypes.ENUM('1', '2'),
        allowNull: false,
        validate: {
            isIn: [['1', '2']] // Validação para garantir que o semestre seja 1 ou 2 (não confio na validação do frontend)
        }
    },
    ativa: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true
    },
}, {
    tableName: 'demandas',
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci'
});

module.exports = Demandas;