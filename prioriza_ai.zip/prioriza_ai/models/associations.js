/**
 * @file models/associations.js
 * @description Define as associações entre os modelos Sequelize.
 * Isso permite que os modelos se relacionem entre si e ajuda
 * a construir consultas complexas.
 * 
 * Para fazer: A tabela de Responsáveis não foi totalmente integrada.
 * Precisa revisar como ela se encaixa no modelo geral.
 * @author Pedro e Rafaela
 */

const Demandas = require('./demandas');

const DemandasBugDefeito = require('./demandas_bug_defeito');
const Status = require('./tip_status');
const Estagiarios = require('./tip_estagiarios');

const Melhoria = require('./demandas_melhoria');
const Area = require('./tip_areas');
const Indicador = require('./tip_indicadores');
const Inviabilidade = require('./tip_inviabilidades');
const tip_fases_etapas = require('./tip_fases_etapas');

const Guthie = require('./matriz_guthie');
const Gravidade = require('./tip_gravidades');
const HorasEconomizadas = require('./tip_horas_economizadas');
const Impacto = require('./tip_impactos');
const Tendencia = require('./tip_tendencias');
const Urgencia = require('./tip_urgencias');
const Experiencia = require('./tip_experiencias');

const HorasFTE = require('./horas_fte');
const Tempo = require('./tip_tempos');
const Repeticao = require('./tip_repeticoes');

const ResponsaveisMelhoria = require('./responsaveis_melhoria');

const Precificacao = require('./precificacao');
const PrecificacaoDev = require('./tip_precificacao_dev');
const PrecificacaoDesign = require('./tip_precificacao_design');

const Tags = require('./tags');
const TipTags = require('./tip_tags');
const Andamento = require('./andamento');
const LogHistoricoAndamento = require('./log_historico_andamento');

const tip_motivos = require('./tip_motivos');
const MotivosDemanda = require('./motivos_demanda');

// Associações Demandas
Demandas.hasOne(DemandasBugDefeito, {
    foreignKey: 'id_demanda',
    as: 'bugDetalhe'
});

Demandas.hasOne(Melhoria, {
    foreignKey: 'id_demanda',
    as: 'melhoriaDetalhe'
});

Demandas.hasOne(ResponsaveisMelhoria, {
    foreignKey: 'id_demanda',
    as: 'responsaveisMelhoriaInfo'
});

Demandas.hasOne(Precificacao, {
    foreignKey: 'id_demanda',
    as: 'precificacaoInfo'
});

// Associações DemandasBugDefeito
DemandasBugDefeito.belongsTo(Demandas, {
    foreignKey: 'id_demanda',
    as: 'demanda'
});

// Associações N:N entre Demandas e tip_motivos através de MotivosDemanda
/**
 * Relacionamento muitos-para-muitos entre Demandas e Motivos.
 * Uma demanda Bug/Defeito pode ter múltiplos motivos associados.
 */
Demandas.belongsToMany(tip_motivos, {
    through: MotivosDemanda,
    foreignKey: 'id_demanda',
    otherKey: 'motivo_id',
    as: 'motivos'
});

tip_motivos.belongsToMany(Demandas, {
    through: MotivosDemanda,
    foreignKey: 'motivo_id',
    otherKey: 'id_demanda',
    as: 'demandas'
});

// Associações diretas com MotivosDemanda para queries específicas
MotivosDemanda.belongsTo(Demandas, {
    foreignKey: 'id_demanda',
    as: 'demanda'
});

MotivosDemanda.belongsTo(tip_motivos, {
    foreignKey: 'motivo_id',
    as: 'motivoInfo'
});

Demandas.hasMany(MotivosDemanda, {
    foreignKey: 'id_demanda',
    as: 'motivosDemanda'
});

DemandasBugDefeito.belongsTo(Status, {
    foreignKey: 'status',
    targetKey: 'id',
    as: 'statusInfo'
});

DemandasBugDefeito.belongsTo(Estagiarios, {
    foreignKey: 'estagiario_atan',
    targetKey: 'id',
    as: 'estagiarioInfo'
});

DemandasBugDefeito.belongsTo(Estagiarios, {
    foreignKey: 'estagiario_atan_aux',
    targetKey: 'id',
    as: 'estagiarioAuxInfo'
});

// Associações Demandas Melhoria
Melhoria.belongsTo(Demandas, {
    foreignKey: 'id_demanda',
    as: 'demanda'
});

Melhoria.belongsTo(Area, {
    foreignKey: 'area',
    targetKey: 'id',
    as: 'areaInfo'
});

Melhoria.belongsTo(Indicador, {
    foreignKey: 'vinculo_indicador',
    targetKey: 'id',
    as: 'indicadorInfo'
});

Melhoria.belongsTo(Inviabilidade, {
    foreignKey: 'inviabilidade',
    targetKey: 'id',
    as: 'inviabilidadeInfo'
});

Melhoria.belongsTo(Status, {
    foreignKey: 'status',
    targetKey: 'id',
    as: 'statusInfo'
});

Melhoria.belongsTo(Guthie, {
    foreignKey: 'id_demanda',
    targetKey: 'id_demanda',
    as: 'guthieInfo'
});

Melhoria.belongsTo(HorasFTE, {
    foreignKey: 'id_demanda',
    targetKey: 'id_demanda',
    as: 'horasFTEInfo'
});

Melhoria.belongsTo(Tags, {
    foreignKey: 'id_demanda',
    targetKey: 'id_demanda',
    as: 'tagsInfo'
});

// Associações Responsáveis Melhoria
/**
 * O campo de funcionários é buscado pela tabela arh. Apenas os 
 * estagiários estão em tabela própria (não sei o motivo) em tip_estagiários
 */
ResponsaveisMelhoria.belongsTo(Estagiarios, {
    foreignKey: 'estagiario_atan',
    targetKey: 'id',
    as: 'estagiarioAtanInfo'
});

ResponsaveisMelhoria.belongsTo(Estagiarios, {
    foreignKey: 'estagiario_atan_aux',
    targetKey: 'id',
    as: 'estagiarioAtanAuxInfo'
});

ResponsaveisMelhoria.belongsTo(Estagiarios, {
    foreignKey: 'estagiario_design',
    targetKey: 'id',
    as: 'estagiarioDesignInfo'
});

ResponsaveisMelhoria.belongsTo(Estagiarios, {
    foreignKey: 'estagiario_design_aux',
    targetKey: 'id',
    as: 'estagiarioDesignAuxInfo'
});

// Associações Matriz Guthie

/**
 * A matriz guthie é uma tabela auxiliar relacioanda apenas
 * com as demandas do tipo Melhoria.
 * Ela contém informações adicionais para calcular o score
 * de cada melhoria.
 */

Guthie.belongsTo(Melhoria, {
    foreignKey: 'id_demanda',
    targetKey: 'id_demanda',
    as: 'melhoria'
});

Guthie.belongsTo(Gravidade, {
    foreignKey: 'gravidade',
    targetKey: 'id',
    as: 'gravidadeInfo'
});

Guthie.belongsTo(HorasEconomizadas, {
    foreignKey: 'horas_economizadas',
    targetKey: 'id',
    as: 'horasEconomizadasInfo'
});

Guthie.belongsTo(Impacto, {
    foreignKey: 'impacto',
    targetKey: 'id',
    as: 'impactoInfo'
});

Guthie.belongsTo(Tendencia, {
    foreignKey: 'tendencia',
    targetKey: 'id',
    as: 'tendenciaInfo'
});

Guthie.belongsTo(Urgencia, {
    foreignKey: 'urgencia',
    targetKey: 'id',
    as: 'urgenciaInfo'
});

Guthie.belongsTo(Experiencia, {
    foreignKey: 'experiencia',
    targetKey: 'id',
    as: 'experienciaInfo'
});

// Associações Horas FTE

/**
 * Horas FTE é uma tabela auxiliar que relaciona
 * as demandas do tipo melhoria com o tempo estimado para conclusão.
 * Ela é usada para calcular o tempo total de trabalho
 * necessário para cada demanda e as horas economizadas.
 */

HorasFTE.belongsTo(Melhoria, {
    foreignKey: 'id_demanda',
    targetKey: 'id_demanda',
    as: 'melhoria'
});

HorasFTE.belongsTo(Tempo, {
    foreignKey: 'unidade_tempo',
    targetKey: 'id',
    as: 'tempoInfo'
});

HorasFTE.belongsTo(Repeticao, {
    foreignKey: 'unidade_repeticao',
    targetKey: 'id',
    as: 'repeticaoInfo'
});

// Associações Status
Status.hasMany(DemandasBugDefeito, {
    foreignKey: 'status',
    as: 'demandasBug'
});

Status.hasMany(Melhoria, {
    foreignKey: 'status',
    as: 'demandasMelhoria'
});

// Associações Estagiarios
Estagiarios.hasMany(DemandasBugDefeito, {
    foreignKey: 'estagiario_atan',
    as: 'demandasEstagiarioAtan'
});

Estagiarios.hasMany(DemandasBugDefeito, {
    foreignKey: 'estagiario_atan_aux',
    as: 'demandasEstagiarioAtanAux'
});

Estagiarios.hasMany(ResponsaveisMelhoria, {
    foreignKey: 'estagiario_atan',
    as: 'demandasMelhoriaAtan'
});

Estagiarios.hasMany(ResponsaveisMelhoria, {
    foreignKey: 'estagiario_atan_aux',
    as: 'demandasMelhoriaAtanAux'
});

Estagiarios.hasMany(ResponsaveisMelhoria, {
    foreignKey: 'estagiario_design',
    as: 'demandasMelhoriaDesign'
});

Estagiarios.hasMany(ResponsaveisMelhoria, {
    foreignKey: 'estagiario_design_aux',
    as: 'demandasMelhoriaDesignAux'
});

// Associações Precificação
/**
 * Precificação é uma tabela auxiliar que relaciona
 * as demandas do tipo melhoria com a precificação de sprints
 * para as equipes de dev e design.
 */
Precificacao.belongsTo(Demandas, {
    foreignKey: 'id_demanda',
    as: 'demanda'
});

Precificacao.belongsTo(PrecificacaoDev, {
    foreignKey: 'precificacao_dev',
    targetKey: 'id',
    as: 'precificacaoDevInfo'
});

Precificacao.belongsTo(PrecificacaoDesign, {
    foreignKey: 'precificacao_design',
    targetKey: 'id',
    as: 'precificacaoDesignInfo'
});

// Associações Tags
Tags.belongsTo(Melhoria, {
    foreignKey: 'id_demanda',
    as: 'demanda'
});

Tags.belongsTo(TipTags, {
    foreignKey: 'tag',
    targetKey: 'id',
    as: 'tagsInfo' 
});

// Associações Andamento
/**
 * Andamento é uma tabela que relaciona demandas com suas
 * fases e etapas de progresso. Cada demanda pode ter múltiplos
 * registros de andamento conforme avança nas etapas.
 */
Demandas.hasMany(Andamento, {
    foreignKey: 'id_demanda',
    as: 'andamentos'
});

Andamento.belongsTo(Demandas, {
    foreignKey: 'id_demanda',
    as: 'demanda'
});

Andamento.belongsTo(tip_fases_etapas, {
    foreignKey: 'fase_etapa',
    targetKey: 'id',
    as: 'andamentoInfo'
});

tip_fases_etapas.hasMany(Andamento, {
    foreignKey: 'fase_etapa',
    as: 'andamentos'
});

module.exports = {
    Demandas,
    DemandasBugDefeito,
    Status,
    Melhoria,
    Area,
    Indicador,
    Inviabilidade,
    Estagiarios,
    Guthie,
    Gravidade,
    HorasEconomizadas,
    Impacto,
    Tendencia,
    Urgencia,
    Experiencia,
    HorasFTE,
    Tempo,
    Repeticao,
    ResponsaveisMelhoria,
    Precificacao,
    PrecificacaoDev,
    PrecificacaoDesign,
    Tags,
    TipTags,
    tip_fases_etapas,
    Andamento,
    LogHistoricoAndamento,
    MotivosDemanda,
    tip_motivos
};