/**
 * @file models/associations.js
 * @description Carrega dinamicamente todos os models e define suas associações.
 * @author Pedro e Rafaela
 */

const fs = require('fs');
const path = require('path');
const sequelize = require('../database/sequelizeConfig');

// =============================================================================
// CARREGAMENTO DINÂMICO DE MODELS
// =============================================================================

const models = {};
const IGNORE_FILES = ['associations.js', 'usuario.js'];

fs.readdirSync(__dirname)
    .filter(file => !IGNORE_FILES.includes(file) && file.endsWith('.js'))
    .forEach(file => {
        const model = require(path.join(__dirname, file));
        if (model.name) {
            models[model.name] = model;
        }
    });

// =============================================================================
// ASSOCIAÇÕES
// =============================================================================

/**
 * DEMANDAS (tabela principal)
 * Uma demanda pode ser Bug/Defeito OU Melhoria (herança)
 */
models.Demandas.hasOne(models.DemandasBugDefeito, {
    foreignKey: 'id_demanda',
    as: 'bugDefeito'
});

models.Demandas.hasOne(models.DemandasMelhoria, {
    foreignKey: 'id_demanda',
    as: 'melhoria'
});

models.Demandas.hasOne(models.ResponsaveisMelhoria, {
    foreignKey: 'id_demanda',
    as: 'responsaveis'
});

models.Demandas.hasOne(models.Precificacao, {
    foreignKey: 'id_demanda',
    as: 'precificacao'
});

models.Demandas.hasMany(models.Andamento, {
    foreignKey: 'id_demanda',
    as: 'andamentos'
});

models.Demandas.hasMany(models.Observacoes, {
    foreignKey: 'id_demanda',
    as: 'observacoes'
});

// N:N Demandas ↔ TipMotivos
models.Demandas.belongsToMany(models.TipMotivos, {
    through: models.MotivosDemanda,
    foreignKey: 'id_demanda',
    otherKey: 'motivo_id',
    as: 'motivos'
});

models.TipMotivos.belongsToMany(models.Demandas, {
    through: models.MotivosDemanda,
    foreignKey: 'motivo_id',
    otherKey: 'id_demanda',
    as: 'demandas'
});

/**
 * DEMANDAS BUG/DEFEITO
 */
models.DemandasBugDefeito.belongsTo(models.Demandas, {
    foreignKey: 'id_demanda',
    as: 'demanda'
});

models.DemandasBugDefeito.belongsTo(models.TipStatus, {
    foreignKey: 'status',
    as: 'statusInfo'
});

models.DemandasBugDefeito.belongsTo(models.TipEstagiarios, {
    foreignKey: 'estagiario_atan',
    as: 'estagiarioAtan'
});

models.DemandasBugDefeito.belongsTo(models.TipEstagiarios, {
    foreignKey: 'estagiario_atan_aux',
    as: 'estagiarioAtanAux'
});

/**
 * DEMANDAS MELHORIA
 */
models.DemandasMelhoria.belongsTo(models.Demandas, {
    foreignKey: 'id_demanda',
    as: 'demanda'
});

models.DemandasMelhoria.belongsTo(models.TipAreas, {
    foreignKey: 'area',
    as: 'areaInfo'
});

models.DemandasMelhoria.belongsTo(models.TipIndicadores, {
    foreignKey: 'vinculo_indicador',
    as: 'indicadorInfo'
});

models.DemandasMelhoria.belongsTo(models.TipInviabilidades, {
    foreignKey: 'inviabilidade',
    as: 'inviabilidadeInfo'
});

models.DemandasMelhoria.belongsTo(models.TipStatus, {
    foreignKey: 'status',
    as: 'statusInfo'
});

models.DemandasMelhoria.hasOne(models.MatrizGuthie, {
    foreignKey: 'id_demanda',
    sourceKey: 'id_demanda',
    as: 'guthieInfo'
});

models.DemandasMelhoria.hasOne(models.HorasFte, {
    foreignKey: 'id_demanda',
    sourceKey: 'id_demanda',
    as: 'horasFTEInfo'
});

/**
 * RESPONSÁVEIS MELHORIA
 */
models.ResponsaveisMelhoria.belongsTo(models.Demandas, {
    foreignKey: 'id_demanda',
    as: 'demanda'
});

models.ResponsaveisMelhoria.belongsTo(models.TipEstagiarios, {
    foreignKey: 'estagiario_atan',
    as: 'estagiarioAtan'
});

models.ResponsaveisMelhoria.belongsTo(models.TipEstagiarios, {
    foreignKey: 'estagiario_atan_aux',
    as: 'estagiarioAtanAux'
});

models.ResponsaveisMelhoria.belongsTo(models.TipEstagiarios, {
    foreignKey: 'estagiario_design',
    as: 'estagiarioDesign'
});

models.ResponsaveisMelhoria.belongsTo(models.TipEstagiarios, {
    foreignKey: 'estagiario_design_aux',
    as: 'estagiarioDesignAux'
});

/**
 * MATRIZ GUTHIE (cálculo de score para melhorias)
 */
models.MatrizGuthie.belongsTo(models.DemandasMelhoria, {
    foreignKey: 'id_demanda',
    targetKey: 'id_demanda',
    as: 'melhoria'
});

models.MatrizGuthie.belongsTo(models.TipGravidades, {
    foreignKey: 'gravidade',
    as: 'gravidadeInfo'
});

models.MatrizGuthie.belongsTo(models.TipHorasEconomizadas, {
    foreignKey: 'horas_economizadas',
    as: 'horasEconomizadasInfo'
});

models.MatrizGuthie.belongsTo(models.TipImpactos, {
    foreignKey: 'impacto',
    as: 'impactoInfo'
});

models.MatrizGuthie.belongsTo(models.TipTendencias, {
    foreignKey: 'tendencia',
    as: 'tendenciaInfo'
});

models.MatrizGuthie.belongsTo(models.TipUrgencias, {
    foreignKey: 'urgencia',
    as: 'urgenciaInfo'
});

models.MatrizGuthie.belongsTo(models.TipExperiencias, {
    foreignKey: 'experiencia',
    as: 'experienciaInfo'
});

/**
 * HORAS FTE (tempo estimado para melhorias)
 */
models.HorasFte.belongsTo(models.DemandasMelhoria, {
    foreignKey: 'id_demanda',
    targetKey: 'id_demanda',
    as: 'melhoria'
});

models.HorasFte.belongsTo(models.TipTempos, {
    foreignKey: 'unidade_tempo',
    as: 'tempoInfo'
});

models.HorasFte.belongsTo(models.TipRepeticoes, {
    foreignKey: 'unidade_repeticao',
    as: 'repeticaoInfo'
});

/**
 * PRECIFICAÇÃO (sprints dev/design)
 */
models.Precificacao.belongsTo(models.Demandas, {
    foreignKey: 'id_demanda',
    as: 'demanda'
});

models.Precificacao.belongsTo(models.TipPrecificacaoDev, {
    foreignKey: 'precificacao_dev',
    as: 'devInfo'
});

models.Precificacao.belongsTo(models.TipPrecificacaoDesign, {
    foreignKey: 'precificacao_design',
    as: 'designInfo'
});

/**
 * TAGS
 */
models.Tags.belongsTo(models.DemandasMelhoria, {
    foreignKey: 'id_demanda',
    targetKey: 'id_demanda',
    as: 'melhoria'
});

models.Tags.belongsTo(models.TipTags, {
    foreignKey: 'tag',
    as: 'tagInfo'
});

/**
 * ANDAMENTO (fases/etapas de progresso)
 */
models.Andamento.belongsTo(models.Demandas, {
    foreignKey: 'id_demanda',
    as: 'demanda'
});

models.Andamento.belongsTo(models.TipFasesEtapas, {
    foreignKey: 'fase_etapa',
    as: 'faseEtapaInfo'
});

/**
 * OBSERVAÇÕES
 */
models.Observacoes.belongsTo(models.Demandas, {
    foreignKey: 'id_demanda',
    as: 'demanda'
});

module.exports = { models, sequelize };