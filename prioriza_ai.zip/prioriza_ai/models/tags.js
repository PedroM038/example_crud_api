/**
 * @file models/tags.js
 * @description Modelo que representa tags. Cada demanda do tipo melhoria
 * pode se associar com várias tags. Esse modelo representa a tabela "tags"
 * da base de dados. Aqui, uma tag é um id que representa (via chave estrangeira)
 * uma linha da tabela tip_tags.
 */

const { DataTypes } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const Tags = sequelize.define('Tags', {
    id_tag: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    id_demanda: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'demandas',
            key: 'id_demanda'
        }
    },
    tag: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'tip_tags',
            key: 'id'
        }
    },
    matricula: {
        type: DataTypes.STRING(8),
        allowNull: true,
        defaultValue: null,
        comment: 'Matrícula da pessoa que inseriu a tag. Serve para logs'        
    },
}, {
    tableName: 'tags',
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci',
    timestamps: true
});

module.exports = Tags;