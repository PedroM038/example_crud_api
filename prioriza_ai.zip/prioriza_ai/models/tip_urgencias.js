/**
 * @file models/tip_urgencias.js
 * @description Modelo Sequelize para a tabela 'tip_urgencias'.
 * Este modelo representa as urgências possíveis de uma demanda.
 * Usamos para o cálculo de pontos e pesos na matriz Guthie.
 * @author Pedro e Rafaela
 */

const { DataTypes } = require("sequelize");
const sequelize = require("../database/sequelizeConfig");

const Urgencia = sequelize.define("urgencia", {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    peso: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    pontos: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    legenda: {
        type: DataTypes.STRING(100),
        allowNull: false
    }
}, {
    tableName: "tip_urgencias",
    charset: "utf8mb4",
    collate: "utf8mb4_unicode_ci"
});

module.exports = Urgencia;