/**
 * @file models/tip_urgencias.js
 * @description Modelo Sequelize para a tabela 'tip_urgencias'.
 * Este modelo representa as urgências possíveis de uma demanda.
 * Usamos para o cálculo de pontos e pesos na matriz Guthie.
 * @author Pedro e Rafaela
 */

const { DataTypes } = require("sequelize");
const sequelize = require("../database/sequelizeConfig");

const TipUrgencias = sequelize.define("TipUrgencias", {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    peso: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    pontos: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    legenda: {
        type: DataTypes.STRING(100),
        allowNull: false
    },
    createdAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'createdAt'
    },
    updatedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'updatedAt'
    }
}, {
    tableName: "tip_urgencias",
    charset: "utf8mb4",
    collate: "utf8mb4_unicode_ci",
    timestamps: true
});

module.exports = TipUrgencias;