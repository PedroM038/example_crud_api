/**
 * @file models/tip_repeticoes.js
 * @description Modelo Sequelize para a tabela 'tip_repeticoes'.
 * Este modelo representa as repetições possíveis de uma demanda.
 * Usado no calculo de horas-fte.
 * @author Pedro e Rafaela
 */

const { DataTypes } = require("sequelize");
const sequelize = require("../database/sequelizeConfig");

const TipRepeticoes = sequelize.define("TipRepeticoes", {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    repeticao: {
        type: DataTypes.STRING,
        allowNull: false
    },
    repeticao_freq: {
        type: DataTypes.STRING,
        allowNull: false
    },
    calc_repeticao: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    createdAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'createdAt'
    },
    updatedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'updatedAt'
    }
}, {
    tableName: "tip_repeticoes",
    charset: "utf8mb4",
    collate: "utf8mb4_unicode_ci",
    timestamps: true,
});

module.exports = TipRepeticoes;
