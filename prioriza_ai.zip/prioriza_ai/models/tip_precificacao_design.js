/**
 * @file models/tip_precificacao_design.js
 * @description Modelo Sequelize para a tabela 'tip_precificacao_design'.
 * Este modelo representa a precificação de design associada a demandas.
 */
const { DataTypes } = require("sequelize");
const sequelize = require("../database/sequelizeConfig")

const TipPrecificacaoDesign = sequelize.define("TipPrecificacaoDesign", {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    legenda: {
        type: DataTypes.STRING(2),
        allowNull: true,
        defaultValue: null,
    },
    quant_sprints: {
        type: DataTypes.TINYINT,
        allowNull: true,
        defaultValue: null
    },
    createdAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'createdAt'
    },
    updatedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'updatedAt'
    }
}, {
    tableName: "tip_precificacao_design",
    charset: "utf8mb4",
    collate: "utf8mb4_unicode_ci",
    timestamps: true,
});

module.exports = TipPrecificacaoDesign;