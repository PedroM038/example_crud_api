/**
 * @file models/tip_indicadores.js
 * @description Modelo Sequelize para a tabela 'tip_indicadores'.
 * Este modelo representa os indicadores que podem ser usados para categorizar e analisar demandas.
 * Os indicadores são usados para facilitar a priorização e análise das demandas.
 * @author Pedro e Rafaela
 */

const { DataTypes } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const TipIndicadores = sequelize.define('TipIndicadores', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    indicador: {
        type: DataTypes.STRING(100),
        allowNull: false
    },
    createdAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'createdAt'
    },
    updatedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'updatedAt'
    }
}, {
    tableName: 'tip_indicadores',
    paranoid: true,
    timestamps: true,
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci'
});

module.exports = TipIndicadores;