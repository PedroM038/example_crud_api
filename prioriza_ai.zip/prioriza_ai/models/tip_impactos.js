/**
 * @file models/tip_impactos.js
 * @description Modelo Sequelize para a tabela 'tip_impactos'.
 * Este modelo representa os impactos possíveis de uma demanda.
 * Usamos para o cálculo de pontos e pesos na matriz Guthie (pois é, muitos modelos associados à matriz).
 * @author Pedro e Rafaela
 */

const { DataTypes } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const TipImpactos = sequelize.define('TipImpactos', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    peso: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },

    pontos: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    legenda: {
        type: DataTypes.STRING(200),
        allowNull: false,
    },
    createdAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'createdAt'
    },
    updatedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'updatedAt'
    }
}, {
    tableName: 'tip_impactos',
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci',
    timestamps: true,
});

module.exports = TipImpactos;
