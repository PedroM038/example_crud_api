const { DataTypes } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const tip_motivos = sequelize.define('tip_motivos', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    motivo: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
},{
    tableName: 'tip_motivos',
    timestamps: true,
    paranoid: true,
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci'
});

module.exports = tip_motivos;