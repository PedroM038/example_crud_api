/**
 * @file models/tip_motivos.js
 * @description Modelo Sequelize para a tabela 'tip_motivos'.
 * Este modelo representa os motivos que podem ser associados a uma demanda.
 * Os motivos são usados para categorizar e analisar as demandas.
 * @author Pedro e Rafaela
 */
const { DataTypes } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const TipMotivos = sequelize.define('TipMotivos', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    motivo: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    createdAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'createdAt'
    },
    updatedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'updatedAt'
    }
}, {
    tableName: 'tip_motivos',
    timestamps: true,
    paranoid: true,
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci'
});

module.exports = TipMotivos;