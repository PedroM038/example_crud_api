/**
 * @file models/tip_gravidades.js
 * @description Modelo Sequelize para a tabela 'tip_gravidades'.
 * Este modelo representa as gravidades possíveis para uma demanda.
 * Usamos para o cálculo de pontos e pesos na matriz Guthie. 
* @author Pedro e Rafaela
 */

const { DataTypes } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const Gravidade = sequelize.define('Gravidade', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    peso: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    pontos: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    legenda: {
        type: DataTypes.STRING(250),
        allowNull: false
    },
}, {
    tableName: 'tip_gravidades',
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci'
});

module.exports = Gravidade;