/**
 * @file models/tip_status.js
 * @description Modelo Sequelize para a tabela 'tip_status'.
 * Este modelo representa os status possíveis de uma demanda.
 * Aqui temos uma lista de status que podem ser usados para categorizar e analisar as demandas.
 * Note que é geral. Se tivermos mais de um tipo de status (seja lá qual for o motivo),
 * podemos criar outro modelo específico para isso.
 * @author Pedro e Rafaela
 */

const { DataTypes } = require("sequelize");
const sequelize = require("../database/sequelizeConfig");

const Status = sequelize.define("Status", {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    status: {
        type: DataTypes.STRING(50),
        allowNull: false
    }
}, {
    tableName: "tip_status",
    timestamps: true,
    paranoid: true,
    charset: "utf8mb4",
    collate: "utf8mb4_unicode_ci"
});

module.exports = Status;