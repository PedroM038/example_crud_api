/**
 * @file models/matriz_guthie.js
 * @description Modelo Sequelize para a tabela 'matriz_guthie'.
 * Este modelo representa a matriz de priorização Guthie, que avalia demandas com base em critérios como gravidade, horas economizadas, impacto, tendência, urgência e experiência.
 * Cada demanda (tipologia melhoria) é associada a um conjunto de critérios que influenciam seu score de priorização.
 * @author Pedro e Rafaela
 */

const { DataTypes } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const MatrizGuthie = sequelize.define('MatrizGuthie', {
    id_guthie: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    id_demanda: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'demandas',
            key: 'id_demanda'
        }
    },
    gravidade: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_gravidades',
            key: 'id'
        }
    },
    horas_economizadas: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_horas_economizadas',
            key: 'id'
        }
    },
    impacto: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_impactos',
            key: 'id'
        }
    },
    tendencia: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_tendencias',
            key: 'id'
        }
    },
    urgencia: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_urgencias',
            key: 'id'
        }
    },
    experiencia: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_experiencias',
            key: 'id'
        }
    },
    score: {
        type: DataTypes.DECIMAL(4, 2),
        allowNull: true,
        defaultValue: 0
    },
    priorizacao_guthie: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    createdAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'createdAt'
    },
    updatedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'updatedAt'
    }
}, {
    tableName: 'matriz_guthie',
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci',
    timestamps: true,
    comment: 'Tabela que armazena a matriz de priorização Guthie para demandas do tipo melhoria'
});

module.exports = MatrizGuthie;