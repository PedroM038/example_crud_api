/**
 * @file models/responsaveis.js
 * @description Modelo Sequelize para a tabela 'responsaveis'.
 * A tabela de responsaveis linka os responsáveis a uma demanda do tipo melhoria específica.
 * 
 * Observação: A tabela de Responsáveis poderia integrar também demandas de outras tipologias.
 * Para isso, necessita de uma tabela que terá o tipo de responsável (funci_atan, funci_design, etc)
 * que poderá estar em uma tabela tip_responsaveis e cada linha aqui da tabela de responsáveis pode ser
 * -> id, id_demanda, tip_responsavel, nome, matricula.
 * @author Pedro e Rafaela
 */

const { DataTypes } = require("sequelize");
const sequelize = require("../database/sequelizeConfig");

const ResponsaveisMelhoria = sequelize.define("ResponsaveisMelhoria", {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    id_demanda: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'demandas',
            key: 'id_demanda'
        },
    },
    funci_atan: {
        type: DataTypes.STRING(200),
        allowNull: true,
        defaultValue: null
    }, 
    funci_atan_aux: {
        type: DataTypes.STRING(200),
        allowNull: true,
        defaultValue: null
    },
    funci_design: {
        type: DataTypes.STRING(200),
        allowNull: true,
        defaultValue: null
    },
    funci_design_aux: {
        type: DataTypes.STRING(200),
        allowNull: true,
        defaultValue: null
    },
    estagiario_atan: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_estagiarios',
            key: 'id'
        },
        defaultValue: null
    },
    estagiario_atan_aux: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_estagiarios',
            key: 'id'
        },
        defaultValue: null
    },
    estagiario_design: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_estagiarios',
            key: 'id'
        },
        defaultValue: null
    },
    estagiario_design_aux: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_estagiarios',
            key: 'id'
        },
        defaultValue: null
    },
}, {
    tableName: "responsaveis_melhoria",
    charset: "utf8mb4",
    collate: "utf8mb4_unicode_ci",
    timestamps: false
});

module.exports = ResponsaveisMelhoria;