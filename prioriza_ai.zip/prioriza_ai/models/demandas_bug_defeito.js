/**
 * @file models/demandas_bug_defeito.js
 * @description Modelo Sequelize para a tabela 'demandas_bug_defeito'.
 * Este modelo representa as demandas do tipo bug ou defeito.
 * @author Pedro e Rafaela
 */

const { DataTypes } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const DemandasBugDefeito = sequelize.define('DemandasBugDefeito', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    id_demanda: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'demandas',
            key: 'id_demanda'
        }
    },
    ferramenta: {
        type: DataTypes.INTEGER,
        allowNull: true,
        defaultValue: null,
        comment: 'Id que faz referência com a tabela de ferramentas do appCesup. Esse id é adquirido por via Api'
    },
    ferramenta_nome: {
        type: DataTypes.STRING(255),
        allowNull: true,
        defaultValue: null,
        comment: 'Nome da ferramenta que vem da api. Esse dado não deveria estar aqui, mas como falta competência das partes que estão construindo a ferramenta, esse campo existe apenas para mostrar no relatório'
    },
    status: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_status',
            key: 'id'
        },
        defaultValue: null
    },
    funci_atan: {
        type: DataTypes.STRING(100),
        allowNull: true,
        defaultValue: null
    },
    estagiario_atan: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_estagiarios',
            key: 'id'
        },
        defaultValue: null
    },
    estagiario_atan_aux: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_estagiarios',
            key: 'id'
        },
        defaultValue: null
    }
}, {
    tableName: 'demandas_bug_defeito',
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci',
    timestamps: false
});

module.exports = DemandasBugDefeito;