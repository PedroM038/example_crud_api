/**
 * @file models/horas-fte.js
 * @description Modelo Sequelize para a tabela 'horas_fte'.
 * Este modelo representa as horas de FTE (acho que significa Full-Time Equivalent) para demandas do tipo melhoria.
 * Ele relaciona as demandas com o tempo estimado para conclusão, quantidade de funcionários, tempo e repetições.
 * As horas FTE são usadas para calcular o tempo total de trabalho necessário para cada demanda e as horas economizadas.
 * @author Pedro e Rafaela
 */

const { DataTypes } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const HorasFTE = sequelize.define('HorasFTE', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    id_demanda: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'demandas',
            key: 'id_demanda'
        }
    },
    quantidade_funci: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    quantidade_tempo: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    quantidade_repeticao: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    unidade_tempo: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_tempos',
            key: 'id'
        }
    },
    unidade_repeticao: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_repeticoes',
            key: 'id'
        }
    },
    horas_ano: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: true
    },
    fte_ano: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: true
    }
}, {
    tableName: 'horas_fte',
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci',
    timestamps: false
});

module.exports = HorasFTE;