/**
 * @file models/horas_fte.js
 * @description Modelo Sequelize para a tabela 'horas_fte'.
 * Este modelo representa as horas de FTE (eficiência) para demandas do tipo melhoria.
 * Ele relaciona as demandas com o tempo estimado para conclusão, quantidade de funcionários e repetições.
 * @author Pedro e Rafaela
 */

const { DataTypes } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const HorasFte = sequelize.define('HorasFte', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    id_demanda: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'demandas',
            key: 'id_demanda'
        }
    },
    quantidade_funci: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    quantidade_tempo: {
        type: DataTypes.INTEGER,
        allowNull: true,
        comment: 'Apenas campo numérico que, junto com a unidade_tempo, define o tempo estimado para a conclusão da demanda'
    },
    quantidade_repeticao: {
        type: DataTypes.INTEGER,
        allowNull: true,
        comment: 'Número de repetições estimadas de uma certa atividade para a conclusão da demanda'
    },
    unidade_tempo: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_tempos',
            key: 'id'
        }
    },
    unidade_repeticao: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_repeticoes',
            key: 'id'
        }
    },
    horas_ano: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: true
    },
    fte_ano: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: true
    },
    createdAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'createdAt'
    },
    updatedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'updatedAt'
    }
}, {
    tableName: 'horas_fte',
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci',
    comment: 'Tabela que armazena as horas de FTE para demandas do tipo melhoria. Para mais informações sobre os campos, consulte equipe de design',
    timestamps: true
});

module.exports = HorasFte;