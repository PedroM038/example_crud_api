/**
 * @file models/tip_areas.js
 * @description Modelo Sequelize para a tabela 'tip_areas'.
 * Este modelo representa as áreas possíveis para uma demanda.
 * As áreas são usadas para categorizar as demandas e facilitar a priorização e análise.
 * @author Pedro e Rafaela
 */

const { DataTypes } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const Areas = sequelize.define('Areas', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    area: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
}, {
    tableName: 'tip_areas',
    timestamps: true,
    paranoid: true,
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci'
});

module.exports = Areas;