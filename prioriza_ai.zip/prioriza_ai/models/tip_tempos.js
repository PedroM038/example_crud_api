/**
 * @file models/tip_tempos.js
 * @description Modelo Sequelize para a tabela 'tip_tempos'.
 * Este modelo representa os tempos possíveis de uma demanda.
 * Usamos para o cálculo de pontos e pesos no calculo das horas-fte.
 */

const { DataTypes } = require("sequelize");
const sequelize = require("../database/sequelizeConfig");

const TipTempos = sequelize.define("TipTempos", {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    tempo: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    tempo_freq: {
        type: DataTypes.STRING(20),
        allowNull: false
    },
    calc_tempo: {
        type: DataTypes.DECIMAL(20, 6),
        allowNull: false
    },
    createdAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'createdAt'
    },
    updatedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'updatedAt'
    }
}, {
    tableName: "tip_tempos",
    charset: "utf8mb4",
    collate: "utf8mb4_unicode_ci",
    timestamps: true
});

module.exports = TipTempos;