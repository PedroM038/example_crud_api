/**
 * @file models/precificacao.js
 * @description Modelo Sequelize para a tabela 'precificacao'.
 * Este modelo representa a precificação associada às demandas, incluindo categorias de 
 * desenvolvimento e design. Cada demanda é vinculada a uma precificação específica que 
 * define custos (principalmente de tempo) relacionados ao desenvolvimento e design.
 * é linkada com os modelos de tip_precificacao_dev e tip_precificacao_design para categorização.
 * @author Pedro e Rafaela
 */
const { DataTypes } = require("sequelize");
const sequelize = require('../database/sequelizeConfig');

const Precificacao = sequelize.define('Precificacao', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
    },
    id_demanda: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'demandas',
            key: 'id_demanda'
        }
    },
    precificacao_dev: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_precificacao_dev',
            key: 'id'
        }
    },
    precificacao_design: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_precificacao_design',
            key: 'id'
        }
    },
    createdAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'createdAt'
    },
    updatedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'updatedAt'
    }
}, {
    tableName: 'precificacao',
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci',
    timestamps: true,
});

module.exports = Precificacao;