const { DataTypes} = require("sequelize");
const sequelize = require('../database/sequelizeConfig');

const Precificacao = sequelize.define('Precificacao', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
    },
    id_demanda: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'demandas',
            key: 'id_demanda'
        }
    },
    precificacao_dev: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_precificacao_dev',
            key: 'id'
        }
    },
    precificacao_design: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_precificacao_design',
            key: 'id' 
        }
    }
}, {
    tableName: 'precificacao',
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci',
    timestamps: false
});

module.exports = Precificacao;