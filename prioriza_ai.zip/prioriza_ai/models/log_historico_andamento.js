/**
 * @file models/log_historico_andamento.js
 * @description Modelo Sequelize para a tabela 'log_historico_andamento'.
 * Este modelo representa o histórico de ações realizadas em fases e etapas.
 * Ele registra ações como criação, edição, exclusão e outras mudanças.
 * Cada registro inclui a fase/etapa afetada, a ação realizada, a data e hora da ação,
 * o usuário que realizou a ação. */

const { DataTypes } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const LogHistoricoAndamento = sequelize.define('LogHistoricoAndamento', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    id_demanda: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'demandas',
            key: 'id_demanda'
        },
        comment: 'ID da demanda associada a este andamento'
    },
    acao: {
        type: DataTypes.STRING(50),
        allowNull: false,
        comment: 'Ação realizada: criacao, exclusao'
    },
    usuario: {
        type: DataTypes.STRING(100),
        allowNull: false,
        comment: 'Matrícula ou nome do usuário que realizou a ação'
    },
    etapa: {
        type: DataTypes.STRING(50),
        allowNull: true,
        comment: 'Valor da etapa no momento da ação'
    },
    fase: {
        type: DataTypes.STRING(100),
        allowNull: true,
        comment: 'Valor da fase no momento da ação'
    },
}, {
    tableName: 'log_historico_andamento',
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci',
    timestamps: true
});

module.exports = LogHistoricoAndamento;