/**
 * @file models/tip_precificacao_dev.js
 * @description Modelo Sequelize para a tabela 'tip_precificacao_dev'.
 * Este modelo representa a precificação de desenvolvimento associada a demandas.
 */
const { DataTypes } = require("sequelize");
const sequelize = require("../database/sequelizeConfig")

const TipPrecificacaoDev = sequelize.define("TipPrecificacaoDev", {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    legenda: {
        type: DataTypes.STRING(2),
        allowNull: true,
        defaultValue: null,
    },
    quant_sprints: {
        type: DataTypes.TINYINT,
        allowNull: true,
        defaultValue: null
    },
    createdAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'createdAt'
    },
    updatedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'updatedAt'
    }
}, {
    tableName: "tip_precificacao_dev",
    charset: "utf8mb4",
    collate: "utf8mb4_unicode_ci",
    timestamps: true,
});

module.exports = TipPrecificacaoDev;