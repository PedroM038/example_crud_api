const { DataTypes } = require("sequelize");
const sequelize = require("../database/sequelizeConfig")

const PrecificacaoDev = sequelize.define("PrecificacaoDev", {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    legenda: {
        type:DataTypes.STRING(2),
        allowNull: true,
        defaultValue: null,
    },
    quant_sprints: {
        type: DataTypes.TINYINT,
        allowNull: true,
        defaultValue: null
    }
}, {
    tableName: "tip_precificacao_dev",
    charset: "utf8mb4",
    collate: "utf8mb4_unicode_ci",
    timestamps: false,
});

module.exports = PrecificacaoDev;