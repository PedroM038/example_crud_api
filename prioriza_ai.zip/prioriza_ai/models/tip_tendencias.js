/**
 * @file models/tip_tendencias.js
 * @description Modelo Sequelize para a tabela 'tip_tendencias'.
 * Este modelo representa as tendências possíveis de uma demanda.
 * Usamos para o cálculo de pontos e pesos na matriz Guthie (eu acho).
 * @author Pedro e Rafaela
 */

const { DataTypes } = require("sequelize");
const sequelize = require("../database/sequelizeConfig");

const TipTendencias = sequelize.define("TipTendencias", {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    peso: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    pontos: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    legenda: {
        type: DataTypes.STRING(100),
        allowNull: false
    },
    createdAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'createdAt'
    },
    updatedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'updatedAt'
    }
}, {
    tableName: "tip_tendencias",
    charset: "utf8mb4",
    collate: "utf8mb4_unicode_ci",
    timestamps: true,
});

module.exports = TipTendencias;