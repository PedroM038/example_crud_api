/**
 * @file models/score.js
 * @description Modelo sequelize para a tabela 'score'.
 * @author Pedro e Rafaela
 */

const { DataTypes } = require("sequelize");
const sequelize = require("../database/sequelizeConfig");

const Score = sequelize.define("score", {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    classificacao: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    score_minimo: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    score_maximo: {
        type: DataTypes.INTEGER,
        allowNull: false
    }
}, {
    tableName: "tip_scores",
    charset: "utf8mb4",
    collate: "utf8mb4_unicode_ci"
});

module.exports = Score;