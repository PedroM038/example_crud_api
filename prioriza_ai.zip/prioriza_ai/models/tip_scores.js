/**
 * @file models/tip_scores.js
 * @description Modelo sequelize para a tabela 'tip_scores'. Essa tabela só existe para definir os 
 * intervalos de score e suas classificações. não é relacionada a nenhuma outra tabela.
 * @author Pedro e Rafaela
 */

const { DataTypes } = require("sequelize");
const sequelize = require("../database/sequelizeConfig");

const TipScores = sequelize.define("TipScores", {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    classificacao: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    score_minimo: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    score_maximo: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    createdAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'createdAt'
    },
    updatedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'updatedAt'
    }
}, {
    tableName: "tip_scores",
    charset: "utf8mb4",
    collate: "utf8mb4_unicode_ci",
    timestamps: true,
});

module.exports = TipScores;