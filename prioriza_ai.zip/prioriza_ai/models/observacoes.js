/**
 * @file models/observacoes.js
 * @description Modelo Sequelize para a tabela 'observacoes'.
 * Este modelo representa as observações feitas sobre demandas, permitindo registrar comentários e informações adicionais.
 * As observações são associadas a uma demanda específica e podem incluir a data da observação e a matrícula do usuário que fez a anotação.
 * @author Pedro e Rafaela
 */

const { DataTypes } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const Observacoes = sequelize.define('Observacoes', {
    id_observacao: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    id_demanda: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'demandas',
            key: 'id_demanda'
        }
    },
    observacao: {
        type: DataTypes.TEXT,
        allowNull: true
    },
    data: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
    },
    matricula: {
        type: DataTypes.STRING(8),
        allowNull: true,
    },
    nome: {
        type: DataTypes.STRING(150),
        allowNull: true,
    }
}, {
    tableName: 'observacoes',
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci',
    timestamps: false
});

module.exports = Observacoes;