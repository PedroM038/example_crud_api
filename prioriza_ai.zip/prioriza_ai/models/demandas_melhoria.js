/**
 * @file models/demandas-melhoria.js
 * @description Modelo Sequelize para a tabela 'demandas_melhoria'.
 * Este modelo representa as demandas do tipo melhoria.
 * 
 * Possível melhoria: São muitos campos reservados para responsáveis e estagiários.
 * Poderia ser normalizado em uma tabela separada para atribuições.
 * @author Pedro e Rafaela
 */

const { DataTypes } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const DemandasMelhoria = sequelize.define('DemandasMelhoria', {
    id_demanda_melhoria: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    id_demanda: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'demandas',
            key: 'id_demanda'
        }
    },
    area: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_areas',
            key: 'id'
        },
        defaultValue: null
    },
    escopo: {
        type: DataTypes.TEXT,
        allowNull: true,
        defaultValue: null
    },
    priorizacao_comite: {
        type: DataTypes.STRING(3),
        allowNull: true,
        defaultValue: null
    },
    status: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_status',
            key: 'id'
        },
        defaultValue: null
    },
    pessoas_envolvidas: {
        type: DataTypes.TEXT('long'),
        allowNull: true,
        defaultValue: null
    },
    mvp: {
        type: DataTypes.TEXT('long'),
        allowNull: true,
        defaultValue: null
    },
    vinculo_indicador: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_indicadores',
            key: 'id'
        },
        defaultValue: null

    },
    auditoria: {
        type: DataTypes.TEXT,
        allowNull: true,
        defaultValue: null
    },
    inviabilidade: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'tip_inviabilidades',
            key: 'id'
        },
        defaultValue: null
    },
    horas_bb: {
        type: DataTypes.STRING(3),
        allowNull: true,
        defaultValue: null
    },
    horas_previstas: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: true,
        defaultValue: null
    },
    horas_validadas: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: true,
        defaultValue: null
    },
    projeto: {
        type: DataTypes.STRING(3),
        allowNull: true,
        defaultValue: null
    },
    ferramenta: {
        type: DataTypes.STRING(3),
        allowNull: true,
        defaultValue: null
    },
}, {
    tableName: 'demandas_melhoria',
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci',
    timestamps: false
});

module.exports = DemandasMelhoria;