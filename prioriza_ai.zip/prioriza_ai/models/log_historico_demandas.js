/**
 * @file models/historico.js
 * @description Modelo Sequelize para a tabela 'historico'.
 * Este modelo representa o histórico de ações realizadas em demandas.
 * Ele registra ações como criação, edição, exclusão e outras mudanças de estado das demandas.
 * Cada registro inclui a demanda afetada, a ação realizada, a data e hora da ação, o usuário que realizou a ação e o
 * estado atual/detalhes (Todos os dados referentes à demanda, de acordo com sua tipologia, no momento da ação).
 * @author Pedro e Rafaela
 */

const { DataTypes } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const Historico = sequelize.define('Historico', {
    id_historico: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    id_demanda: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'demandas',
            key: 'id_demanda'
        }
    },
    acao: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    data_hora: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
    },
    usuario: {
        type: DataTypes.STRING(100),
        allowNull: false
    },

    // json com os detalhes da ação
    // uso isso para acompanhar mudanças de estado, por exemplo
    // se a ação for "edição", guardarei os dados atuais da demanda
    // assim, ao pesquisar por uma demanda, posso mostrar o histórico de mudanças
    // e o que foi alterado em cada mudança.
    detalhes: {
        type: DataTypes.JSON,
        allowNull: true
    }
}, {
    tableName: 'log_historico_demandas',
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci',
    timestamps: false
});

module.exports = Historico;