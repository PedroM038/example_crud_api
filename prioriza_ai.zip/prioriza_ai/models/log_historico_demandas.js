/**
 * @file models/log_historico_demandas.js
 * @description Modelo Sequelize para a tabela 'log_historico_demandas'.
 * Este modelo representa o histórico de ações realizadas em demandas.
 * Ele registra ações como criação, edição, exclusão e outras mudanças de estado das demandas.
 * Note que o atributo detalhes é um JSON que armazena o estado da demanda no momento da ação,
 * Faço isso para não precisar criar várias tabelas de log para cada tipo de demanda. Então,
 * para cada tipo de demanda os dados serão diferentes. Por isso, a criei views específicas para cada tipo de demanda
 * com base nessa tabela de log.
 * @author Pedro e Rafaela
 */

const { DataTypes } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const LogHistoricoDemandas = sequelize.define('LogHistoricoDemandas', {
    id_historico: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    id_demanda: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'demandas',
            key: 'id_demanda'
        }
    },
    acao: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    data_hora: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
    },
    usuario: {
        type: DataTypes.STRING(100),
        allowNull: false
    },

    /* json com os detalhes da ação
     uso isso para acompanhar mudanças de estado, por exemplo
     se a ação for "edição", guardarei os dados atuais da demanda
     assim, ao pesquisar por uma demanda, posso mostrar o histórico de mudanças
     e o que foi alterado em cada mudança.*/
    detalhes: {
        type: DataTypes.JSON,
        allowNull: true
    },
    createdAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'createdAt'
    },
    updatedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'updatedAt'
    }
}, {
    tableName: 'log_historico_demandas',
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci',
    timestamps: true
});

module.exports = LogHistoricoDemandas;