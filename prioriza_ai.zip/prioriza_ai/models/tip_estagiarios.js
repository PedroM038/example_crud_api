/**
 * @file models/tip_estagiarios.js
 * @description Modelo Sequelize para a tabela 'tip_estagiarios'.
 * Este modelo representa os estagiários que podem ser alocados em demandas.
 * Podemos, caso necessário, usar alguma API externa para buscar os estagiários.
 * Como não temos uma API externa, vamos usar o modelo para armazenar os estagiários. (infelizmente)
 * @author Pedro e Rafaela
 */

const { DataTypes } = require("sequelize");
const sequelize = require("../database/sequelizeConfig");

const Estagiarios = sequelize.define("Estagiarios", {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    equipe: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    matricula: {
        type: DataTypes.STRING(8),
        allowNull: false
    },
    nome: {
        type: DataTypes.STRING(100),
        allowNull: false
    },
}, {
    tableName: "tip_estagiarios",
    paranoid: true,
    timestamps: true,
    charset: "utf8mb4",
    collate: "utf8mb4_unicode_ci"
});

module.exports = Estagiarios;
