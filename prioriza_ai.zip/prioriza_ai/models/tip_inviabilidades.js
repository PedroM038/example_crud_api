/**
 * @file models/tip_inviabilidades.js
 * @description Modelo Sequelize para a tabela 'tip_inviabilidades'.
 * Este modelo representa as inviabilidades possíveis de uma demanda.
 * As inviabilidades são usadas para categorizar as demandas e facilitar a priorização e análise.
 * @author Pedro e Rafaela
 */

const { DataTypes } = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const Inviabilidade = sequelize.define('Inviabilidade', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },

    inviabilidade: {
        type: DataTypes.STRING(100),
        allowNull: false
    },
}, {
    tableName: 'tip_inviabilidades',
    paranoid: true,
    timestamps: true,
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci'
});

module.exports = Inviabilidade;