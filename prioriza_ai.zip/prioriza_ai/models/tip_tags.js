const {DataTypes} = require('sequelize');
const sequelize = require('../database/sequelizeConfig');

const TipTags = sequelize.define('TipTags', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    tag: {
        type: DataTypes.STRING,
        allowNull: false
    }
}, {
    tableName: 'tip_tags',
    timestamps: true,
    paranoid: true,
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci'
});

module.exports = TipTags;