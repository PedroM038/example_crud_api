/**
 * @file middlewares/verificaPermissao.js
 * @description Middleware para verificar permissões de usuário baseado em papéis
 * Verifica se o usuário autenticado tem as permissões necessárias para acessar uma rota
 * @author Pedro e Rafaela
 */

const { determinarPapelPorUor, temPermissao, temAlgumaPermissao } = require('../config/papelConfig');

/**
 * Middleware que verifica se o usuário tem uma permissão específica
 * @param {string} permissao - Permissão a verificar
 * @returns {Function} Middleware function
 */
function verificaPermissao(permissao) {
    return (req, res, next) => {
        // Verificar se usuário está autenticado (tem sessão e UOR)
        if (!req.session || !req.session.uor) {
            return res.status(401).json({ 
                erro: 'Usuário não autenticado' 
            });
        }

        // Verificar se tem a permissão
        if (temPermissao(req.session.uor, permissao)) {
            // Armazenar papel do usuário na requisição para uso posterior
            req.usuario = {
                papel: determinarPapelPorUor(req.session.uor),
                ...req.session
            };
            return next();
        }

        return res.status(403).json({ 
            erro: 'Acesso negado. Você não tem permissão para acessar este recurso.',
            permissaoNecessaria: permissao
        });
    };
}

/**
 * Middleware que verifica se o usuário tem alguma das permissões fornecidas
 * @param {Array} permissoes - Array de permissões a verificar
 * @returns {Function} Middleware function
 */
function verificaAlgumaPermissao(permissoes) {
    return (req, res, next) => {
        // Verificar se usuário está autenticado
        if (!req.session || !req.session.uor) {
            return res.status(401).json({ 
                erro: 'Usuário não autenticado' 
            });
        }

        // Verificar se tem alguma das permissões
        if (temAlgumaPermissao(req.session.uor, permissoes)) {
            req.usuario = {
                papel: determinarPapelPorUor(req.session.uor),
                ...req.session
            };
            return next();
        }

        return res.status(403).json({ 
            erro: 'Acesso negado. Você não tem permissão para acessar este recurso.',
            permissoesNecessarias: permissoes
        });
    };
}

/**
 * Middleware que apenas verifica autenticação, sem verificar permissões específicas
 * Útil para rotas que precisam de autenticação mas não de papéis específicos
 */
function verificaAutenticacao(req, res, next) {
    if (!req.session || !req.session.uor) {
        return res.status(401).json({ 
            erro: 'Usuário não autenticado' 
        });
    }

    req.usuario = {
        papel: determinarPapelPorUor(req.session.uor),
        ...req.session
    };
    
    return next();
}

module.exports = {
    verificaPermissao,
    verificaAlgumaPermissao,
    verificaAutenticacao
};
