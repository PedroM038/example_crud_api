/**
 * @file middlewares/securityHeaders.js
 * @description Este arquivo contém middlewares para adicionar headers de segurança e capturar o IP do cliente.
 * @author Pedro
 */

const requestIp = require("request-ip");

// Middleware para headers de segurança
const securityHeaders = (req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    
    if (process.env.NODE_ENV === 'production') {
        res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    }
    
    next();
};

// Middleware para capturar IP do cliente
const captureClientIp = (req, res, next) => {
    if (!req.session.ip) {
        req.session.ip = requestIp.getClientIp(req);
    }
    next();
};

module.exports = { securityHeaders, captureClientIp };