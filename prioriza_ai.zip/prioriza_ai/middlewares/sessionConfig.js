/**
 * @file middlewares/sessionConfig.js
 * @description Este arquivo contém a configuração do middleware de sessão para o Express.
 * Ele utiliza o MySQL como armazenamento de sessão, garantindo persistência e segurança.
 * @author Pedro
 */

const session = require("express-session");
const MySQLStore = require("express-mysql-session")(session);
const { v4: uuidv4 } = require("uuid");
const { conexao } = require("../database/bd");

// Configuração do MySQL Session Store
const sessionStore = new MySQLStore({
    ...conexao,
    createDatabaseTable: true,
    schema: {
        tableName: 'sessions',
        columnNames: {
            session_id: 'session_id',
            expires: 'expires',
            data: 'data'
        }
    }
});

const sessionConfig = session({
    key: 'sessionId',
    secret: process.env.SESSION_SECRET,
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    genid: () => uuidv4(),
    name: 'sessionId',
    cookie: {
        secure: process.env.NODE_ENV === 'production',
        maxAge: process.env.NODE_ENV === 'production' ? 1800000 : 600000, // 30min prod, 10min dev
        httpOnly: true, 
        sameSite: 'strict'
    },
    rolling: true
});

module.exports = { sessionConfig, sessionStore };