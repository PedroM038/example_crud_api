/**
 * @file middlewares/autenticaUsuario.js
 * @description Middleware para autenticação de usuários via SSO.
 * Valida o token do usuário, processa os atributos recebidos e armazena na sessão.
 * Redireciona para a página de login caso o token não seja válido ou não exista.
 * * Este middleware é utilizado para garantir que o usuário esteja autenticado antes de acessar rotas protegidas.
 * * Ele verifica a existência do token nos cookies, valida o token com o serviço SSO e processa os atributos do usuário.
 * * Se o token for inválido ou não existir, redireciona o usuário para a página de login.
 * @author Pedro e Rafaela
 */

const axios = require("axios");
const session = require("express-session");
const https = require("https");

// ============================================================================
// CONFIGURAÇÃO DE AMBIENTE
// ============================================================================
// Defina como 'true' para desenvolvimento local (bypass SSO)
// Defina como 'false' para produção (autenticação SSO real)
const IS_LOCAL_DEVELOPMENT = process.env.NODE_ENV !== 'production' || true;

// ============================================================================
// DADOS MOCKADOS PARA DESENVOLVIMENTO LOCAL
// ============================================================================
// Altere estes valores conforme necessário para testes locais
const MOCK_USER_DATA = {
    comissao: "1234",
    chave: "F1234567",
    prefixo: "0001",
    nome: "Usuário Desenvolvimento",
    uor: "286527",
    nomeguerra: "Dev User",
    cargo: "Desenvolvedor"
};

// Cache do agente HTTPS para reutilização
const httpsAgent = new https.Agent({ 
    rejectUnauthorized: false,
    keepAlive: true,
    timeout: 10000 // 10 segundos timeout
});

// Mapeamento de atributos para melhor manutenção
const ATTRIBUTE_MAPPING = {
    "cd-cmss-usu": "comissao",
    "chaveFuncionario": "chave", 
    "cd-pref-depe": "prefixo",
    "nm-idgl": "nome",
    "cd-eqp": "uor",
    "nomeGuerra": "nomeguerra",
    "tx-cmss-usu": "cargo"
};

module.exports = {
    async autenticaUsuario(req, res, next) {
        try {
            // Verificar se usuário já está autenticado
            if (req.session && req.session.nome) {
                return next();
            }

            // ================================================================
            // MODO DESENVOLVIMENTO LOCAL - BYPASS SSO
            // ================================================================
            if (IS_LOCAL_DEVELOPMENT) {
                console.log("[AUTH] Modo desenvolvimento local ativado - usando dados mockados");
                setMockUserSession(req);
                return next();
            }

            // ================================================================
            // MODO PRODUÇÃO - AUTENTICAÇÃO SSO REAL
            // ================================================================
            // Verifica se o token existe nos cookies
            if (!req.cookies?.BBSSOToken) {
                return redirectToLogin(req, res);
            }

            const response = await validateToken(req);
            
            if (response.status > 300) {
                return redirectToLogin(req, res);
            }

            // Processa atributos do usuário
            processUserAttributes(req, response.data.attributes);

            return next();
            
        } catch (error) {
            console.error("Erro ao validar token:", error.message);
            
            // Em desenvolvimento, mesmo com erro, usa dados mockados
            if (IS_LOCAL_DEVELOPMENT) {
                console.log("[AUTH] Erro na autenticação, usando dados mockados como fallback");
                setMockUserSession(req);
                return next();
            }
            
            return redirectToLogin(req, res);
        }
    },
};

// ============================================================================
// FUNÇÕES AUXILIARES
// ============================================================================

/**
 * Define os dados mockados do usuário na sessão (para desenvolvimento local)
 */
function setMockUserSession(req) {
    req.session.comissao = MOCK_USER_DATA.comissao;
    req.session.chave = MOCK_USER_DATA.chave;
    req.session.prefixo = MOCK_USER_DATA.prefixo;
    req.session.nome = MOCK_USER_DATA.nome;
    req.session.uor = MOCK_USER_DATA.uor;
    req.session.nomeguerra = MOCK_USER_DATA.nomeguerra;
    req.session.cargo = MOCK_USER_DATA.cargo;
}

/**
 * Redireciona para a página de login SSO
 */
function redirectToLogin(req, res) {
    const redirectUrl = `https://login.intranet.bb.com.br/sso/XUI/#login/&goto=https://${req.headers.host}${req.url}`;
    res.charset = "UTF-8";
    return res.redirect(redirectUrl);
}

/**
 * Valida o token SSO com o servidor de autenticação
 */
async function validateToken(req) {
    const headers = {
        cookie: req.headers.cookie,
        host: "sso.intranet.bb.com.br",
    };

    return await axios({
        method: "GET",
        url: "https://sso.intranet.bb.com.br/sso/identity/json/attributes",
        headers,
        httpsAgent,
        timeout: 10000
    });
}

/**
 * Processa os atributos retornados pelo SSO e armazena na sessão
 */
function processUserAttributes(req, attributes) {
    for (const atributo of attributes) {
        const sessionKey = ATTRIBUTE_MAPPING[atributo.name];
        if (sessionKey) {
            req.session[sessionKey] = atributo.name === "chaveFuncionario" 
                ? atributo.values + "" 
                : atributo.values[0];
        }
    }
}