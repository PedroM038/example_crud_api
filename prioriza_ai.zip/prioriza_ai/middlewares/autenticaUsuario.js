/**
 * @file middlewares/autenticaUsuario.js
 * @description Middleware para autenticação de usuários via SSO.
 * Valida o token do usuário, processa os atributos recebidos e armazena na sessão.
 * Redireciona para a página de login caso o token não seja válido ou não exista.
 * * Este middleware é utilizado para garantir que o usuário esteja autenticado antes de acessar rotas protegidas.
 * * Ele verifica a existência do token nos cookies, valida o token com o serviço SSO e processa os atributos do usuário.
 * * Se o token for inválido ou não existir, redireciona o usuário para a página de login.
 * @author Pedro e Rafaela
 */

const axios = require("axios");
const session = require("express-session");
const https = require("https");

// Cache do agente HTTPS para reutilização
const httpsAgent = new https.Agent({ 
    rejectUnauthorized: false,
    keepAlive: true,
    timeout: 10000 // 10 segundos timeout
});

// Mapeamento de atributos para melhor manutenção
const ATTRIBUTE_MAPPING = {
    "cd-cmss-usu": "comissao",
    "chaveFuncionario": "chave", 
    "cd-pref-depe": "prefixo",
    "nm-idgl": "nome",
    "cd-eqp": "uor",
    "nomeGuerra": "nomeguerra",
    "tx-cmss-usu": "cargo"
};

module.exports = {
    async autenticaUsuario(req, res, next) {
        try {
            // Verificar se usuário já está autenticado
            if (req.session && req.session.nome) {
                return next();
            }

            // Verifica se o token existe nos cookies
            if (!req.cookies?.BBSSOToken) {
                return redirectToLogin(req, res);
            }

            const response = await validateToken(req);
            
            if (response.status > 300) {
                return redirectToLogin(req, res);
            }

            // Processa atributos do usuário
            processUserAttributes(req, response.data.attributes);

            return next();
            
        } catch (error) {
            console.error("Erro ao validar token:", error.message);
            return redirectToLogin(req, res);
        }
    },
};

// Funções auxiliares
function redirectToLogin(req, res) {
    const redirectUrl = `https://login.intranet.bb.com.br/sso/XUI/#login/&goto=https://${req.headers.host}${req.url}`;
    res.charset = "UTF-8";
    return res.redirect(redirectUrl);
}

async function validateToken(req) {
    const headers = {
        cookie: req.headers.cookie,
        host: "sso.intranet.bb.com.br",
    };

    return await axios({
        method: "GET",
        url: "https://sso.intranet.bb.com.br/sso/identity/json/attributes",
        headers,
        httpsAgent,
        timeout: 10000
    });
}

function processUserAttributes(req, attributes) {
    for (const atributo of attributes) {
        const sessionKey = ATTRIBUTE_MAPPING[atributo.name];
        if (sessionKey) {
            req.session[sessionKey] = atributo.name === "chaveFuncionario" 
                ? atributo.values + "" 
                : atributo.values[0];
        }
    }
}