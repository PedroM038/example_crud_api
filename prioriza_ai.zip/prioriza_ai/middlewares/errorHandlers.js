/** 
 * @file middlewares/errorHandlers.js
 * @description Este arquivo contém middlewares para tratamento de erros no Express.
 * Ele inclui um middleware para lidar com erros 404 (rota não encontrada) e outro para tratamento de erros gerais.
 * @author Pedro
*/

// Middleware para tratamento de erro 404
const notFoundHandler = (req, res, next) => {
    const error = new Error(`Rota não encontrada: ${req.originalUrl}`);
    error.status = 404;
    next(error);
};

// Middleware para tratamento de erros gerais
const errorHandler = (err, req, res, next) => {
    console.error("Erro no servidor:", {
        message: err.message,
        stack: process.env.NODE_ENV !== 'production' ? err.stack : undefined,
        url: req.originalUrl,
        method: req.method,
        ip: req.ip,
        userAgent: req.get('User-Agent')
    });
    
    const status = err.status || 500;
    const message = process.env.NODE_ENV === 'production' 
        ? 'Erro interno do servidor' 
        : err.message;
    
    // Se for uma requisição AJAX, retorna JSON
    if (req.xhr || req.headers.accept?.indexOf('json') > -1) {
        return res.status(status).json({ 
            error: true, 
            message,
            status 
        });
    }
    
    // Caso contrário, renderiza a página de erro
    res.status(status).render("error", { message, status });
};

module.exports = { notFoundHandler, errorHandler };