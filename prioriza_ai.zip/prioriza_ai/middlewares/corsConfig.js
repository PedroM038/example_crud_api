/* 
    * @file middlewares/corsConfig.js
    * @description Este arquivo contém a configuração do middleware CORS para o aplicativo.
    * O CORS (Cross-Origin Resource Sharing) é um mecanismo que permite que recursos de um servidor sejam acessados por páginas web de origens diferentes.
*/

const cors = require("cors");

const corsConfig = cors({
    origin: true, // Permite qualquer origem. Pode ser ajustado para um domínio específico.
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization', 'Cookie', 'X-Requested-With'],
    optionsSuccessStatus: 200
});

module.exports = corsConfig;