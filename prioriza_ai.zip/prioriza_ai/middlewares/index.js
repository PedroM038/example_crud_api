/**
 * @file middlewares/index.js
 * @description Este arquivo centraliza todos os middlewares utilizados na aplicação.
 * Facilita a importação e organização dos middlewares.
 * @author Pedro
 */

const { autenticaUsuario } = require("./autenticaUsuario");
const { sessionConfig, sessionStore } = require("./sessionConfig");
const corsConfig = require("./corsConfig");
const { securityHeaders, captureClientIp } = require("./securityHeaders");
const { notFoundHandler, errorHandler } = require("./errorHandlers");
const { verificaPermissao, verificaAlgumaPermissao, verificaAutenticacao } = require("./verificaPermissao");

module.exports = {
    autenticaUsuario,
    sessionConfig,
    sessionStore,
    corsConfig,
    securityHeaders,
    captureClientIp,
    notFoundHandler,
    errorHandler,
    verificaPermissao,
    verificaAlgumaPermissao,
    verificaAutenticacao
};