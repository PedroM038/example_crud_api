"""
Script para converter arquivo Markdown (.md) para PDF formatado

Para executar, certifique-se de ter o python instalado.

instale as dependências:
    pip install markdown2 reportlab

para executar, garanta que você esteja no diretório correto e execute:
    python converte-md.py

Ou, na raiz do projeto:
    python docs/converte-md.py
"""

import os
from pathlib import Path

try:
    import markdown2
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.lib.enums import TA_LEFT, TA_CENTER
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle
    from reportlab.lib import colors
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
except ImportError as e:
    print(f" Erro: Biblioteca não encontrada - {e}")
    print("\n Instale as dependências com:")
    print("   pip install markdown2 reportlab")
    exit(1)


def processar_markdown_para_pdf(arquivo_md, arquivo_pdf):
    """
    Converte arquivo Markdown para PDF com formatação
    
    Args:
        arquivo_md: caminho do arquivo .md
        arquivo_pdf: caminho do arquivo .pdf de saída
    """
    
    # Ler conteúdo Markdown
    try:
        with open(arquivo_md, 'r', encoding='utf-8') as f:
            conteudo_md = f.read()
    except FileNotFoundError:
        print(f" Arquivo não encontrado: {arquivo_md}")
        return False
    except Exception as e:
        print(f" Erro ao ler arquivo: {e}")
        return False
    
    # Converter Markdown para HTML
    html_content = markdown2.markdown(
        conteudo_md,
        extras=['tables', 'fenced-code-blocks', 'break-on-newline']
    )
    
    # Criar PDF
    doc = SimpleDocTemplate(
        arquivo_pdf,
        pagesize=A4,
        rightMargin=72,
        leftMargin=72,
        topMargin=72,
        bottomMargin=50
    )
    
    # Estilos
    styles = getSampleStyleSheet()
    
    # Estilo personalizado para título principal
    styles.add(ParagraphStyle(
        name='CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        textColor=colors.HexColor('#1a1a1a'),
        spaceAfter=30,
        alignment=TA_CENTER,
        fontName='Helvetica-Bold'
    ))
    
    # Estilo para subtítulos
    styles.add(ParagraphStyle(
        name='CustomHeading',
        parent=styles['Heading2'],
        fontSize=16,
        textColor=colors.HexColor('#2c3e50'),
        spaceAfter=12,
        spaceBefore=12,
        fontName='Helvetica-Bold'
    ))
    
    # Estilo para código
    styles.add(ParagraphStyle(
        name='CustomCode',
        parent=styles['Code'],
        fontSize=9,
        textColor=colors.HexColor('#c7254e'),
        backColor=colors.HexColor('#f9f2f4'),
        leftIndent=10,
        rightIndent=10,
        spaceAfter=10
    ))
    
    # Processar conteúdo
    story = []
    linhas = conteudo_md.split('\n')
    
    i = 0
    while i < len(linhas):
        linha = linhas[i].strip()
        
        # Títulos
        if linha.startswith('# ') and not linha.startswith('## '):
            texto = linha[2:].strip()
            story.append(Paragraph(texto, styles['CustomTitle']))
            story.append(Spacer(1, 0.3 * inch))
        
        elif linha.startswith('## '):
            texto = linha[3:].strip()
            story.append(Spacer(1, 0.2 * inch))
            story.append(Paragraph(texto, styles['CustomHeading']))
            story.append(Spacer(1, 0.1 * inch))
        
        elif linha.startswith('### '):
            texto = linha[4:].strip()
            story.append(Paragraph(f"<b>{texto}</b>", styles['Normal']))
            story.append(Spacer(1, 0.1 * inch))
        
        # Tabelas simples (detecta linhas com |)
        elif '|' in linha and linha.startswith('|'):
            # Coletar linhas da tabela
            tabela_linhas = []
            while i < len(linhas) and '|' in linhas[i]:
                if not linhas[i].strip().startswith('|---') and not linhas[i].strip().startswith('| ---'):
                    cells = [c.strip() for c in linhas[i].split('|')[1:-1]]
                    if cells:
                        tabela_linhas.append(cells)
                i += 1
            
            if tabela_linhas:
                # Converter células de texto em Paragraphs para permitir quebra de linha
                tabela_processada = []
                for idx, row in enumerate(tabela_linhas):
                    if idx == 0:
                        # Cabeçalho - fonte menor e bold
                        tabela_processada.append([
                            Paragraph(f"<b>{cell}</b>", styles['Normal']) for cell in row
                        ])
                    else:
                        # Células normais - permitir quebra de linha
                        tabela_processada.append([
                            Paragraph(cell, styles['Normal']) for cell in row
                        ])
                
                # Criar tabela com larguras proporcionais
                num_cols = len(tabela_processada[0])
    
                # Largura disponível (A4 com margens)
                largura_disponivel = A4[0] - 144  # 72pt de margem em cada lado
                col_widths = [largura_disponivel / num_cols] * num_cols
                
                table = Table(tabela_processada, colWidths=col_widths)
                table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#3498db')),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 9),
                    ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
                    ('TOPPADDING', (0, 0), (-1, 0), 8),
                    ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#ecf0f1')),
                    ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
                    ('FONTSIZE', (0, 1), (-1, -1), 8),
                    ('LEFTPADDING', (0, 0), (-1, -1), 6),
                    ('RIGHTPADDING', (0, 0), (-1, -1), 6),
                    ('TOPPADDING', (0, 1), (-1, -1), 6),
                    ('BOTTOMPADDING', (0, 1), (-1, -1), 6),
                ]))
                story.append(table)
                story.append(Spacer(1, 0.2 * inch))
            continue
        
        # Blocos de código
        elif linha.startswith('```'):
            codigo_linhas = []
            i += 1
            while i < len(linhas) and not linhas[i].strip().startswith('```'):
                codigo_linhas.append(linhas[i])
                i += 1
            
            if codigo_linhas:
                codigo_texto = '<br/>'.join(codigo_linhas)
                story.append(Paragraph(f"<font name='Courier'>{codigo_texto}</font>", styles['CustomCode']))
                story.append(Spacer(1, 0.1 * inch))
        
        # Lista com marcadores
        elif linha.startswith('- ') or linha.startswith('* '):
            texto = linha[2:].strip()
            story.append(Paragraph(f"• {texto}", styles['Normal']))
        
        # Lista numerada
        elif len(linha) > 2 and linha[0].isdigit() and linha[1] == '.':
            texto = linha[linha.index('.')+1:].strip()
            story.append(Paragraph(f"{linha[:linha.index('.')+1]} {texto}", styles['Normal']))
        
        # Texto normal
        elif linha:
            import re
            linha = re.sub(r'`([^`]+)`', r'<font name="Courier" color="#c7254e">\1</font>', linha)
            linha = re.sub(r'\*\*([^*]+)\*\*', r'<b>\1</b>', linha)
            
            story.append(Paragraph(linha, styles['Normal']))
            story.append(Spacer(1, 0.05 * inch))
        
        else:
            # Linha vazia
            story.append(Spacer(1, 0.1 * inch))
        
        i += 1
    
    # Gerar PDF
    try:
        doc.build(story)
        print(f"✅ PDF gerado com sucesso: {arquivo_pdf}")
        return True
    except Exception as e:
        print(f"❌ Erro ao gerar PDF: {e}")
        return False


def main():
    """Função principal"""
    # Caminhos dos arquivos
    script_dir = Path(__file__).parent
    arquivo_md = script_dir / "doc.md"
    arquivo_pdf = script_dir / "doc.pdf"
    
    print("=" * 60)
    print("  CONVERSOR MARKDOWN → PDF")
    print("=" * 60)
    print(f"\n📄 Arquivo de entrada: {arquivo_md}")
    print(f"📄 Arquivo de saída:   {arquivo_pdf}\n")
    
    if not arquivo_md.exists():
        print(f" Arquivo não encontrado: {arquivo_md}")
        return
    
    # Processar conversão
    sucesso = processar_markdown_para_pdf(str(arquivo_md), str(arquivo_pdf))
    
    if sucesso:
        print(f"\n Conversão concluída!")
        print(f"📂 Arquivo salvo em: {arquivo_pdf.absolute()}")
    else:
        print("\n Falha na conversão")


if __name__ == "__main__":
    main()
