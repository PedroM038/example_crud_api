## Documentação do Projeto

# Prioriza Aí — Documentação do Projeto

## Visão geral

Projeto web para priorização de demandas (Demandas / Melhoria / Bug/Defeito). Aplicação construída com Node.js + Express e EJS para renderização de views no servidor. Utiliza MySQL via Sequelize como ORM e organiza a lógica em camadas (controllers → services → models).

## Sobre essa documentação
Aqui você encontrará requisitos mais técnicos sobre a aplicação. É para ser um lugar amigável para os DEVs. Qualquer modificação feita no arquivo Markdown, deve ser também atualizada para o PDF. Utilize o script converte-md.py ou use algum conversor online para garantir sempre a última versão desse arquivo. Não deixe de conferir a seção de comentários úteis!

## Requisitos

- Node.js >= 18 (ver `package.json`)
- MySQL (ou compatível)
- NPM

Dependências principais: Express, EJS, Sequelize, mysql2, express-session, express-mysql-session.

## Instalação

1. Clone o repositório
2. Instale dependências:

```powershell
npm install
```

3. Configure variáveis de ambiente: crie um arquivo `.env` na raiz com as chaves necessárias. Use o arquivo `.env.example` como referência:

Depois, edite `.env` com suas credenciais reais (banco de dados, SESSION_SECRET etc.).

Variáveis principais:

- `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASS`, `DB_NAME` — conexão com MySQL
- `SESSION_SECRET` — chave secreta para express-session (use string aleatória longa)
- `PORT` — porta do servidor (padrão: 3000)
- `NODE_ENV` — ambiente (development ou production)
- `VERSAO` — versão da aplicação (opcional, exibida no front-end)

## Scripts úteis

Leia o `package.json`:

- `npm start` — inicia a aplicação (produção): `node app.js`
- `npm run dev` — inicia em modo de desenvolvimento com `nodemon` (recarregamento automático)

## Como executar

1. Configure `.env`
2. Rode `npm install`
3. Execute em desenvolvimento:

```powershell
npm run dev
```

Ou em produção:

```powershell
npm start
```

Se desejar usar HTTPS local, a pasta `ssl/` contém `key.pem` e `server.crt` — a configuração de uso depende de `server.js`/`app.js`.

## Estrutura do projeto

obs: Se for incluir novos diretórios ou arquivos, adicione aqui.

- `database/` — código relacionado à conexão e configuração do ORM/DB
	- `conexao.js` — arquivo de conexão com o banco (MySQL)
	- `sequelizeConfig.js` — configuração do Sequelize (usado por `sequelize-cli`)
	- `bd.js`, `index.js` — utilitários ou inicializadores do banco

- `models/` — definem os modelos Sequelize que espelham tabelas do banco
	- `associations.js` — define relacionamentos entre modelos. É um modelo chave que permite não precisarmos fazer um milhão de joins entre as tabelas
		(Obviamente a operação de JOIN ainda existe, mas por baixo dos panos).
	- modelos principais: `demandas.js`, `usuario.js`, `observacoes.js`, `matriz_guthie.js`, e vários `tip_*` para tabelas de referência (status, urgência, tempos etc.)
	- Também existem modelos auxiliares para demandas do tipo bug/defeito e melhoria.

- `services/` — camada de negócio que encapsula regras e acesso a dados
	- Cada recurso tem um service (por ex. `demandas_service.js`, `melhoria_service.js`, `bug_defeito_service.js`).
	- Controllers chamam os services para obter/atualizar dados.
	- São arquivos maiores, pois contém regras de negócio, tratamento de erros, etc.
	- Aqui fica a sujeira por baixo dos panos.

- `controllers/` — tratadores de rotas/requests
	- Recebem requisições HTTP, chamam services e retornam views ou JSON.
	- Exemplos: `demandas_controller.js`, `melhoria_controller.js`, `bug_defeito_controller.js`, `observacoes_controller.js`.
	- Observação: note que os controladores tratam apenas do fluxo de dado, e não de toda lógica de negócio. É o gerente 
		que chama os outros (services) para fazerem o trabalho sujo.

- `middlewares/` — middlewares Express usados pela aplicação
	- `autenticaUsuario.js` — proteção de rotas e verificação de sessão
	- `sessionConfig.js` — configuração de sessão (usa `express-session` / `express-mysql-session`)
	- `corsConfig.js` — configuração de CORS
	- `securityHeaders.js` — headers de segurança personalizados
	- `errorHandlers.js` — middlewares para tratamento de erros
	- É um diretório que você provavelmente não quer mexer. =( =)

- `routes/` — definem as rotas da aplicação
	- `routes.js` — centraliza rotas e associa controllers. Quando adicionar novas rotas, atualize este arquivo.
	- O proposito das rotas e dizer "Olha, esse fluxo aqui vai ser controlado por alguém".
	- Exemplo: Rota 'index/' (home) é associada ao controlador "Demandas". 

- `public/` — ativos estáticos servidos ao cliente
	- `css/` — estilos (Tailwind / custom)
	- `js/` — scripts front-end (Ex.: `calcula-score.js`, `dataTable.js`, `demanda-adicionar.js`, `observacoes.js`)
	- `images/`, `fontawesome/`, `webfonts/`
	- Um destaque especial para o js/ . Muitos se confundem, mas em suma, o objetivo desses JavaScripts públicos
		é controlar o DOM. Em nenhum momento eles interferem na lógica de negócio. Podemos, por meio deles, preparar
		os dados de um formulário e mandar para um controlador, por exemplo.

- `views/` — templates EJS que geram HTML no servidor
	- `index.ejs`, `error.ejs` e `partials/` com modais, importações e o sidebar.
	- Temos aqui a magia dos includes. Basicamente, para não deixamos arquivos com milhões de linhas,
		usamos parciais para modularização.

Se estiver muito perdido, tente acompanhar o fluxo de criar demanda (um dos mais básicos). Veja no controlador de Demandas, os estáticos no front (modal e javascript) e também a lógica no service.

## Banco de dados e ORM

- Cuidado com o ambiente para produção! Sempre confira as bases de dados:
	7419Demandas: Produção.
	7419Demandas_hm: Desenvolvimento (Homologação)
	7419Demandas_Backup: Base de backup. Contém apenas dados e não relações.
- A aplicação usa Sequelize como ORM (`sequelize` + `mysql2`).
- Para migrações/seeders, o projeto inclui `sequelize-cli` como dependência — se você usar migrations, verifique a pasta padrão `migrations/` (pode não existir neste repositório).
- O uso de ORM foi pensando para facilitar, e não complicar. A maioria das funcionalidades que você consegue fazer com sql (crud, por exemplo), você também conseguirá fazer com ORM.
- Dúvidas de sintaxe, consulte a documentação do sequelize.

## Fluxo de desenvolvimento (como adicionar uma nova entidade)

1. Criar model em `models/` com a definição Sequelize (Se necessário. Se não, use os existentes).
2. Adicionar relacionamentos em `models/associations.js` se necessário.
3. Criar service em `services/` para lógica e operações com o model.
4. Criar controller em `controllers/` para expor endpoints ou renderizar views.
5. Adicionar rotas em `routes/routes.js` para mapear URLs a controller/actions.
6. Criar views/parciais em `views/` e assets em `public/` quando necessário.

## Rotas e controllers (visão geral)

- As rotas estão centralizadas em `routes/routes.js`. Os controllers recebem o request, chamam os services e retornam respostas. Para APIs internas, prefira respostas JSON; para páginas, renderize EJS.

## Endpoints / API — Documentação detalhada

Todos os endpoints retornam JSON (exceto as páginas principais que renderizam EJS). A autenticação é feita via sessão (middleware `autenticaUsuario.js`).

Abaixo tento abordar todos ou a maioria dos endPoints (ficaria agradecido se alguém pudesse verificar a veracidade de toda informação. Pois provavelmente esqueci de algo).

### Páginas principais

| Método | Rota | Descrição | Controller | Resposta |
|--------|------|-----------|------------|----------|
| `GET` | `/` ou `/index` | Página inicial — lista todas as demandas ativas | `DemandasCtl. index` | Renderiza `index.ejs` com dados do usuário e lista de demandas |

### Demandas (CRUD básico)

| Método | Rota | Descrição | Controller | Body/Params | Resposta |
|--------|------|-----------|------------|-------------|----------|
| `GET` | `/ demanda / nova` | Buscar dados para criar nova demanda (form) | `DemandasCtl. criarDemandaForm` | — | `{ success: true, tipologias: [...] }` |
| `POST` | `/ demanda / inserir` | Criar nova demanda | `DemandasCtl. criarDemanda` | JSON com campos da demanda (tipologia, nome, descrição etc.) | `{ success: true, message: "...", data: {...} }` |
| `POST` | `/ excluir-demanda / :id` | Soft delete de uma demanda (marca como excluída) | `DemandasCtl. excluirDemanda` | `:id` (params) | `{ success: true, message: "Demanda excluída com sucesso" }` |

**Observação:** `criarDemanda` aceita os campos da tabela `demandas` (tipologia, numero_gd, nome_demanda, descricao, data_solicitacao etc.). Tipologias aceitas: `Bug`, `Defeito`, `Melhoria`, `Tutoria`, `Acesso`, `Mineração de Dados e ETL`.

### Demandas tipo Bug/Defeito

| Método | Rota | Descrição | Controller | Body/Params | Resposta |
|--------|------|-----------|------------|-------------|----------|
| `GET` | `/ demanda/ visualizar-bug-defeito/ :id` | Ver detalhes de uma demanda Bug/Defeito | `BugDefeitoCtl. verDemanda` | `:id` (params) | `{ success: true, demanda: {...} }` |
| `GET` | `/ demanda/ editar-bug-defeito/ :id` | Buscar dados para editar Bug/Defeito (form) | `BugDefeitoCtl. editarForm` | `:id` (params) | `{ success: true, demanda: {...}, ferramentas: [...], status: [...], funcionarios: [...], estagiarios: [...], categorias: [...] }` |
| `PUT` | `/ demanda/ editar-bug-defeito/ :id` | Editar demanda Bug/Defeito | `BugDefeitoCtl. editarDemanda` | `:id` (params) + JSON: `{ ferramenta, status, funci_atan?, estagiario_atan?, estagiario_atan_aux? }` | `{ success: true, message: "...", data: {...} }` |

**Campos obrigatórios para edição:** `ferramenta`, `status`. Outros campos são opcionais (responsáveis).

### Demandas tipo Melhoria

| Método | Rota | Descrição | Controller | Body/Params | Resposta |
|--------|------|-----------|------------|-------------|----------|
| `GET` | `/ demanda/ visualizar-melhoria/ :id` | Ver detalhes de uma demanda Melhoria | `MelhoriaCtl. verDemanda` | `:id` (params) | `{ success: true, demanda: {...} }` |
| `GET` | `/ demanda/ editar-melhoria/ :id` | Buscar dados para editar Melhoria (form) | `MelhoriaCtl. editarForm` | `:id` (params) | `{ success: true, demanda: {...}, areas: [...], fases: [...], indicadores: [...], inviabilidades: [...], status: [...], funcionariosAtan: [...], funcionariosDesign: [...], estagiariosAtan: [...], estagiariosDesign: [...], experiencias: [...], gravidades: [...], horasEconomizadas: [...], impactos: [...], tendencias: [...], urgencias: [...], tempos: [...], repeticoes: [...], score: [...], categorias: [...] }` |
| `PUT` | `/ demanda/ editar-melhoria/ :id` | Editar demanda Melhoria | `MelhoriaCtl. editarDemanda` | `:id` (params) + JSON com campos: `area`, `escopo`, `score`, `gravidade`, `urgencia`, `tendencia`, `horas_economizadas`, `impacto`, `experiencia`, `priorizacao_guthie`, `priorizacao_comite`, `pontos_contato`, `envolvidos`, `afetados`, `vinculo_indicador_id`, `auditoria`, `inviabilidade_id`, `status_id`, `fase_id`, responsáveis (funcionários/estagiários Design e Atan), campos de FTE (`fte_ano`, `horas_ano`, `unidade_tempo`, `unidade_repeticao`, `quantidade_tempo`, `quantidade_repeticao`, `quantidade_funcionario`) | `{ success: true, message: "...", data: {...} }` |

**Observação:** Demandas do tipo Melhoria têm campos adicionais relacionados à Matriz de Guthrie (gravidade, urgência, tendência, score etc.) e cálculo de FTE (horas/ano).

### Observações (comentários das demandas)

| Método | Rota | Descrição | Controller | Body/Params | Resposta |
|--------|------|-----------|------------|-------------|----------|
| `GET` | `/ demanda/ observacoes/ :idDemanda` | Listar observações de uma demanda | `ObservacoesCtl. observacoesForm` | `:idDemanda` (params) | `{ success: true, observacoes: [...], message: "..." }` |
| `POST` | `/ demanda/ observacoes/ inserir` | Adicionar nova observação a uma demanda | `ObservacoesCtl. inserir` | JSON: `{ idDemanda, observacao }` | `{ success: true, message: "Observação inserida com sucesso", data: {...} }` |

**Observação:** Todas as ações (criar demanda, editar, inserir observação, excluir) são registradas automaticamente no histórico (`log_historico_demandas`) com dados do usuário da sessão.

### Respostas de erro (comuns a todos os endpoints)

- `400 Bad Request` — validação falhou (ex.: campos obrigatórios faltando)
- `404 Not Found` — demanda não encontrada
- `500 Internal Server Error` — erro no servidor (banco de dados, lógica etc.)

Formato de erro padrão:
```json
{
  "success": false,
  "message": "Descrição do erro"
}
```

## Middlewares importantes

- Autenticação: `middlewares/autenticaUsuario.js` — verifica sessão do usuário já na rede interna do banco.
- Sessão: `middlewares/sessionConfig.js` — configura armazenamento de sessão (MySQL) e cookies.
- Erros: `middlewares/errorHandlers.js` — captura erros e renderiza `error.ejs`.

## SSL

- A pasta `ssl/` contém `key.pem` e `server.crt`. Use com cuidado e não comite certificados sensíveis em repositórios públicos.

## Testes e qualidade

- Atualmente não há uma suíte de testes incluída no repositório. Sugestões de melhoria:
	- Adicionar testes unitários para services (Mocha/Chai/Jest)
	- Adicionar linting (ESLint) e integração contínua

## Próximos passos e melhorias recomendadas

- Automatizar, via rotina ou afins, a base de dados Backup.
- Migrarmos a aplicação para usar as configurações do NGINX (Fale com o Iuri primeiro).
- Documentar endpoints principais com Postman/OpenAPI (Veja seção "Endpoints / API").
- Incluir exemplos de variáveis de ambiente (arquivo `.env.example`).
- Adicionar testes automatizados e CI.
- Extrair strings estáticas para i18n se necessário.
- Adicionar validação de campos no front-end antes de submeter formulários
- Como podemos otimizar o projeto para novos tipos de demandas?
- O escopo da ferramenta poderia crescer para um GESTÃO DE DEMANDAS ?

## Comentários Úteis

- O projeto foi feito em cima da estrutura básica node (Vide projeto basico node no gitlab). Se você quiser aprender mais sobre 
Configurações de baixo nível, estilo de arquitetura, comece por lá, e não por aqui!

- USE APENAS A BASE DE DADOS PARA DESENVOLVIMENTO (7419Demandas_hm). Se você executar o projeto, no modo developer (veja o .env) em cima da base em produção, o orm vai utilizar os métodos alter e isso pode ser catastrófico caso não saiba o que está fazendo. O projeto conta com uma base backup, agradeceria se alguém conseguisse automatizar ela para atualizar os dados a cada ciclo de tempo.

- Sobre os Logs: Foi pedido que qualquer alteração de demanda seja guardada na base de dados. Por esse motivo, eu guardo na tabela de logs um JSON que armazena o estado atual da demanda. 
Então por exemplo, quando criada, ela vai com campos nulos, e basta uma simples edição que guardo novamente todos os dados. 
Demandas do tipo bug/defeito compartilham os mesmos dados, e as de melhoria possuem dados a mais. Essa abordagem tem um problema de normalização de dados na base de dados (Atributos multivalorados quebram a primeira forma normal). o correto
seria ter tabelas de log para cada tipo de demanda. 

- Olhe com cuidado os services das demandas (o geral, o de bug e defeito e o de melhoria). A mágica ocorre nas funções de mapeamento. 
O mapeamento por id foca na tipologia da demanda. Basicamente, é uma boa forma de garantir que todos os dados de uma demanda de certo tipo estejam ali para serem acessados. 
O mapeamento geral (lista) prepara os dados para mostrar no front. O problema é que as pessoas que pediram essa aplicação não pensaram muito bem no caso de que ter uma tabela para mostrar as demandas que possuem dados e campos diferentes não era uma boa ideia. Então, por exemplo, o mapeamento geral das demandas bug e defeito possui campo de funcionário design = NULL, mesmo que esse tipo de demanda NÃO tenha um funcionário do design (Imagina um funcionário do design cuidando de um bug, que perigo). Então a tabela do front acredita que há um campo chamado funci_design para acessar. Se eu não fizesse isso, ele tentaria acessar um campo inexistente e muito provavelmente cairia em um erro. 

## Contato / manutenção

Para dúvidas sobre o código ou deploy, abra uma issue no repositório ou contacte o analista responsável pelo projeto.

---