/**
 * @file database/sequelizeConfig.js
 * @description Configuração da conexão Sequelize com MySQL.
 * @author Pedro
 */

require("dotenv").config();

const { Sequelize } = require("sequelize");

const sequelize = new Sequelize(
    process.env.DATABASE, // database
    process.env.USER_DB,  // username
    process.env.PASS,     // password
    {
        host: process.env.HOSTSQL,
        port: process.env.DB_PORT,
        dialect: "mysql",
        pool: {
            max: 100,
            min: 0,
            acquire: 30000,
            idle: 900000, // 15 minutos
            evict: 10000,
        },
        dialectOptions: {
            // charset e timezone
            charset: "utf8mb4",
            // SSL (desabilitado) - precisamos melhorar a questão de segurança da base de dados
            ssl: false,
        },
        define: {
            // Garante charset nas tabelas criadas pelo Sequelize
            charset: "utf8mb4",
            collate: "utf8mb4_unicode_ci",
        },
        logging: process.env.NODE_ENV !== 'production' ? console.log : false, // log apenas em desenvolvimento
    }
);

module.exports = sequelize;