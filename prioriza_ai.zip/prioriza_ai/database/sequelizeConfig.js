/**
 * @file database/sequelizeConfig.js
 * @description Configuração da instância Sequelize
 * @author Pedro
 */

const { Sequelize } = require("sequelize");
const dbConfig = require('./config');

const sequelize = new Sequelize(
    dbConfig.database,
    dbConfig.user,
    dbConfig.password,
    {
        host: dbConfig.host,
        port: dbConfig.port,
        dialect: "mysql",
        pool: {
            max: dbConfig.connectionLimit,
            min: 0,
            acquire: 30000,
            idle: dbConfig.idleTimeout,
            evict: 10000,
        },
        dialectOptions: {
            charset: dbConfig.charset,
            ssl: dbConfig.ssl,
        },
        define: {
            charset: dbConfig.charset,
            collate: "utf8mb4_unicode_ci",
        },
        logging: process.env.NODE_ENV !== 'production' ? console.log : false,
    }
);

module.exports = sequelize;