/**
 * @file database/config.js
 * @description Configurações centralizadas de conexão com banco de dados MySQL
 * @author Pedro
 */

require("dotenv").config();

const dbConfig = {
    host: process.env.HOSTSQL,
    port: process.env.DB_PORT,
    database: process.env.DATABASE,
    user: process.env.USER_DB,
    password: process.env.PASS,
    
    // Pool
    connectionLimit: 100,
    queueLimit: 30,
    
    // Timeouts
    idleTimeout: 900000, // 15 minutos
    
    // Charset
    charset: 'utf8mb4',
    timezone: 'local',
    
    // Segurança
    ssl: false,
    multipleStatements: false,
    
    // TypeCast para TINYINT -> boolean
    typeCast: function (field, next) {
        if (field.type === 'TINY' && field.length === 1) {
            return field.string() === '1';
        }
        return next();
    }
};

module.exports = dbConfig;
