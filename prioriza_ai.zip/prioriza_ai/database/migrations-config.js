/**
 * @file database/migrations-config.js
 * @description Configuração do Sequelize CLI para migrations
 * 
 * Este arquivo é usado APENAS pelo sequelize-cli (npx sequelize-cli)
 * A aplicação usa o arquivo database/sequelizeConfig.js
 * 
 * PROTEÇÃO DE PRODUÇÃO:
 * - Para rodar migrations em produção, use: NODE_ENV=production npx sequelize-cli db:migrate
 * - O ambiente 'production' requer confirmação explícita via NODE_ENV
 */

require('dotenv').config();

// ============================================================================
// PROTEÇÃO: Detecta se está tentando rodar em produção
// ============================================================================
const dbName = process.env.DATABASE || '';
const devSuffixes = ['_hm', '_bkp'];
const isDevDatabase = devSuffixes.some(suffix => dbName.toLowerCase().endsWith(suffix));

if (!isDevDatabase && process.env.NODE_ENV !== 'production') {
    console.error('');
    console.error('╔══════════════════════════════════════════════════════════════════════════════╗');
    console.error('║  🛑  ATENÇÃO: BANCO DE PRODUÇÃO DETECTADO                                    ║');
    console.error('╠══════════════════════════════════════════════════════════════════════════════╣');
    console.error(`║  Banco: ${dbName.padEnd(64)}║`);
    console.error('║                                                                              ║');
    console.error('║  Para executar migrations em PRODUÇÃO, confirme definindo:                   ║');
    console.error('║     NODE_ENV=production npx sequelize-cli db:migrate                         ║');
    console.error('║                                                                              ║');
    console.error('║  Para desenvolvimento, use um banco com sufixo _hm, _dev ou _test            ║');
    console.error('╚══════════════════════════════════════════════════════════════════════════════╝');
    console.error('');
    process.exit(1);
}

module.exports = {
    development: {
        username: process.env.USER_DB,
        password: process.env.PASS,
        database: process.env.DATABASE,
        host: process.env.HOSTSQL,
        port: process.env.DB_PORT || 3306,
        dialect: 'mysql',
        charset: 'utf8mb4',
        collate: 'utf8mb4_unicode_ci',
        logging: console.log
    },
    test: {
        username: process.env.USER_DB,
        password: process.env.PASS,
        database: process.env.DATABASE + '_test',
        host: process.env.HOSTSQL,
        port: process.env.DB_PORT || 3306,
        dialect: 'mysql',
        charset: 'utf8mb4',
        collate: 'utf8mb4_unicode_ci',
        logging: false
    },
    production: {
        username: process.env.USER_DB,
        password: process.env.PASS,
        database: process.env.DATABASE,
        host: process.env.HOSTSQL,
        port: process.env.DB_PORT || 3306,
        dialect: 'mysql',
        charset: 'utf8mb4',
        collate: 'utf8mb4_unicode_ci',
        logging: false,
        pool: {
            max: 10,
            min: 0,
            acquire: 30000,
            idle: 10000
        }
    }
};
