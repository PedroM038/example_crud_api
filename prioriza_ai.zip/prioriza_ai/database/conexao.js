/**
 * @file database/conexao.js
 * @description Configuração da conexão com o banco de dados MySQL usando mysql2.
 * Inclui criação de pool, funções de conexão, query, transações e health check.
 * @author Pedro
 */

const mysql = require("mysql2/promise");
const { conexao } = require("./bd");

// Criando pool com mysql2
const pool = mysql.createPool(conexao);

// Função para testar conexão na inicialização
async function testConnection() {
    try {
        const connection = await pool.getConnection();
        console.log("Conexão com banco de dados estabelecida");
        connection.release();
        return true;
    } catch (error) {
        console.error("Erro ao conectar com banco de dados:", error.message);
        return false;
    }
}

// Graceful shutdown
process.on("SIGINT", async () => {
    try {
        await pool.end();
        console.log("Pool de conexões fechado");
        process.exit(0);
    } catch (err) {
        console.error("Erro ao fechar pool:", err);
        process.exit(1);
    }
});

process.on("SIGTERM", async () => {
    try {
        await pool.end();
        console.log("Pool de conexões fechado (SIGTERM)");
        process.exit(0);
    } catch (err) {
        console.error("Erro ao fechar pool:", err);
        process.exit(1);
    }
});

// Função para obter conexão (mantendo compatibilidade)
async function getConnection() {
    try {
        const connection = await pool.getConnection();
        return connection;
    } catch (error) {
        console.error("Erro ao obter conexão:", error);
        throw error;
    }
}

// Função para query direta com retry
async function query(sql, params = []) {
    const maxRetries = 3;
    let lastError;
    
    for (let i = 0; i < maxRetries; i++) {
        try {
            const [results] = await pool.execute(sql, params);
            return results;
        } catch (error) {
            lastError = error;
            console.error(`Tentativa ${i + 1}/${maxRetries} falhou:`, error.message);
            
            // Se não é o último retry, aguarda antes de tentar novamente
            if (i < maxRetries - 1) {
                await new Promise(resolve => setTimeout(resolve, 1000 * (i + 1)));
            }
        }
    }
    
    throw lastError;
}

// Função para transações
async function transaction(callback) {
    const connection = await getConnection();
    try {
        await connection.beginTransaction();
        const result = await callback(connection);
        await connection.commit();
        return result;
    } catch (error) {
        await connection.rollback();
        throw error;
    } finally {
        connection.release();
    }
}

// Função para verificar health do banco
async function healthCheck() {
    try {
        await query("SELECT 1 as health");
        return { status: "healthy", timestamp: new Date().toISOString() };
    } catch (error) {
        return { 
            status: "unhealthy", 
            error: error.message, 
            timestamp: new Date().toISOString() 
        };
    }
}

// Teste inicial da conexão
testConnection();

module.exports = {
    pool,
    getConnection,
    query,
    transaction,
    healthCheck,
    testConnection
};