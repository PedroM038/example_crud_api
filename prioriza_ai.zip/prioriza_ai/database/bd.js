/**
 * @file database/bd.js
 * @description Configuração da conexão com o banco de dados MySQL.
 * Inclui configurações de pool, keep-alive, segurança e charset.
 * @author Pedro
 */

require("dotenv").config();

module.exports = {
    conexao: {
        // Configurações de Pool
        connectionLimit: 100, 
        queueLimit: 30,
        
        // Configurações de conexão
        host: process.env.HOSTSQL,
        user: process.env.USER_DB,
        password: process.env.PASS,
        database: process.env.DATABASE,
        port: process.env.DB_PORT,
        
        // Configurações de keep-alive
        idleTimeout: 900000, // 15 minutos
        typeCast: function (field, next) {
            if (field.type === 'TINY' && field.length === 1) {
                return (field.string() === '1'); // Converte TINYINT para boolean
            }
            return next();
        },
        
        // Configurações de segurança
        ssl: false,

        // Configurações extras de segurança
        multipleStatements: false, // Mudado para false por segurança
        charset: 'utf8mb4',
        timezone: 'local'
    }
};