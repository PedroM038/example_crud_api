/**
 * @file database/index.js
 * @description Inicialização do banco de dados (Sequelize + Pool MySQL2)
 * @author Pedro
 */

const mysql = require("mysql2/promise");
const sequelize = require('./sequelizeConfig');
const dbConfig = require('./config');
require('../models/associations');

// Pool MySQL2 para queries diretas (tabelas externas)
const pool = mysql.createPool(dbConfig);

/**
 * Executa query SQL direta com retry automático
 * @param {string} sql - Query SQL
 * @param {Array} params - Parâmetros da query
 * @returns {Promise<Array>}
 */
async function query(sql, params = []) {
    const maxRetries = 3;
    let lastError;
    
    for (let i = 0; i < maxRetries; i++) {
        try {
            const [results] = await pool.execute(sql, params);
            return results;
        } catch (error) {
            lastError = error;
            console.error(`Query tentativa ${i + 1}/${maxRetries} falhou:`, error.message);
            if (i < maxRetries - 1) {
                await new Promise(resolve => setTimeout(resolve, 1000 * (i + 1)));
            }
        }
    }
    throw lastError;
}

/**
 * Inicializa conexões com o banco de dados
 * @returns {Promise<boolean>}
 */
async function initDatabase() {
    try {
        // Testa conexão Sequelize
        await sequelize.authenticate();
        console.log('✅ Conexão Sequelize estabelecida.');
        
        // Testa conexão do pool MySQL2
        const conn = await pool.getConnection();
        conn.release();
        console.log('✅ Pool MySQL2 estabelecido.');
        
        // Sincroniza models
        const alterTables = process.env.NODE_ENV !== 'production';
        await sequelize.sync({ alter: alterTables });
        console.log('📋 Models sincronizados.');
        
        return true;
    } catch (error) {
        console.error('❌ Erro ao inicializar banco:', error);
        return false;
    }
}

/**
 * Fecha todas as conexões com o banco
 */
async function closeDatabase() {
    try {
        await sequelize.close();
        await pool.end();
        console.log('🔐 Conexões de banco fechadas.');
    } catch (error) {
        console.error('❌ Erro ao fechar conexões:', error);
    }
}

module.exports = { 
    sequelize,
    pool,
    query,
    dbConfig,
    initDatabase, 
    closeDatabase
};