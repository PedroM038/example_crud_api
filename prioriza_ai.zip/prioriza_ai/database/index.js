/**
 * @file database/index.js
 * @description Inicialização e sincronização dos models Sequelize.
 * @author Pedro
 */

const sequelize = require('./sequelizeConfig');
const models = require('../models/associations');

// Função para inicializar e sincronizar
async function initDatabase() {
    try {
        // 1. Testa a conexão com a database
        await sequelize.authenticate();
        console.log('✅ Conexão Sequelize estabelecida com sucesso.');
        
        // 2. Sincroniza os models com as tabelas
        if (process.env.NODE_ENV !== 'production') {
            // Em desenvolvimento: altera tabelas se necessário
            await sequelize.sync({ alter: true });
            console.log('📋 Models sincronizados com o banco.');
        } else {
            // Em produção: apenas verifica se as tabelas existem
            await sequelize.sync({ alter: false });
            console.log('📋 Verificação de models concluída.');
        }
        
        return true;
    } catch (error) {
        console.error('❌ Erro ao inicializar banco:', error);
        return false;
    }
}

// Função para fechar conexões
async function closeDatabase() {
    try {
        await sequelize.close();
        console.log('🔐 Conexões Sequelize fechadas.');
    } catch (error) {
        console.error('❌ Erro ao fechar conexões:', error);
    }
}

module.exports = { 
    sequelize, 
    initDatabase, 
    closeDatabase
};