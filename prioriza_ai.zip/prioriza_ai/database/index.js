/**
 * @file database/index.js
 * @description Inicialização do banco de dados (Sequelize + Pool MySQL2)
 * @author Pedro
 * 
 * MODOS DE SINCRONIZAÇÃO (variável DB_SYNC_MODE):
 * - "none"   : Não sincroniza (RECOMENDADO para produção - use migrations)
 * - "safe"   : Apenas cria tabelas que não existem (seguro)
 * - "alter"  : Altera tabelas existentes (CUIDADO - pode dar erro com constraints)
 * - "force"  : Recria todas as tabelas (PERIGO - apaga todos os dados!)
 * 
 * PROTEÇÃO DE PRODUÇÃO:
 * - Bases SEM sufixo "_hm" são consideradas PRODUÇÃO
 * - Operações destrutivas (alter, force) são BLOQUEADAS em produção
 * - Para forçar (NÃO RECOMENDADO), use: ALLOW_PRODUCTION_SYNC=true
 */

const mysql = require("mysql2/promise");
const sequelize = require('./sequelizeConfig');
const dbConfig = require('./config');
require('../models/associations');

// Pool MySQL2 para queries diretas (tabelas externas)
const pool = mysql.createPool(dbConfig);

// Configurações de sincronização
const SYNC_MODES = {
    none: null,                          // Não sincroniza
    safe: { alter: false, force: false }, // Apenas cria novas tabelas
    alter: { alter: true, force: false }, // Altera estrutura existente
    force: { alter: false, force: true }  // Recria tudo (APAGA DADOS!)
};

// ============================================================================
// PROTEÇÃO DE BANCO DE PRODUÇÃO
// ============================================================================

/**
 * Verifica se o banco atual é de produção
 * Regra: banco é PRODUÇÃO se NÃO termina com "_hm" (homologação)
 * 
 * Exemplos:
 *   - "7419Demandas"     → PRODUÇÃO ⛔
 *   - "7419Demandas_hm"  → Homologação ✅
 * 
 * @returns {boolean}
 */
function isProductionDatabase() {
    const dbName = dbConfig.database || '';
    
    // Lista de sufixos que indicam ambiente de desenvolvimento/homologação
    const devSuffixes = ['_hm', "_bkp"];
    
    // Se o nome do banco termina com algum sufixo de dev, NÃO é produção
    const isDev = devSuffixes.some(suffix => 
        dbName.toLowerCase().endsWith(suffix)
    );
    
    return !isDev;
}

/**
 * Valida se a operação é permitida no banco atual
 * @param {string} syncMode - Modo de sincronização
 * @returns {{ allowed: boolean, reason?: string }}
 */
function validateDatabaseOperation(syncMode) {
    const dbName = dbConfig.database;
    const isProd = isProductionDatabase();
    const dangerousModes = ['alter', 'force'];
    
    // Modos perigosos em produção
    if (isProd && dangerousModes.includes(syncMode)) {
        // Permite bypass apenas se explicitamente configurado (NÃO RECOMENDADO)
        if (process.env.ALLOW_PRODUCTION_SYNC === 'true') {
            return {
                allowed: true,
                reason: `⚠️  BYPASS ATIVO: Operação ${syncMode.toUpperCase()} permitida em PRODUÇÃO por ALLOW_PRODUCTION_SYNC=true`
            };
        }
        
        return {
            allowed: false,
            reason: `
╔══════════════════════════════════════════════════════════════════════════════╗
║  🛑  OPERAÇÃO BLOQUEADA - BANCO DE PRODUÇÃO DETECTADO                        ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  Banco atual: ${dbName.padEnd(58)}║
║  Modo solicitado: ${syncMode.toUpperCase().padEnd(54)}║
║                                                                              ║
║  ❌ Operações '${syncMode}' não são permitidas em bancos de produção.          ║
║                                                                              ║
║  📋 SOLUÇÕES:                                                                ║
║     1. Use um banco de desenvolvimento (sufixo _hm, _dev, _test)             ║
║     2. Use DB_SYNC_MODE=none e gerencie com migrations                       ║
║     3. Para desenvolvimento, configure DATABASE=7419Demandas_hm              ║
║                                                                              ║
║  ⚠️  Se você REALMENTE precisa fazer isso (NÃO RECOMENDADO):                 ║
║     Adicione ALLOW_PRODUCTION_SYNC=true no .env                              ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝`
        };
    }
    
    return { allowed: true };
}

/**
 * Retorna o modo de sincronização baseado no ambiente
 * @returns {string}
 */
function getSyncMode() {
    // Prioridade: variável explícita > baseado no ambiente
    if (process.env.DB_SYNC_MODE) {
        return process.env.DB_SYNC_MODE.toLowerCase();
    }
    
    // Padrões por ambiente
    switch (process.env.NODE_ENV) {
        case 'production':
            return 'none';  // NUNCA sincroniza em produção
        case 'test':
            return 'force'; // Recria para testes limpos
        default:
            return 'safe';  // Desenvolvimento: apenas cria novas
    }
}

/**
 * Executa query SQL direta com retry automático
 * @param {string} sql - Query SQL
 * @param {Array} params - Parâmetros da query
 * @returns {Promise<Array>}
 */
async function query(sql, params = []) {
    const maxRetries = 3;
    let lastError;
    
    for (let i = 0; i < maxRetries; i++) {
        try {
            const [results] = await pool.execute(sql, params);
            return results;
        } catch (error) {
            lastError = error;
            console.error(`Query tentativa ${i + 1}/${maxRetries} falhou:`, error.message);
            if (i < maxRetries - 1) {
                await new Promise(resolve => setTimeout(resolve, 1000 * (i + 1)));
            }
        }
    }
    throw lastError;
}

/**
 * Limpa constraints órfãs antes do sync (resolve problemas de refatoração)
 * @param {string} tableName - Nome da tabela
 * @param {string} constraintName - Nome da constraint
 */
async function dropConstraintIfExists(tableName, constraintName) {
    try {
        const [constraints] = await pool.execute(`
            SELECT CONSTRAINT_NAME 
            FROM information_schema.TABLE_CONSTRAINTS 
            WHERE TABLE_SCHEMA = ? 
            AND TABLE_NAME = ? 
            AND CONSTRAINT_NAME = ?
        `, [dbConfig.database, tableName, constraintName]);
        
        if (constraints.length > 0) {
            await pool.execute(`ALTER TABLE \`${tableName}\` DROP FOREIGN KEY \`${constraintName}\``);
            console.log(`🧹 Constraint órfã removida: ${tableName}.${constraintName}`);
        }
    } catch (error) {
        // Ignora erros silenciosamente
    }
}

/**
 * Inicializa conexões com o banco de dados
 * @returns {Promise<boolean>}
 */
async function initDatabase() {
    try {
        // Exibe informações do banco
        const dbName = dbConfig.database;
        const isProd = isProductionDatabase();
        
        console.log('');
        console.log(`🗄️  Banco de dados: ${dbName}`);
        console.log(`🏷️  Tipo: ${isProd ? '🔴 PRODUÇÃO' : '🟢 Desenvolvimento/Homologação'}`);
        
        // Testa conexão Sequelize
        await sequelize.authenticate();
        console.log('✅ Conexão Sequelize estabelecida.');
        
        // Testa conexão do pool MySQL2
        const conn = await pool.getConnection();
        conn.release();
        console.log('✅ Pool MySQL2 estabelecido.');
        
        // Determina modo de sincronização
        const syncMode = getSyncMode();
        const syncOptions = SYNC_MODES[syncMode];
        
        console.log(`🔧 Ambiente: ${process.env.NODE_ENV || 'development'}`);
        console.log(`🔧 Modo de sincronização: ${syncMode.toUpperCase()}`);
        
        // ================================================================
        // VALIDAÇÃO DE SEGURANÇA - PROTEÇÃO DE PRODUÇÃO
        // ================================================================
        const validation = validateDatabaseOperation(syncMode);
        
        if (!validation.allowed) {
            console.error(validation.reason);
            console.error('');
            console.error('❌ Aplicação NÃO iniciada por segurança.');
            process.exit(1); // Encerra a aplicação
        }
        
        if (validation.reason) {
            console.warn(validation.reason);
        }
        // ================================================================
        
        if (!syncOptions) {
            console.log('📋 Sincronização desabilitada (use migrations em produção).');
            return true;
        }
        
        // Aviso de segurança para modos perigosos
        if (syncMode === 'force') {
            console.warn('⚠️  ATENÇÃO: Modo FORCE ativo - todas as tabelas serão recriadas!');
        }
        if (syncMode === 'alter') {
            console.warn('⚠️  ATENÇÃO: Modo ALTER ativo - pode causar erros com constraints.');
        }
        
        // Sincroniza models
        await sequelize.sync(syncOptions);
        console.log('📋 Models sincronizados com sucesso.');
        
        return true;
    } catch (error) {
        // Tratamento especial para erros de constraint
        if (error.name === 'SequelizeUnknownConstraintError') {
            console.error(`❌ Erro de constraint: "${error.constraint}" na tabela "${error.table}"`);
            console.error('');
            console.error('💡 SOLUÇÕES:');
            console.error('   1. Execute no MySQL: SET FOREIGN_KEY_CHECKS=0; DROP TABLE IF EXISTS ' + error.table + '; SET FOREIGN_KEY_CHECKS=1;');
            console.error('   2. Ou use DB_SYNC_MODE=force para recriar todas as tabelas');
            console.error('   3. Ou use DB_SYNC_MODE=none e gerencie com migrations');
            console.error('');
        } else {
            console.error('❌ Erro ao inicializar banco:', error);
        }
        return false;
    }
}

/**
 * Fecha todas as conexões com o banco
 */
async function closeDatabase() {
    try {
        await sequelize.close();
        await pool.end();
        console.log('🔐 Conexões de banco fechadas.');
    } catch (error) {
        console.error('❌ Erro ao fechar conexões:', error);
    }
}

module.exports = { 
    sequelize,
    pool,
    query,
    dbConfig,
    initDatabase, 
    closeDatabase
};