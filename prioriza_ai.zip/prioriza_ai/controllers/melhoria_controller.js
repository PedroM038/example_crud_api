/**
 * @file controllers/melhoria_controller.js
 * @description Controlador para gerenciar demandas do tipo Melhoria.
 * Endpoints granulares para edição de diferentes seções da demanda.
 * @author Pedro e Rafaela
 */

const DemandaService = require("../services/demandas_service");
const MelhoriaService = require("../services/melhoria_service");
const TipAreasService = require("../services/tip_areas_service");
const TipIndicadoresService = require("../services/tip_indicadores_service");
const TipInviabilidadesService = require("../services/tip_inviabilidades_service");
const ResponsaveisMelhoriaService = require("../services/responsaveis_service");
const TipStatusService = require("../services/tip_status_service");
const LogHistoricoService = require("../services/log_historico_service");
const TipExperienciasService = require("../services/tip_experiencias_service");
const TipGravidadesService = require("../services/tip_gravidades_service");
const TipHorasEconomizadasService = require("../services/tip_horas_economizadas_service");
const TipImpactosService = require("../services/tip_impactos_service");
const TipTendenciasService = require("../services/tip_tendencias_service");
const TipUrgenciasService = require("../services/tip_urgencias_service");
const TipTemposService = require("../services/tip_tempos_service");
const TipRepeticoesService = require("../services/tip_repeticoes_service");
const TipScoresService = require("../services/tip_scores_service");
const TipTagsService = require("../services/tip_tags_service");
const FasesEtapasService = require("../services/tip_andamento_service");
const Usuario = require("../models/usuario");

const MelhoriaController = {

    // ==================== CONSULTAS ====================

    /**
     * Busca dados completos de uma demanda Melhoria
     * GET /api/melhoria/:id
     */
    async buscar(req, res) {
        try {
            const { id } = req.params;

            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            const demanda = await MelhoriaService.buscarPorId(id);

            if (!demanda) {
                return res.status(404).json({
                    success: false,
                    message: "Demanda não encontrada"
                });
            }

            res.json({
                success: true,
                demanda
            });
        } catch (error) {
            console.error("Erro ao buscar demanda melhoria:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao buscar demanda"
            });
        }
    },

    /**
     * Busca demanda com opções de formulário (para edição)
     * GET /api/melhoria/:id/formulario
     */
    async buscarFormulario(req, res) {
        try {
            const { id } = req.params;

            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            // Buscar demanda e opções em paralelo
            const [demanda, opcoes] = await Promise.all([
                MelhoriaService.buscarPorId(id),
                MelhoriaController._buscarOpcoesFormulario()
            ]);

            if (!demanda) {
                return res.status(404).json({
                    success: false,
                    message: "Demanda não encontrada"
                });
            }

            res.json({
                success: true,
                demanda,
                ...opcoes
            });

        } catch (error) {
            console.error("Erro ao carregar formulário de edição Melhoria:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao carregar o formulário de edição"
            });
        }
    },

    /**
     * Listar todas as demandas Melhoria
     * GET /api/melhoria
     */
    async listar(req, res) {
        try {
            const filtros = {
                ano: req.query.ano,
                semestre: req.query.semestre,
                statusId: req.query.status_id,
                areaId: req.query.area_id,
                funciAtan: req.query.funci_atan,
                funciDesign: req.query.funci_design
            };

            const demandas = await MelhoriaService.buscarTodas(filtros);

            res.json({
                success: true,
                data: demandas
            });

        } catch (error) {
            console.error("Erro ao listar demandas Melhoria:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao carregar lista de demandas"
            });
        }
    },

    // ==================== EDIÇÃO GRANULAR ====================

    /**
     * Edita dados básicos (semestre, ano)
     * PUT /api/melhoria/:id/dados
     */
    async editarDados(req, res) {
        try {
            const { id } = req.params;
            const { semestre, ano } = req.body;

            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            // Verificar se demanda existe
            const demandaExiste = await DemandaService.buscarPorId(id);
            if (!demandaExiste) {
                return res.status(404).json({
                    success: false,
                    message: "Demanda não encontrada"
                });
            }

            if (!MelhoriaService.ehTipologiaValida(demandaExiste.tipologia)) {
                return res.status(400).json({
                    success: false,
                    message: "Demanda não é do tipo Melhoria"
                });
            }

            const atualizado = await MelhoriaService.editarDados(id, { semestre, ano });
            const userData = Usuario.buscaDadosUsuario(req.session);

            // Registrar histórico em background
            setImmediate(async () => {
                try {
                    const demandaCompleta = await MelhoriaService.buscarPorId(id);
                    await LogHistoricoService.registrar(id, 'Editar Dados', userData.chave, demandaCompleta);
                } catch (err) {
                    console.error("Erro ao registrar histórico (background):", err);
                }
            });

            res.json({
                success: true,
                message: atualizado ? "Dados atualizados com sucesso" : "Nenhum dado foi alterado"
            });

        } catch (error) {
            console.error("Erro ao editar dados da melhoria:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao editar dados"
            });
        }
    },

    /**
     * Edita detalhes específicos da Melhoria
     * PUT /api/melhoria/:id/detalhe
     */
    async editarDetalhe(req, res) {
        try {
            const { id } = req.params;

            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            // Verificar se demanda existe
            const demandaExiste = await DemandaService.buscarPorId(id);
            if (!demandaExiste) {
                return res.status(404).json({
                    success: false,
                    message: "Demanda não encontrada"
                });
            }

            if (!MelhoriaService.ehTipologiaValida(demandaExiste.tipologia)) {
                return res.status(400).json({
                    success: false,
                    message: "Demanda não é do tipo Melhoria"
                });
            }

            const atualizado = await MelhoriaService.editarDetalhe(id, req.body);
            const userData = Usuario.buscaDadosUsuario(req.session);

            // Registrar histórico em background
            setImmediate(async () => {
                try {
                    const demandaCompleta = await MelhoriaService.buscarPorId(id);
                    await LogHistoricoService.registrar(id, 'Editar Detalhe', userData.chave, demandaCompleta);
                } catch (err) {
                    console.error("Erro ao registrar histórico (background):", err);
                }
            });

            res.json({
                success: true,
                message: atualizado ? "Detalhe atualizado com sucesso" : "Nenhum dado foi alterado"
            });

        } catch (error) {
            console.error("Erro ao editar detalhe da melhoria:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao editar detalhe"
            });
        }
    },

    /**
     * Edita responsáveis (funcis e estagiários)
     * PUT /api/melhoria/:id/responsaveis
     */
    async editarResponsaveis(req, res) {
        try {
            const { id } = req.params;

            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            // Verificar se demanda existe
            const demandaExiste = await DemandaService.buscarPorId(id);
            if (!demandaExiste) {
                return res.status(404).json({
                    success: false,
                    message: "Demanda não encontrada"
                });
            }

            if (!MelhoriaService.ehTipologiaValida(demandaExiste.tipologia)) {
                return res.status(400).json({
                    success: false,
                    message: "Demanda não é do tipo Melhoria"
                });
            }

            const resultado = await MelhoriaService.editarResponsaveis(id, req.body);
            const userData = Usuario.buscaDadosUsuario(req.session);

            // Registrar histórico em background
            setImmediate(async () => {
                try {
                    const demandaCompleta = await MelhoriaService.buscarPorId(id);
                    await LogHistoricoService.registrar(id, 'Editar Responsáveis', userData.chave, demandaCompleta);
                } catch (err) {
                    console.error("Erro ao registrar histórico (background):", err);
                }
            });

            res.json({
                success: true,
                message: resultado ? "Responsáveis atualizados com sucesso" : "Nenhum dado foi alterado"
            });

        } catch (error) {
            console.error("Erro ao editar responsáveis da melhoria:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao editar responsáveis"
            });
        }
    },

    /**
     * Busca opções de responsáveis para formulário
     * GET /api/melhoria/responsaveis/opcoes
     */
    async buscarOpcoesResponsaveis(req, res) {
        try {
            const [funcionariosAtan, funcionariosDesign, estagiariosAtan, estagiariosDesign] = await Promise.all([
                ResponsaveisMelhoriaService.buscarFuncionariosAtan(),
                ResponsaveisMelhoriaService.buscarFuncionariosDesign(),
                ResponsaveisMelhoriaService.buscarEstagiariosAtan(),
                ResponsaveisMelhoriaService.buscarEstagiariosDesign()
            ]);

            res.json({
                success: true,
                funcionariosAtan,
                funcionariosDesign,
                estagiariosAtan,
                estagiariosDesign
            });
        } catch (error) {
            console.error("Erro ao buscar opções de responsáveis:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao buscar opções"
            });
        }
    },

    /**
     * Edita matriz Guthie (priorização)
     * PUT /api/melhoria/:id/guthie
     */
    async editarGuthie(req, res) {
        try {
            const { id } = req.params;

            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            // Verificar se demanda existe
            const demandaExiste = await DemandaService.buscarPorId(id);
            if (!demandaExiste) {
                return res.status(404).json({
                    success: false,
                    message: "Demanda não encontrada"
                });
            }

            if (!MelhoriaService.ehTipologiaValida(demandaExiste.tipologia)) {
                return res.status(400).json({
                    success: false,
                    message: "Demanda não é do tipo Melhoria"
                });
            }

            const resultado = await MelhoriaService.editarGuthie(id, req.body);
            const userData = Usuario.buscaDadosUsuario(req.session);

            // Registrar histórico em background
            setImmediate(async () => {
                try {
                    const demandaCompleta = await MelhoriaService.buscarPorId(id);
                    await LogHistoricoService.registrar(id, 'Editar Guthie', userData.chave, demandaCompleta);
                } catch (err) {
                    console.error("Erro ao registrar histórico (background):", err);
                }
            });

            res.json({
                success: true,
                message: resultado ? "Matriz Guthie atualizada com sucesso" : "Nenhum dado foi alterado"
            });

        } catch (error) {
            console.error("Erro ao editar Guthie da melhoria:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao editar Guthie"
            });
        }
    },

    /**
     * Busca opções de Guthie para formulário
     * GET /api/melhoria/guthie/opcoes
     */
    async buscarOpcoesGuthie(req, res) {
        try {
            const [gravidades, urgencias, tendencias, impactos, horasEconomizadas, experiencias, scores] = await Promise.all([
                TipGravidadesService.buscarTodas(),
                TipUrgenciasService.buscarTodas(),
                TipTendenciasService.buscarTodas(),
                TipImpactosService.buscarTodos(),
                TipHorasEconomizadasService.buscarTodas(),
                TipExperienciasService.buscarTodas(),
                TipScoresService.buscarTodos()
            ]);

            res.json({
                success: true,
                gravidades,
                urgencias,
                tendencias,
                impactos,
                horasEconomizadas,
                experiencias,
                scores
            });
        } catch (error) {
            console.error("Erro ao buscar opções de Guthie:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao buscar opções"
            });
        }
    },

    /**
     * Edita cálculo de Horas FTE
     * PUT /api/melhoria/:id/horas-fte
     */
    async editarHorasFte(req, res) {
        try {
            const { id } = req.params;

            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            // Verificar se demanda existe
            const demandaExiste = await DemandaService.buscarPorId(id);
            if (!demandaExiste) {
                return res.status(404).json({
                    success: false,
                    message: "Demanda não encontrada"
                });
            }

            if (!MelhoriaService.ehTipologiaValida(demandaExiste.tipologia)) {
                return res.status(400).json({
                    success: false,
                    message: "Demanda não é do tipo Melhoria"
                });
            }

            const resultado = await MelhoriaService.editarHorasFte(id, req.body);
            const userData = Usuario.buscaDadosUsuario(req.session);

            // Registrar histórico em background
            setImmediate(async () => {
                try {
                    const demandaCompleta = await MelhoriaService.buscarPorId(id);
                    await LogHistoricoService.registrar(id, 'Editar Horas FTE', userData.chave, demandaCompleta);
                } catch (err) {
                    console.error("Erro ao registrar histórico (background):", err);
                }
            });

            res.json({
                success: true,
                message: resultado ? "Horas FTE atualizadas com sucesso" : "Nenhum dado foi alterado"
            });

        } catch (error) {
            console.error("Erro ao editar Horas FTE da melhoria:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao editar Horas FTE"
            });
        }
    },

    /**
     * Busca opções de Horas FTE para formulário
     * GET /api/melhoria/horas-fte/opcoes
     */
    async buscarOpcoesHorasFte(req, res) {
        try {
            const [tempos, repeticoes] = await Promise.all([
                TipTemposService.buscarTodos(),
                TipRepeticoesService.buscarTodas()
            ]);

            res.json({
                success: true,
                tempos,
                repeticoes
            });
        } catch (error) {
            console.error("Erro ao buscar opções de Horas FTE:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao buscar opções"
            });
        }
    },

    // ==================== MÉTODOS AUXILIARES ====================

    /**
     * Busca todas as opções de formulário em paralelo
     * @private
     */
    async _buscarOpcoesFormulario() {
        const [
            areas, 
            indicadores, 
            inviabilidades, 
            status, 
            funcionariosAtan, 
            funcionariosDesign,
            estagiariosAtan,
            estagiariosDesign,
            experiencias,
            gravidades,
            horasEconomizadas,
            impactos,
            tendencias,
            urgencias,
            tempos,
            repeticoes,
            scores,
            tags,
            fasesEtapas
        ] = await Promise.all([
            TipAreasService.buscarAtivas(),
            TipIndicadoresService.buscarAtivos(),
            TipInviabilidadesService.buscarAtivas(),
            TipStatusService.buscaTodosStatusAtivos(),
            ResponsaveisMelhoriaService.buscarFuncionariosAtan(),
            ResponsaveisMelhoriaService.buscarFuncionariosDesign(),
            ResponsaveisMelhoriaService.buscarEstagiariosAtan(),
            ResponsaveisMelhoriaService.buscarEstagiariosDesign(),
            TipExperienciasService.buscarTodas(),
            TipGravidadesService.buscarTodas(),
            TipHorasEconomizadasService.buscarTodas(),
            TipImpactosService.buscarTodos(),
            TipTendenciasService.buscarTodas(),
            TipUrgenciasService.buscarTodas(),
            TipTemposService.buscarTodos(),
            TipRepeticoesService.buscarTodas(),
            TipScoresService.buscarTodos(),
            TipTagsService.buscarAtivas(),
            FasesEtapasService.buscarAgrupadas()
        ]);

        return {
            areas,
            indicadores,
            inviabilidades,
            status,
            funcionariosAtan,
            funcionariosDesign,
            estagiariosAtan,
            estagiariosDesign,
            experiencias,
            gravidades,
            horasEconomizadas,
            impactos,
            tendencias,
            urgencias,
            tempos,
            repeticoes,
            scores,
            tags,
            fasesEtapas
        };
    }
};

module.exports = MelhoriaController;