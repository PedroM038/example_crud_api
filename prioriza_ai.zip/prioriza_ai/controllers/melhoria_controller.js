/**
 * @file controllers/MelhoriaCtl.js
 * @description Controlador para gerenciar demandas do tipo Melhoria.
 * Este controlador lida com a edição e visualização de demandas de melhoria.
 * @author Pedro e Rafaela
 */

const demandaService = require("../services/demandas_service");
const melhoriaService = require("../services/melhoria_service");
const areaService = require("../services/tip_areas_service");
const indicadorService = require("../services/tip_indicadores_service");
const inviabilidadeService = require("../services/tip_inviabilidades_service");
const responsaveisService = require("../services/responsaveis_service");
const statusService = require("../services/tip_status_service");
const historicoService = require("../services/log_historico_service");
const experienciaService = require("../services/tip_experiencias_service");
const gravidade = require("../services/tip_gravidades_service");
const horasEconomizadasService = require("../services/tip_horas_economizadas_service");
const impactoService = require("../services/tip_impactos_service");
const tendenciaService = require("../services/tip_tendencias_service");
const urgenciaService = require("../services/tip_urgencias_service");
const temposService = require("../services/tip_tempos_service");
const repeticoesService = require("../services/tip_repeticoes_service");
const scoreService = require("../services/tip_scores_service");
const precificacaoService = require("../services/precificacao_service");
const tipTagsService = require("../services/tip_tags_service");
const fasesEtapasService = require("../services/tip_andamento_service");
const usuario = require("../models/usuario");

const MelhoriaCtl = {

    /**
     * Monta dados da demanda. Inicialmente foi feito para o modal de visualização
     * Porém, agora é usado para montar o pdf da demanda
     * 
     * @description Este método busca os dados de uma demanda específica do tipo Melhoria
     * e retorna um JSON com todas as informações necessárias. 
     * @param {Object} req 
     * @param {Object} res
     */
    async verDemanda(req, res) {
        try {
            const { id } = req.params;

            // Buscar dados da demanda usando o service
            const demanda = await melhoriaService.buscaDemandaPorId(id);

            if (!demanda) {
                return res.status(404).json({
                    success: false,
                    message: "Demanda não encontrada"
                });
            }

            // Retorna JSON com todos os dados necessários
            res.json({
                success: true,
                demanda: demanda
            });
        } catch (error) {
            console.error("Erro ao carregar dados da demanda melhoria:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao carregar dados da demanda melhoria"
            });
        }
    },

    /**
     * Exibir formulário de edição para Melhoria
     * @param {Object} req 
     * @param {Object} res 
     */
    async editarForm(req, res) {
        try {
            const { id } = req.params;

            // Buscar detalhes específicos de Melhoria
            const demanda = await melhoriaService.buscaDemandaPorId(id);

            if (!demanda) {
                return res.status(404).json({
                    success: false,
                    message: "Demanda não encontrada"
                });
            }

            // Buscar dados para os dropdowns
            const [
                todasAreas, 
                todosIndicadores, 
                todasInviabilidades, 
                todosStatus, 
                funcionariosAtan, 
                funcionariosDesign,
                estagiariosAtan,
                estagiariosDesign,
                todasExperiencias,
                todasGravidades,
                todasHorasEconomizadas,
                todosImpactos,
                todasTendencias,
                todasUrgencias,
                todosTempos,
                todasRepeticoes,
                todosScores,
                todasPrecificacoesDev,
                todasPrecificacoesDesign,
                todasTags,
                todasFasesEtapas
            ] = await Promise.all([
                areaService.buscaTodasAreasAtivas(),
                indicadorService.buscaTodosIndicadoresAtivos(),
                inviabilidadeService.buscaTodasInviabilidadesAtivas(),
                statusService.buscaTodosStatusAtivos(),
                responsaveisService.buscaFuncionariosAtan(),
                responsaveisService.buscaFuncionariosDesign(),
                responsaveisService.buscaEstagiariosAtan(),
                responsaveisService.buscaEstagiariosDesign(),
                experienciaService.buscaTodasExperiencias(),
                gravidade.buscaTodasGravidades(),
                horasEconomizadasService.buscaTodasHorasEconomizadas(),
                impactoService.buscaTodosImpactos(),
                tendenciaService.buscaTodasTendencias(),
                urgenciaService.buscaTodasUrgencias(),
                temposService.buscaTodosTempos(),
                repeticoesService.buscaTodasRepeticoes(),
                scoreService.buscaTodosScores(),
                precificacaoService.buscaTodasPrecificacoesDev(),
                precificacaoService.buscaTodasPrecificacoesDesign(),
                tipTagsService.buscaTodasTagsAtivas(),
                fasesEtapasService.buscaFasesEtapasAgrupadas()
            ]);

            // Retorna JSON com todos os dados necessários para o modal
            res.json({
                success: true,
                demanda: demanda,
                areas: todasAreas,
                indicadores: todosIndicadores,
                inviabilidades: todasInviabilidades,
                status: todosStatus,
                funcionariosAtan: funcionariosAtan,
                funcionariosDesign: funcionariosDesign,
                estagiariosAtan: estagiariosAtan,
                estagiariosDesign: estagiariosDesign,
                experiencias: todasExperiencias,
                gravidades: todasGravidades,
                horasEconomizadas: todasHorasEconomizadas,
                impactos: todosImpactos,
                tendencias: todasTendencias,
                urgencias: todasUrgencias,
                tempos: todosTempos,
                repeticoes: todasRepeticoes,
                score: todosScores,
                precificacoesDev: todasPrecificacoesDev,
                precificacoesDesign: todasPrecificacoesDesign,
                tags: todasTags,
                fasesEtapas: todasFasesEtapas
            });

        } catch (error) {
            console.error("Erro ao carregar formulário de edição Melhoria:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao carregar o formulário de edição"
            });
        }
    },

    /**
     * Processar edição de demanda Melhoria
     * @param {Object} req 
     * @param {Object} res 
     */
    async editarDemanda(req, res) {
        try {
            const { id } = req.params;
            
            // Pega dados do front-end
            const dados = req.body;

            // Verificar se a demanda existe e é do tipo Melhoria
            const demandaExistente = await demandaService.buscaDemandaPorId(id);

            if (!demandaExistente) {
                return res.status(404).json({
                    success: false,
                    message: "Demanda não encontrada"
                });
            }

            if (!melhoriaService.verificaTipoDemanda(demandaExistente.tipologia)) {
                return res.status(400).json({
                    success: false,
                    message: "Demanda não é do tipo Melhoria"
                });
            }

            const userData = usuario.buscaDadosUsuario(req.session);
            
            await melhoriaService.editaDemanda(id, dados, userData);

            // Buscar dados completos para o histórico (após transação concluída)
            const demandaCompleta = await melhoriaService.buscaDemandaPorId(id);

            // Registrar no histórico de forma assíncrona (não bloqueia a resposta)
            const acao = `Editar Melhoria`;
            setImmediate(async () => {
                try {
                    await historicoService.registraAcao(id, acao, userData.chave, demandaCompleta);
                } catch (err) {
                    console.error("Erro ao registrar histórico (background):", err);
                }
            });

            res.json({
                success: true,
                message: "Demanda editada com sucesso",
                data: demandaCompleta
            });

        } catch (error) {
            console.error("Erro ao editar demanda Melhoria:", error);
            res.status(500).json({
                success: false,
                message: "Erro interno do servidor ao editar demanda"
            });
        }
    },

    /**
     * Listar todas as demandas Melhoria
     * podemos fazer uma api para esse método
     * @param {Object} req 
     * @param {Object} res 
     */
    async listarDemandas(req, res) {
        try {
            const demandas = await melhoriaService.buscaTodasDemandas();

            res.json({
                success: true,
                data: demandas
            });

        } catch (error) {
            console.error("Erro ao listar demandas Melhoria:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao carregar lista de demandas"
            });
        }
    }
};

module.exports = MelhoriaCtl;