/**
 * @file controllers/ObservacoesCtl.js
 * @description Controlador para gerenciar as observações das demandas.
 * Inclui a exibição do formulário de observações, inserção de novas observações e registro no histórico.
 * @author Pedro e Rafaela
 */

const observacoesService = require("../services/observacoes_service");
const demandaService = require("../services/demandas_service");
const historicoService = require("../services/log_historico_service");
const usuario = require("../models/usuario");

const ObservacoesCtl = {
    
    /**
     * Exibir formulário de ver observações da demanda
     * @param {Object} req 
     * @param {Object} res 
     */
    async observacoesForm(req, res) {
        try {
            const { idDemanda } = req.params;

            // Validar ID da demanda
            if (!idDemanda || isNaN(idDemanda)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            // Verificar se a demanda existe
            const demandaExiste = await demandaService.buscaDemandaPorId(idDemanda);
            if (!demandaExiste) {
                return res.status(404).json({
                    success: false,
                    message: "Demanda não encontrada"
                });
            }

            // Buscar observações da demanda
            const listaObservacoes = await observacoesService.buscaObservacoesPorDemanda(idDemanda);
            
            // Retorna JSON com os dados necessários para o modal
            res.json({
                success: true,
                observacoes: listaObservacoes,
                message: "Formulário carregado com sucesso"
            });

        } catch (error) {
            console.error("Erro ao carregar formulário de observações:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao carregar o formulário de observações"
            });
        }
    },

    /**
     * Processar inserção de nova observação
     * @param {Object} req 
     * @param {Object} res 
     */
    async inserir(req, res) {
        try {
            const { idDemanda, observacao } = req.body;

            // Buscar dados do usuário da sessão
            const userData = usuario.buscaDadosUsuario(req.session);
            
            // Verificar se a demanda existe
            const demandaExiste = await demandaService.buscaDemandaPorId(idDemanda);
            if (!demandaExiste) {
                return res.status(404).json({
                    success: false,
                    message: "Demanda não encontrada"
                });
            }

            // Inserir observação
            const resultado = await observacoesService.inserirObservacao(
                idDemanda, 
                observacao, 
                userData.chave,
                userData.nomeGuerra || userData.nome || "Usuário sem nome"
            );

            // Registrar no histórico
            const acao = `Nova Observação`;
            const detalhesHistorico = {
                observacao_id: resultado.id,
                observacao_texto: resultado.observacao,
                usuario_matricula: resultado.matricula
            };
            
            await historicoService.registraAcao(
                idDemanda, 
                acao, 
                userData.chave, 
                detalhesHistorico
            );
            
            res.json({
                success: true,
                message: "Observação inserida com sucesso",
                data: resultado
            });

        } catch (error) {
            console.error("Erro ao inserir nova observação:", error);
            res.status(500).json({
                success: false,
                message: error.message || "Erro interno do servidor ao inserir observação"
            });
        }
    },
};

module.exports = ObservacoesCtl;