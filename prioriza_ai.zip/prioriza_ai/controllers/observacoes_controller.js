/**
 * @file controllers/ObservacoesCtl.js
 * @description Controlador para gerenciar as observações das demandas.
 * Inclui a exibição do formulário de observações, inserção de novas observações e registro no histórico.
 * @author Pedro e Rafaela
 */

const ObservacoesService = require("../services/observacoes_service");
const DemandaService = require("../services/demandas_service");
const LogHistoricoService = require("../services/log_historico_service");
const usuario = require("../models/usuario");

const ObservacoesCtl = {
    
    /**
     * Exibir formulário de ver observações da demanda
     * @param {Object} req 
     * @param {Object} res 
     */
    async observacoesForm(req, res) {
        try {
            const { idDemanda } = req.params;

            // Validar ID da demanda
            if (!idDemanda || isNaN(idDemanda)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            // Verificar se a demanda existe (lança exceção se não encontrar)
            await DemandaService.buscarPorId(idDemanda);

            // Buscar observações da demanda
            const listaObservacoes = await ObservacoesService.buscarPorDemanda(idDemanda);
            
            // Retorna JSON com os dados necessários para o modal
            res.json({
                success: true,
                observacoes: listaObservacoes,
                message: "Formulário carregado com sucesso"
            });

        } catch (error) {
            console.error("Erro ao carregar formulário de observações:", error);
            
            // Tratamento específico para demanda não encontrada
            if (error.message === 'Demanda não encontrada') {
                return res.status(404).json({
                    success: false,
                    message: error.message
                });
            }

            res.status(500).json({
                success: false,
                message: "Erro ao carregar o formulário de observações"
            });
        }
    },

    /**
     * Processar inserção de nova observação
     * @param {Object} req 
     * @param {Object} res 
     */
    async inserir(req, res) {
        try {
            const { idDemanda, observacao } = req.body;

            // Buscar dados do usuário da sessão
            const userData = usuario.buscaDadosUsuario(req.session);
            
            // Verificar se a demanda existe (lança exceção se não encontrar)
            await DemandaService.buscarPorId(idDemanda);

            // Inserir observação
            const resultado = await ObservacoesService.criar({
                idDemanda,
                observacao,
                matricula: userData.chave,
                nome: userData.nomeGuerra || userData.nome || "Usuário sem nome"
            });

            // Registrar no histórico
            await LogHistoricoService.registrar({
                idDemanda,
                acao: 'Nova Observação',
                usuario: userData.chave,
                detalhes: {
                    observacao_id: resultado.id_observacao,
                    observacao_texto: resultado.observacao,
                    usuario_matricula: resultado.matricula
                }
            });
            
            res.json({
                success: true,
                message: "Observação inserida com sucesso",
                data: resultado
            });

        } catch (error) {
            console.error("Erro ao inserir nova observação:", error);
            
            // Tratamento específico para demanda não encontrada
            if (error.message === 'Demanda não encontrada') {
                return res.status(404).json({
                    success: false,
                    message: error.message
                });
            }

            res.status(500).json({
                success: false,
                message: error.message || "Erro interno do servidor ao inserir observação"
            });
        }
    },
};

module.exports = ObservacoesCtl;