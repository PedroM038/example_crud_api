/**
 * @file controllers/andamento_controller.js
 * @description Controlador para gerenciar o andamento das demandas.
 * Este controlador lida com a visualização, adição, edição e remoção
 * de fases/etapas associadas às demandas.
 */

const andamentoService = require("../services/andamento_service");
const fasesEtapasService = require("../services/tip_andamento_service");
const usuario = require("../models/usuario");

const AndamentoCtl = {

    /**
     * Retorna os dados do andamento de uma demanda e as opções de fases/etapas
     * para montar o formulário de checkboxes no front-end
     * @param {Object} req 
     * @param {Object} res 
     */
    async andamentoForm(req, res) {
        try {
            const { idDemanda } = req.params;

            // Busca em paralelo: andamentos atuais e opções disponíveis
            const [andamentosDemanda, fasesEtapasAgrupadas] = await Promise.all([
                andamentoService.buscaAndamentosPorDemanda(idDemanda),
                fasesEtapasService.buscaFasesEtapasAgrupadas()
            ]);

            // Extrai os IDs das fases/etapas já marcadas
            const marcados = andamentosDemanda.map(a => a.fase_etapa);

            // Calcula o progresso atual
            const progresso = await andamentoService.calculaProgressoDemanda(idDemanda);

            res.json({
                success: true,
                idDemanda: parseInt(idDemanda),
                andamentos: andamentosDemanda,
                marcados: marcados,
                fasesEtapas: fasesEtapasAgrupadas,
                progresso: progresso
            });

        } catch (error) {
            console.error("Erro ao carregar formulário de andamento:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao carregar dados de andamento"
            });
        }
    },

    /**
     * Sincroniza os andamentos de uma demanda (adiciona/remove em massa)
     * Recebe um array com os IDs das fases/etapas que devem estar marcadas
     * @param {Object} req 
     * @param {Object} res 
     */
    async sincronizar(req, res) {
        try {
            const { idDemanda } = req.params;
            const { fasesEtapasMarcadas } = req.body;

            if (!Array.isArray(fasesEtapasMarcadas)) {
                return res.status(400).json({
                    success: false,
                    message: "fasesEtapasMarcadas deve ser um array"
                });
            }

            const userData = usuario.buscaDadosUsuario(req.session);
            const matricula = userData?.chave || 'sistema';

            const resultado = await andamentoService.sincronizaAndamentos(
                idDemanda,
                fasesEtapasMarcadas,
                matricula
            );

            // Calcula o novo progresso
            const progresso = await andamentoService.calculaProgressoDemanda(idDemanda);

            res.json({
                success: true,
                message: "Andamento atualizado com sucesso",
                resultado: resultado,
                progresso: progresso
            });

        } catch (error) {
            console.error("Erro ao sincronizar andamentos:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao atualizar andamento"
            });
        }
    },

    /**
     * Adiciona uma única fase/etapa ao andamento de uma demanda
     * @param {Object} req 
     * @param {Object} res 
     */
    async adicionar(req, res) {
        try {
            const { idDemanda } = req.params;
            const { fase_etapa } = req.body;

            if (!fase_etapa) {
                return res.status(400).json({
                    success: false,
                    message: "fase_etapa é obrigatório"
                });
            }

            // Verifica se já existe
            const existe = await andamentoService.verificaFaseEtapaExistente(idDemanda, fase_etapa);
            if (existe) {
                return res.status(400).json({
                    success: false,
                    message: "Esta fase/etapa já está marcada para esta demanda"
                });
            }

            const userData = usuario.buscaDadosUsuario(req.session);
            const matricula = userData?.chave || 'sistema';

            const novoAndamento = await andamentoService.adicionaAndamento(
                idDemanda,
                fase_etapa,
                matricula
            );

            const progresso = await andamentoService.calculaProgressoDemanda(idDemanda);

            res.json({
                success: true,
                message: "Fase/etapa adicionada com sucesso",
                andamento: novoAndamento,
                progresso: progresso
            });

        } catch (error) {
            console.error("Erro ao adicionar andamento:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao adicionar fase/etapa"
            });
        }
    },

    /**
     * Remove uma fase/etapa do andamento de uma demanda
     * @param {Object} req 
     * @param {Object} res 
     */
    async remover(req, res) {
        try {
            const { idDemanda, idAndamento } = req.params;

            const userData = usuario.buscaDadosUsuario(req.session);
            const matricula = userData?.chave || 'sistema';

            await andamentoService.removeAndamento(idAndamento, parseInt(idDemanda), matricula);

            const progresso = await andamentoService.calculaProgressoDemanda(idDemanda);

            res.json({
                success: true,
                message: "Fase/etapa removida com sucesso",
                progresso: progresso
            });

        } catch (error) {
            console.error("Erro ao remover andamento:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao remover fase/etapa"
            });
        }
    },

    /**
     * Retorna apenas o progresso de uma demanda
     * @param {Object} req 
     * @param {Object} res 
     */
    async progresso(req, res) {
        try {
            const { idDemanda } = req.params;

            const progresso = await andamentoService.calculaProgressoDemanda(idDemanda);

            res.json({
                success: true,
                idDemanda: parseInt(idDemanda),
                progresso: progresso
            });

        } catch (error) {
            console.error("Erro ao calcular progresso:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao calcular progresso"
            });
        }
    }
};

module.exports = AndamentoCtl;
