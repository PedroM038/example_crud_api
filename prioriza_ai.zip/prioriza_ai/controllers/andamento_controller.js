/**
 * @file controllers/andamento_controller.js
 * @description Controlador para gerenciar o andamento das demandas.
 * Este controlador lida com a visualização, adição, edição e remoção
 * de fases/etapas associadas às demandas.
 */

const AndamentoService = require("../services/andamento_service");
const TipFasesEtapasService = require("../services/tip_andamento_service");
const DemandaService = require("../services/demandas_service");
const usuario = require("../models/usuario");

const AndamentoCtl = {

    /**
     * Retorna os dados do andamento de uma demanda e as opções de fases/etapas
     * para montar o formulário de checkboxes no front-end
     * @param {Object} req 
     * @param {Object} res 
     */
    async andamentoForm(req, res) {
        try {
            const { idDemanda } = req.params;

            // Validar ID da demanda
            if (!idDemanda || isNaN(idDemanda)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            // Verificar se a demanda existe (lança exceção se não encontrar)
            await DemandaService.buscarPorId(idDemanda);

            // Busca em paralelo: andamentos atuais e opções disponíveis
            const [andamentosDemanda, fasesEtapasAgrupadas] = await Promise.all([
                AndamentoService.buscarPorDemanda(idDemanda),
                TipFasesEtapasService.buscarAgrupadas()
            ]);

            // Extrai os IDs das fases/etapas já marcadas
            const marcados = andamentosDemanda.map(a => a.fase_etapa);

            // Calcula o progresso atual
            const progresso = await AndamentoService.calcularProgresso(idDemanda);

            res.json({
                success: true,
                idDemanda: parseInt(idDemanda),
                andamentos: andamentosDemanda,
                marcados: marcados,
                fasesEtapas: fasesEtapasAgrupadas,
                progresso: progresso
            });

        } catch (error) {
            console.error("Erro ao carregar formulário de andamento:", error);

            if (error.message === 'Demanda não encontrada') {
                return res.status(404).json({
                    success: false,
                    message: error.message
                });
            }

            res.status(500).json({
                success: false,
                message: "Erro ao carregar dados de andamento"
            });
        }
    },

    /**
     * Sincroniza os andamentos de uma demanda (adiciona/remove em massa)
     * Recebe um array com os IDs das fases/etapas que devem estar marcadas
     * @param {Object} req 
     * @param {Object} res 
     */
    async sincronizar(req, res) {
        try {
            const { idDemanda } = req.params;
            const { fasesEtapasMarcadas } = req.body;

            // Validar ID da demanda
            if (!idDemanda || isNaN(idDemanda)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            if (!Array.isArray(fasesEtapasMarcadas)) {
                return res.status(400).json({
                    success: false,
                    message: "fasesEtapasMarcadas deve ser um array"
                });
            }

            // Verificar se a demanda existe
            await DemandaService.buscarPorId(idDemanda);

            const userData = usuario.buscaDadosUsuario(req.session);
            const matricula = userData?.chave || 'sistema';

            const resultado = await AndamentoService.sincronizar(
                idDemanda,
                fasesEtapasMarcadas,
                matricula
            );

            // Calcula o novo progresso
            const progresso = await AndamentoService.calcularProgresso(idDemanda);

            res.json({
                success: true,
                message: "Andamento atualizado com sucesso",
                resultado: resultado,
                progresso: progresso
            });

        } catch (error) {
            console.error("Erro ao sincronizar andamentos:", error);

            if (error.message === 'Demanda não encontrada') {
                return res.status(404).json({
                    success: false,
                    message: error.message
                });
            }

            res.status(500).json({
                success: false,
                message: "Erro ao atualizar andamento"
            });
        }
    },

    /**
     * Adiciona uma única fase/etapa ao andamento de uma demanda
     * @param {Object} req 
     * @param {Object} res 
     */
    async adicionar(req, res) {
        try {
            const { idDemanda } = req.params;
            const { fase_etapa } = req.body;

            // Validar ID da demanda
            if (!idDemanda || isNaN(idDemanda)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            if (!fase_etapa) {
                return res.status(400).json({
                    success: false,
                    message: "fase_etapa é obrigatório"
                });
            }

            // Verificar se a demanda existe
            await DemandaService.buscarPorId(idDemanda);

            // Verifica se já existe
            const existe = await AndamentoService.existeFaseEtapa(idDemanda, fase_etapa);
            if (existe) {
                return res.status(400).json({
                    success: false,
                    message: "Esta fase/etapa já está marcada para esta demanda"
                });
            }

            const userData = usuario.buscaDadosUsuario(req.session);
            const matricula = userData?.chave || 'sistema';

            const novoAndamento = await AndamentoService.adicionar({
                idDemanda: parseInt(idDemanda),
                faseEtapa: fase_etapa,
                matricula
            });

            const progresso = await AndamentoService.calcularProgresso(idDemanda);

            res.json({
                success: true,
                message: "Fase/etapa adicionada com sucesso",
                andamento: novoAndamento,
                progresso: progresso
            });

        } catch (error) {
            console.error("Erro ao adicionar andamento:", error);

            if (error.message === 'Demanda não encontrada') {
                return res.status(404).json({
                    success: false,
                    message: error.message
                });
            }

            res.status(500).json({
                success: false,
                message: "Erro ao adicionar fase/etapa"
            });
        }
    },

    /**
     * Remove uma fase/etapa do andamento de uma demanda
     * @param {Object} req 
     * @param {Object} res 
     */
    async remover(req, res) {
        try {
            const { idDemanda, idAndamento } = req.params;

            // Validar IDs
            if (!idDemanda || isNaN(idDemanda)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            if (!idAndamento || isNaN(idAndamento)) {
                return res.status(400).json({
                    success: false,
                    message: "ID do andamento inválido"
                });
            }

            // Verificar se a demanda existe
            await DemandaService.buscarPorId(idDemanda);

            const userData = usuario.buscaDadosUsuario(req.session);
            const matricula = userData?.chave || 'sistema';

            const removido = await AndamentoService.remover(idAndamento, matricula);

            if (!removido) {
                return res.status(404).json({
                    success: false,
                    message: "Andamento não encontrado"
                });
            }

            const progresso = await AndamentoService.calcularProgresso(idDemanda);

            res.json({
                success: true,
                message: "Fase/etapa removida com sucesso",
                progresso: progresso
            });

        } catch (error) {
            console.error("Erro ao remover andamento:", error);

            if (error.message === 'Demanda não encontrada') {
                return res.status(404).json({
                    success: false,
                    message: error.message
                });
            }

            res.status(500).json({
                success: false,
                message: "Erro ao remover fase/etapa"
            });
        }
    },

    /**
     * Retorna apenas o progresso de uma demanda
     * @param {Object} req 
     * @param {Object} res 
     */
    async progresso(req, res) {
        try {
            const { idDemanda } = req.params;

            // Validar ID da demanda
            if (!idDemanda || isNaN(idDemanda)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            // Verificar se a demanda existe
            await DemandaService.buscarPorId(idDemanda);

            const progresso = await AndamentoService.calcularProgresso(idDemanda);

            res.json({
                success: true,
                idDemanda: parseInt(idDemanda),
                progresso: progresso
            });

        } catch (error) {
            console.error("Erro ao calcular progresso:", error);

            if (error.message === 'Demanda não encontrada') {
                return res.status(404).json({
                    success: false,
                    message: error.message
                });
            }

            res.status(500).json({
                success: false,
                message: "Erro ao calcular progresso"
            });
        }
    }
};

module.exports = AndamentoCtl;
