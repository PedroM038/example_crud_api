/**
 * @file controllers/gestao_controller.js
 * @description Controlador para gerenciamento das tabelas auxiliares (tip_areas, tip_status, etc)
 * Apenas usuários com papel de gerente ou admin podem acessar estas funcionalidades
 * @author Pedro e Rafaela
 */

const TipAreasService = require('../services/tip_areas_service');
const TipAndamentoService = require('../services/tip_andamento_service');
const TipEstagiarioService = require('../services/tip_estagiario_service');
const TipIndicadoresService = require('../services/tip_indicadores_service');
const TipInviabilidadesService = require('../services/tip_inviabilidades_service');
const TipStatusService = require('../services/tip_status_service');
const TipTagsService = require('../services/tip_tags_service');
const TipMotivosService = require('../services/tip_motivos_services');
const Usuario = require("../models/usuario");
const versao = process.env.VERSAO;

class GestaoController {

    static async index(req, res) {
        try {
            const usuarioDados = Usuario.buscaDadosUsuario(req.session);

            // Buscar todos os dados em paralelo
            const [
                areas,
                andamentos,
                estagiarios,
                indicadores,
                inviabilidades,
                status,
                tags,
                motivos
            ] = await Promise.all([
                TipAreasService.buscarTodas(),
                TipAndamentoService.buscarTodas(),
                TipEstagiarioService.buscarTodos(),
                TipIndicadoresService.buscarTodos(),
                TipInviabilidadesService.buscarTodas(),
                TipStatusService.buscaTodosStatus(),
                TipTagsService.buscarTodas(),
                TipMotivosService.buscarTodos()
            ]);

            res.render('gestao', {
                titulo: 'Gestão de Dados Auxiliares',
                areas: areas,
                andamentos: andamentos,
                estagiarios: estagiarios,
                indicadores: indicadores,
                inviabilidades: inviabilidades,
                status: status,
                motivos: motivos,
                tags: tags,
                usuario: usuarioDados,
                versao: versao,
                mensagem: req.flash('sucesso'),
                erro: req.flash('erro')
            });
        } catch (error) {
            console.error('Erro ao carregar página de gestão:', error);
            return res.status(500).json({
                erro: 'Erro ao carregar página de gestão',
                detalhes: error.message
            });
        }
    }

    static async listarAreas(req, res) {
        try {
            const areas = await TipAreasService.buscarTodas();
            return res.json(areas);
        } catch (error) {
            console.error('Erro ao listar áreas:', error);
            return res.status(500).json({
                erro: 'Erro ao listar áreas',
                detalhes: error.message
            });
        }
    }

    static async criarArea(req, res) {
        try {
            const { area } = req.body;

            const novaArea = await TipAreasService.criar({ area });

            return res.status(201).json({
                mensagem: 'Área criada com sucesso',
                area: novaArea
            });
        } catch (error) {
            console.error('Erro ao criar área:', error);
            return res.status(500).json({
                erro: 'Erro ao criar área',
                detalhes: error.message
            });
        }
    }

    static async atualizarArea(req, res) {
        try {
            const { id } = req.params;
            const { area } = req.body;

            const areaAtualizada = await TipAreasService.atualizar(id, { area });

            return res.json({
                mensagem: 'Área atualizada com sucesso',
                area: areaAtualizada
            });
        } catch (error) {
            console.error('Erro ao atualizar área:', error);

            if (error.message.includes('não encontrada')) {
                return res.status(404).json({
                    erro: 'Área não encontrada'
                });
            }

            return res.status(500).json({
                erro: 'Erro ao atualizar área',
                detalhes: error.message
            });
        }
    }

    static async deletarArea(req, res) {
        try {
            const { id } = req.params;
            const resultado = await TipAreasService.deletar(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao deletar área:', error);
            if (error.message.includes('não encontrada')) {
                return res.status(404).json({ erro: 'Área não encontrada' });
            }
            return res.status(500).json({
                erro: 'Erro ao deletar área',
                detalhes: error.message
            });
        }
    }

    static async restaurarArea(req, res) {
        try {
            const { id } = req.params;
            const resultado = await TipAreasService.restaurar(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao restaurar área:', error);
            if (error.message.includes('não encontrada')) {
                return res.status(404).json({ erro: 'Área não encontrada ou não estava deletada' });
            }
            return res.status(500).json({
                erro: 'Erro ao restaurar área',
                detalhes: error.message
            });
        }
    }

    static async listarMotivos(req, res) {
        try {
            const motivos = await TipMotivosService.buscarTodos();
            return res.json(motivos);
        } catch (error) {
            console.error('Erro ao listar motivos:', error);
            return res.status(500).json({
                erro: 'Erro ao listar motivos',
                detalhes: error.message
            });
        }
    }

    static async criarMotivo(req, res) {
        try {
            const { motivo } = req.body;

            const novoMotivo = await TipMotivosService.criar({ motivo });

            return res.status(201).json({
                mensagem: 'Motivo criado com sucesso',
                motivo: novoMotivo
            });
        } catch (error) {
            console.error('Erro ao criar motivo:', error);
            return res.status(500).json({
                erro: 'Erro ao criar motivo',
                detalhes: error.message
            });
        }
    }

    static async atualizarMotivo(req, res) {
        try {
            const { id } = req.params;
            const { motivo } = req.body;

            const motivoAtualizado = await TipMotivosService.atualizar(id, { motivo });

            return res.json({
                mensagem: 'motivo atualizado com sucesso',
                motivo: motivoAtualizado
            });
        } catch (error) {
            console.error('Erro ao atualizar motivo:', error);

            if (error.message.includes('não encontrado')) {
                return res.status(404).json({
                    erro: 'Motivo não encontrado'
                });
            }

            return res.status(500).json({
                erro: 'Erro ao atualizar motivo',
                detalhes: error.message
            });
        }
    }

    static async deletarMotivo(req, res) {
        try {
            const { id } = req.params;
            const resultado = await TipMotivosService.deletar(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao deletar motivo:', error);
            if (error.message.includes('não encontrado')) {
                return res.status(404).json({ erro: 'motivo não encontrado' });
            }
            return res.status(500).json({
                erro: 'Erro ao deletar motivo',
                detalhes: error.message
            });
        }
    }

    static async restaurarMotivo(req, res) {
        try {
            const { id } = req.params;
            const resultado = await TipMotivosService.restaurar(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao restaurar motivo:', error);
            if (error.message.includes('não encontrada')) {
                return res.status(404).json({ erro: 'Motivo não encontrado ou não estava deletado' });
            }
            return res.status(500).json({
                erro: 'Erro ao restaurar motivo',
                detalhes: error.message
            });
        }
    }

    static async listarAndamentos(req, res) {
        try {
            const andamentos = await TipAndamentoService.buscarTodas();
            return res.json(andamentos);
        } catch (error) {
            console.error('Erro ao listar andamentos:', error);
            return res.status(500).json({
                erro: 'Erro ao listar andamentos',
                detalhes: error.message
            });
        }
    }

    static async criarAndamento(req, res) {
        try {
            const { etapa, fase, percentual } = req.body;
            const novoAndamento = await TipAndamentoService.criar({ etapa, fase, percentual });
            return res.status(201).json({
                mensagem: 'Fase/Etapa criada com sucesso',
                andamento: novoAndamento
            });
        } catch (error) {
            console.error('Erro ao criar andamento:', error);
            return res.status(500).json({
                erro: 'Erro ao criar andamento',
                detalhes: error.message
            });
        }
    }

    static async atualizarAndamento(req, res) {
        try {
            const { id } = req.params;
            const { etapa, fase, percentual } = req.body;
            const andamentoAtualizado = await TipAndamentoService.atualizar(id, { etapa, fase, percentual });
            return res.json({
                mensagem: 'Fase/Etapa atualizada com sucesso',
                andamento: andamentoAtualizado
            });
        } catch (error) {
            console.error('Erro ao atualizar andamento:', error);
            if (error.message.includes('não encontrada')) {
                return res.status(404).json({ erro: 'Fase/Etapa não encontrada' });
            }
            return res.status(500).json({
                erro: 'Erro ao atualizar andamento',
                detalhes: error.message
            });
        }
    }

    static async deletarAndamento(req, res) {
        try {
            const { id } = req.params;
            const resultado = await TipAndamentoService.deletar(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao deletar andamento:', error);
            if (error.message.includes('não encontrada')) {
                return res.status(404).json({ erro: 'Fase/Etapa não encontrada' });
            }
            return res.status(500).json({
                erro: 'Erro ao deletar andamento',
                detalhes: error.message
            });
        }
    }

    static async restaurarAndamento(req, res) {
        try {
            const { id } = req.params;
            const resultado = await TipAndamentoService.restaurar(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao restaurar andamento:', error);
            if (error.message.includes('não encontrada')) {
                return res.status(404).json({ erro: 'Fase/Etapa não encontrada ou não estava deletada' });
            }
            return res.status(500).json({
                erro: 'Erro ao restaurar andamento',
                detalhes: error.message
            });
        }
    }

    static async listarEstagiarios(req, res) {
        try {
            const estagiarios = await TipEstagiarioService.buscarTodos();
            return res.json(estagiarios);
        } catch (error) {
            console.error('Erro ao listar estagiários:', error);
            return res.status(500).json({
                erro: 'Erro ao listar estagiários',
                detalhes: error.message
            });
        }
    }

    static async criarEstagiario(req, res) {
        try {
            const { equipe, matricula, nome } = req.body;
            const novoEstagiario = await TipEstagiarioService.criar({ equipe, matricula, nome });
            return res.status(201).json({
                mensagem: 'Estagiário criado com sucesso',
                estagiario: novoEstagiario
            });
        } catch (error) {
            console.error('Erro ao criar estagiário:', error);
            return res.status(500).json({
                erro: 'Erro ao criar estagiário',
                detalhes: error.message
            });
        }
    }

    static async atualizarEstagiario(req, res) {
        try {
            const { id } = req.params;
            const { equipe, matricula, nome } = req.body;
            const estagiarioAtualizado = await TipEstagiarioService.atualizar(id, { equipe, matricula, nome });
            return res.json({
                mensagem: 'Estagiário atualizado com sucesso',
                estagiario: estagiarioAtualizado
            });
        } catch (error) {
            console.error('Erro ao atualizar estagiário:', error);
            if (error.message.includes('não encontrado')) {
                return res.status(404).json({ erro: 'Estagiário não encontrado' });
            }
            return res.status(500).json({
                erro: 'Erro ao atualizar estagiário',
                detalhes: error.message
            });
        }
    }

    static async deletarEstagiario(req, res) {
        try {
            const { id } = req.params;
            const resultado = await TipEstagiarioService.deletar(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao deletar estagiário:', error);
            if (error.message.includes('não encontrado')) {
                return res.status(404).json({ erro: 'Estagiário não encontrado' });
            }
            return res.status(500).json({
                erro: 'Erro ao deletar estagiário',
                detalhes: error.message
            });
        }
    }

    static async restaurarEstagiario(req, res) {
        try {
            const { id } = req.params;
            const resultado = await TipEstagiarioService.restaurar(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao restaurar estagiário:', error);
            if (error.message.includes('não encontrado')) {
                return res.status(404).json({ erro: 'Estagiário não encontrado ou não estava deletado' });
            }
            return res.status(500).json({
                erro: 'Erro ao restaurar estagiário',
                detalhes: error.message
            });
        }
    }

    static async listarIndicadores(req, res) {
        try {
            const indicadores = await TipIndicadoresService.buscarTodos();
            return res.json(indicadores);
        } catch (error) {
            console.error('Erro ao listar indicadores:', error);
            return res.status(500).json({
                erro: 'Erro ao listar indicadores',
                detalhes: error.message
            });
        }
    }

    static async criarIndicador(req, res) {
        try {
            const { indicador } = req.body;
            const novoIndicador = await TipIndicadoresService.criar({ indicador });
            return res.status(201).json({
                mensagem: 'Indicador criado com sucesso',
                indicador: novoIndicador
            });
        } catch (error) {
            console.error('Erro ao criar indicador:', error);
            return res.status(500).json({
                erro: 'Erro ao criar indicador',
                detalhes: error.message
            });
        }
    }

    static async atualizarIndicador(req, res) {
        try {
            const { id } = req.params;
            const { indicador } = req.body;
            const indicadorAtualizado = await TipIndicadoresService.atualizar(id, { indicador });
            return res.json({
                mensagem: 'Indicador atualizado com sucesso',
                indicador: indicadorAtualizado
            });
        } catch (error) {
            console.error('Erro ao atualizar indicador:', error);
            if (error.message.includes('não encontrado')) {
                return res.status(404).json({ erro: 'Indicador não encontrado' });
            }
            return res.status(500).json({
                erro: 'Erro ao atualizar indicador',
                detalhes: error.message
            });
        }
    }

    static async deletarIndicador(req, res) {
        try {
            const { id } = req.params;
            const resultado = await TipIndicadoresService.deletar(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao deletar indicador:', error);
            if (error.message.includes('não encontrado')) {
                return res.status(404).json({ erro: 'Indicador não encontrado' });
            }
            return res.status(500).json({
                erro: 'Erro ao deletar indicador',
                detalhes: error.message
            });
        }
    }

    static async restaurarIndicador(req, res) {
        try {
            const { id } = req.params;
            const resultado = await TipIndicadoresService.restaurar(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao restaurar indicador:', error);
            if (error.message.includes('não encontrado')) {
                return res.status(404).json({ erro: 'Indicador não encontrado ou não estava deletado' });
            }
            return res.status(500).json({
                erro: 'Erro ao restaurar indicador',
                detalhes: error.message
            });
        }
    }

    static async listarInviabilidades(req, res) {
        try {
            const inviabilidades = await TipInviabilidadesService.buscarTodas();
            return res.json(inviabilidades);
        } catch (error) {
            console.error('Erro ao listar inviabilidades:', error);
            return res.status(500).json({
                erro: 'Erro ao listar inviabilidades',
                detalhes: error.message
            });
        }
    }

    static async criarInviabilidade(req, res) {
        try {
            const { inviabilidade } = req.body;
            const novaInviabilidade = await TipInviabilidadesService.criar({ inviabilidade });
            return res.status(201).json({
                mensagem: 'Inviabilidade criada com sucesso',
                inviabilidade: novaInviabilidade
            });
        } catch (error) {
            console.error('Erro ao criar inviabilidade:', error);
            return res.status(500).json({
                erro: 'Erro ao criar inviabilidade',
                detalhes: error.message
            });
        }
    }

    static async atualizarInviabilidade(req, res) {
        try {
            const { id } = req.params;
            const { inviabilidade } = req.body;
            const inviabilidadeAtualizada = await TipInviabilidadesService.atualizar(id, { inviabilidade });
            return res.json({
                mensagem: 'Inviabilidade atualizada com sucesso',
                inviabilidade: inviabilidadeAtualizada
            });
        } catch (error) {
            console.error('Erro ao atualizar inviabilidade:', error);
            if (error.message.includes('não encontrada')) {
                return res.status(404).json({ erro: 'Inviabilidade não encontrada' });
            }
            return res.status(500).json({
                erro: 'Erro ao atualizar inviabilidade',
                detalhes: error.message
            });
        }
    }

    static async deletarInviabilidade(req, res) {
        try {
            const { id } = req.params;
            const resultado = await TipInviabilidadesService.deletar(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao deletar inviabilidade:', error);
            if (error.message.includes('não encontrada')) {
                return res.status(404).json({ erro: 'Inviabilidade não encontrada' });
            }
            return res.status(500).json({
                erro: 'Erro ao deletar inviabilidade',
                detalhes: error.message
            });
        }
    }

    static async restaurarInviabilidade(req, res) {
        try {
            const { id } = req.params;
            const resultado = await TipInviabilidadesService.restaurar(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao restaurar inviabilidade:', error);
            if (error.message.includes('não encontrada')) {
                return res.status(404).json({ erro: 'Inviabilidade não encontrada ou não estava deletada' });
            }
            return res.status(500).json({
                erro: 'Erro ao restaurar inviabilidade',
                detalhes: error.message
            });
        }
    }

    // ==================== STATUS ====================

    static async listarStatus(req, res) {
        try {
            const status = await TipStatusService.buscaTodosStatus();
            return res.json(status);
        } catch (error) {
            console.error('Erro ao listar status:', error);
            return res.status(500).json({
                erro: 'Erro ao listar status',
                detalhes: error.message
            });
        }
    }

    static async criarStatus(req, res) {
        try {
            const { status } = req.body;
            const novoStatus = await TipStatusService.criaStatus({ status });
            return res.status(201).json({
                mensagem: 'Status criado com sucesso',
                status: novoStatus
            });
        } catch (error) {
            console.error('Erro ao criar status:', error);
            return res.status(500).json({
                erro: 'Erro ao criar status',
                detalhes: error.message
            });
        }
    }

    static async atualizarStatus(req, res) {
        try {
            const { id } = req.params;
            const { status } = req.body;
            const statusAtualizado = await TipStatusService.atualizaStatus(id, { status });
            return res.json({
                mensagem: 'Status atualizado com sucesso',
                status: statusAtualizado
            });
        } catch (error) {
            console.error('Erro ao atualizar status:', error);
            if (error.message.includes('não encontrado')) {
                return res.status(404).json({ erro: 'Status não encontrado' });
            }
            return res.status(500).json({
                erro: 'Erro ao atualizar status',
                detalhes: error.message
            });
        }
    }

    static async deletarStatus(req, res) {
        try {
            const { id } = req.params;
            const resultado = await TipStatusService.deletaStatus(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao deletar status:', error);
            if (error.message.includes('não encontrado')) {
                return res.status(404).json({ erro: 'Status não encontrado' });
            }
            return res.status(500).json({
                erro: 'Erro ao deletar status',
                detalhes: error.message
            });
        }
    }

    static async restaurarStatus(req, res) {
        try {
            const { id } = req.params;
            const resultado = await TipStatusService.restauraStatus(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao restaurar status:', error);
            if (error.message.includes('não encontrado')) {
                return res.status(404).json({ erro: 'Status não encontrado ou não estava deletado' });
            }
            return res.status(500).json({
                erro: 'Erro ao restaurar status',
                detalhes: error.message
            });
        }
    }

    static async listarTags(req, res) {
        try {
            const tags = await TipTagsService.buscarTodas();
            return res.json(tags);
        } catch (error) {
            console.error('Erro ao listar tags:', error);
            return res.status(500).json({
                erro: 'Erro ao listar tags',
                detalhes: error.message
            });
        }
    }

    static async criarTag(req, res) {
        try {
            const { tag } = req.body;
            const novaTag = await TipTagsService.criar({ tag });
            return res.status(201).json({
                mensagem: 'Tag criada com sucesso',
                tag: novaTag
            });
        } catch (error) {
            console.error('Erro ao criar tag:', error);
            return res.status(500).json({
                erro: 'Erro ao criar tag',
                detalhes: error.message
            });
        }
    }

    static async atualizarTag(req, res) {
        try {
            const { id } = req.params;
            const { tag } = req.body;
            const tagAtualizada = await TipTagsService.atualizar(id, { tag });
            return res.json({
                mensagem: 'Tag atualizada com sucesso',
                tag: tagAtualizada
            });
        } catch (error) {
            console.error('Erro ao atualizar tag:', error);
            if (error.message.includes('não encontrada')) {
                return res.status(404).json({ erro: 'Tag não encontrada' });
            }
            return res.status(500).json({
                erro: 'Erro ao atualizar tag',
                detalhes: error.message
            });
        }
    }

    static async deletarTag(req, res) {
        try {
            const { id } = req.params;
            const resultado = await TipTagsService.deletar(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao deletar tag:', error);
            if (error.message.includes('não encontrada')) {
                return res.status(404).json({ erro: 'Tag não encontrada' });
            }
            return res.status(500).json({
                erro: 'Erro ao deletar tag',
                detalhes: error.message
            });
        }
    }

    static async restaurarTag(req, res) {
        try {
            const { id } = req.params;
            const resultado = await TipTagsService.restaurar(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao restaurar tag:', error);
            if (error.message.includes('não encontrada')) {
                return res.status(404).json({ erro: 'Tag não encontrada ou não estava deletada' });
            }
            return res.status(500).json({
                erro: 'Erro ao restaurar tag',
                detalhes: error.message
            });
        }
    }
}

module.exports = GestaoController;
