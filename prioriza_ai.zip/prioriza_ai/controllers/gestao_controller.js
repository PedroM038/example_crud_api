/**
 * @file controllers/gestao_controller.js
 * @description Controlador para gerenciamento das tabelas auxiliares (tip_areas, tip_status, etc)
 * Apenas usuários com papel de gerente ou admin podem acessar estas funcionalidades
 * @author Pedro e Rafaela
 */

const tip_areas_service = require('../services/tip_areas_service');
const tip_andamento_service = require('../services/tip_andamento_service');
const tip_estagiario_service = require('../services/tip_estagiario_service');
const tip_indicadores_service = require('../services/tip_indicadores_service');
const tip_inviabilidades_service = require('../services/tip_inviabilidades_service');
const tip_status_service = require('../services/tip_status_service');
const tip_tags_service = require('../services/tip_tags_service');
const tip_motivos_service = require('../services/tip_motivos_services');
const usuario = require("../models/usuario");
const versao = process.env.VERSAO;

class GestaoController {

    static async index(req, res) {
        try {
            const usuarioDados = await usuario.buscaDadosUsuario(req.session);

            const areas = await tip_areas_service.buscaTodasAreas();
            const andamentos = await tip_andamento_service.buscaTodasFasesEtapas();
            const estagiarios = await tip_estagiario_service.buscaTodosEstagiarios();
            const indicadores = await tip_indicadores_service.buscaTodosIndicadores();
            const inviabilidades = await tip_inviabilidades_service.buscaTodasInviabilidades();
            const status = await tip_status_service.buscaTodosStatus();
            const tags = await tip_tags_service.buscaTodasTags();
            const motivos = await tip_motivos_service.buscaTodosMotivos();

            res.render('gestao', {
                titulo: 'Gestão de Dados Auxiliares',
                areas: areas,
                andamentos: andamentos,
                estagiarios: estagiarios,
                indicadores: indicadores,
                inviabilidades: inviabilidades,
                status: status,
                motivos: motivos,
                tags: tags,
                usuario: usuarioDados,
                versao: versao,
                mensagem: req.flash('sucesso'),
                erro: req.flash('erro')
            });
        } catch (error) {
            console.error('Erro ao carregar página de gestão:', error);
            return res.status(500).json({
                erro: 'Erro ao carregar página de gestão',
                detalhes: error.message
            });
        }
    }

    static async listarAreas(req, res) {
        try {
            const areas = await tip_areas_service.buscaTodasAreas();
            return res.json(areas);
        } catch (error) {
            console.error('Erro ao listar áreas:', error);
            return res.status(500).json({
                erro: 'Erro ao listar áreas',
                detalhes: error.message
            });
        }
    }

    static async criarArea(req, res) {
        try {
            const { area } = req.body;

            const novaArea = await tip_areas_service.criaArea({ area });

            return res.status(201).json({
                mensagem: 'Área criada com sucesso',
                area: novaArea
            });
        } catch (error) {
            console.error('Erro ao criar área:', error);
            return res.status(500).json({
                erro: 'Erro ao criar área',
                detalhes: error.message
            });
        }
    }

    static async atualizarArea(req, res) {
        try {
            const { id } = req.params;
            const { area } = req.body;


            const areaAtualizada = await tip_areas_service.atualizaArea(id, { area });

            return res.json({
                mensagem: 'Área atualizada com sucesso',
                area: areaAtualizada
            });
        } catch (error) {
            console.error('Erro ao atualizar área:', error);

            if (error.message.includes('não encontrada')) {
                return res.status(404).json({
                    erro: 'Área não encontrada'
                });
            }

            return res.status(500).json({
                erro: 'Erro ao atualizar área',
                detalhes: error.message
            });
        }
    }

    static async deletarArea(req, res) {
        try {
            const { id } = req.params;
            const resultado = await tip_areas_service.deletaArea(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao deletar área:', error);
            if (error.message.includes('não encontrada')) {
                return res.status(404).json({ erro: 'Área não encontrada' });
            }
            return res.status(500).json({
                erro: 'Erro ao deletar área',
                detalhes: error.message
            });
        }
    }

    static async restaurarArea(req, res) {
        try {
            const { id } = req.params;
            const resultado = await tip_areas_service.restauraArea(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao restaurar área:', error);
            if (error.message.includes('não encontrada')) {
                return res.status(404).json({ erro: 'Área não encontrada ou não estava deletada' });
            }
            return res.status(500).json({
                erro: 'Erro ao restaurar área',
                detalhes: error.message
            });
        }
    }

    static async listarMotivos(req, res) {
        try {
            const motivos = await tip_motivos_service.buscaTodosMotivos();
            return res.json(motivos);
        } catch (error) {
            console.error('Erro ao listar motivos:', error);
            return res.status(500).json({
                erro: 'Erro ao listar motivos',
                detalhes: error.message
            });
        }
    }

    static async criarMotivo(req, res) {
        try {
            const { motivo } = req.body;

            const novoMotivo = await tip_motivos_service.criaMotivos({ motivo });

            return res.status(201).json({
                mensagem: 'Motivo criado com sucesso',
                motivo: novoMotivo
            });
        } catch (error) {
            console.error('Erro ao criar motivo:', error);
            return res.status(500).json({
                erro: 'Erro ao criar motivo',
                detalhes: error.message
            });
        }
    }

    static async atualizarMotivo(req, res) {
        try {
            const { id } = req.params;
            const { motivo } = req.body;


            const motivoAtualizado = await tip_motivos_service.atualizaMotivo(id, { motivo });

            return res.json({
                mensagem: 'motivo atualizado com sucesso',
                motivo: motivoAtualizado
            });
        } catch (error) {
            console.error('Erro ao atualizar motivo:', error);

            if (error.message.includes('não encontrado')) {
                return res.status(404).json({
                    erro: 'Motivo não encontrado'
                });
            }

            return res.status(500).json({
                erro: 'Erro ao atualizar motivo',
                detalhes: error.message
            });
        }
    }

    static async deletarMotivo(req, res) {
        try {
            const { id } = req.params;
            const resultado = await tip_motivos_service.deletaMotivo(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao deletar motivo:', error);
            if (error.message.includes('não encontrado')) {
                return res.status(404).json({ erro: 'motivo não encontrado' });
            }
            return res.status(500).json({
                erro: 'Erro ao deletar motivo',
                detalhes: error.message
            });
        }
    }

    static async restaurarMotivo(req, res) {
        try {
            const { id } = req.params;
            const resultado = await tip_motivos_service.restauraMotivo(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao restaurar motivo:', error);
            if (error.message.includes('não encontrada')) {
                return res.status(404).json({ erro: 'Motivo não encontrado ou não estava deletado' });
            }
            return res.status(500).json({
                erro: 'Erro ao restaurar motivo',
                detalhes: error.message
            });
        }
    }

    static async listarAndamentos(req, res) {
        try {
            const andamentos = await tip_andamento_service.buscaTodasFasesEtapas();
            return res.json(andamentos);
        } catch (error) {
            console.error('Erro ao listar andamentos:', error);
            return res.status(500).json({
                erro: 'Erro ao listar andamentos',
                detalhes: error.message
            });
        }
    }

    static async criarAndamento(req, res) {
        try {
            const { etapa, fase, percentual } = req.body;
            const novoAndamento = await tip_andamento_service.criaFaseEtapa({ etapa, fase, percentual });
            return res.status(201).json({
                mensagem: 'Fase/Etapa criada com sucesso',
                andamento: novoAndamento
            });
        } catch (error) {
            console.error('Erro ao criar andamento:', error);
            return res.status(500).json({
                erro: 'Erro ao criar andamento',
                detalhes: error.message
            });
        }
    }

    static async atualizarAndamento(req, res) {
        try {
            const { id } = req.params;
            const { etapa, fase, percentual } = req.body;
            const andamentoAtualizado = await tip_andamento_service.atualizaFaseEtapa(id, { etapa, fase, percentual });
            return res.json({
                mensagem: 'Fase/Etapa atualizada com sucesso',
                andamento: andamentoAtualizado
            });
        } catch (error) {
            console.error('Erro ao atualizar andamento:', error);
            if (error.message.includes('não encontrada')) {
                return res.status(404).json({ erro: 'Fase/Etapa não encontrada' });
            }
            return res.status(500).json({
                erro: 'Erro ao atualizar andamento',
                detalhes: error.message
            });
        }
    }

    static async deletarAndamento(req, res) {
        try {
            const { id } = req.params;
            const resultado = await tip_andamento_service.deletaFaseEtapa(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao deletar andamento:', error);
            if (error.message.includes('não encontrada')) {
                return res.status(404).json({ erro: 'Fase/Etapa não encontrada' });
            }
            return res.status(500).json({
                erro: 'Erro ao deletar andamento',
                detalhes: error.message
            });
        }
    }

    static async restaurarAndamento(req, res) {
        try {
            const { id } = req.params;
            const resultado = await tip_andamento_service.restauraFaseEtapa(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao restaurar andamento:', error);
            if (error.message.includes('não encontrada')) {
                return res.status(404).json({ erro: 'Fase/Etapa não encontrada ou não estava deletada' });
            }
            return res.status(500).json({
                erro: 'Erro ao restaurar andamento',
                detalhes: error.message
            });
        }
    }

    static async listarEstagiarios(req, res) {
        try {
            const estagiarios = await tip_estagiario_service.buscaTodosEstagiarios();
            return res.json(estagiarios);
        } catch (error) {
            console.error('Erro ao listar estagiários:', error);
            return res.status(500).json({
                erro: 'Erro ao listar estagiários',
                detalhes: error.message
            });
        }
    }

    static async criarEstagiario(req, res) {
        try {
            const { equipe, matricula, nome } = req.body;
            const novoEstagiario = await tip_estagiario_service.criaEstagiario({ equipe, matricula, nome });
            return res.status(201).json({
                mensagem: 'Estagiário criado com sucesso',
                estagiario: novoEstagiario
            });
        } catch (error) {
            console.error('Erro ao criar estagiário:', error);
            return res.status(500).json({
                erro: 'Erro ao criar estagiário',
                detalhes: error.message
            });
        }
    }

    static async atualizarEstagiario(req, res) {
        try {
            const { id } = req.params;
            const { equipe, matricula, nome } = req.body;
            const estagiarioAtualizado = await tip_estagiario_service.atualizaEstagiario(id, { equipe, matricula, nome });
            return res.json({
                mensagem: 'Estagiário atualizado com sucesso',
                estagiario: estagiarioAtualizado
            });
        } catch (error) {
            console.error('Erro ao atualizar estagiário:', error);
            if (error.message.includes('não encontrado')) {
                return res.status(404).json({ erro: 'Estagiário não encontrado' });
            }
            return res.status(500).json({
                erro: 'Erro ao atualizar estagiário',
                detalhes: error.message
            });
        }
    }

    static async deletarEstagiario(req, res) {
        try {
            const { id } = req.params;
            const resultado = await tip_estagiario_service.deletaEstagiario(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao deletar estagiário:', error);
            if (error.message.includes('não encontrado')) {
                return res.status(404).json({ erro: 'Estagiário não encontrado' });
            }
            return res.status(500).json({
                erro: 'Erro ao deletar estagiário',
                detalhes: error.message
            });
        }
    }

    static async restaurarEstagiario(req, res) {
        try {
            const { id } = req.params;
            const resultado = await tip_estagiario_service.restauraEstagiario(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao restaurar estagiário:', error);
            if (error.message.includes('não encontrado')) {
                return res.status(404).json({ erro: 'Estagiário não encontrado ou não estava deletado' });
            }
            return res.status(500).json({
                erro: 'Erro ao restaurar estagiário',
                detalhes: error.message
            });
        }
    }

    static async listarIndicadores(req, res) {
        try {
            const indicadores = await tip_indicadores_service.buscaTodosIndicadores();
            return res.json(indicadores);
        } catch (error) {
            console.error('Erro ao listar indicadores:', error);
            return res.status(500).json({
                erro: 'Erro ao listar indicadores',
                detalhes: error.message
            });
        }
    }

    static async criarIndicador(req, res) {
        try {
            const { indicador } = req.body;
            const novoIndicador = await tip_indicadores_service.criaIndicador({ indicador });
            return res.status(201).json({
                mensagem: 'Indicador criado com sucesso',
                indicador: novoIndicador
            });
        } catch (error) {
            console.error('Erro ao criar indicador:', error);
            return res.status(500).json({
                erro: 'Erro ao criar indicador',
                detalhes: error.message
            });
        }
    }

    static async atualizarIndicador(req, res) {
        try {
            const { id } = req.params;
            const { indicador } = req.body;
            const indicadorAtualizado = await tip_indicadores_service.atualizaIndicador(id, { indicador });
            return res.json({
                mensagem: 'Indicador atualizado com sucesso',
                indicador: indicadorAtualizado
            });
        } catch (error) {
            console.error('Erro ao atualizar indicador:', error);
            if (error.message.includes('não encontrado')) {
                return res.status(404).json({ erro: 'Indicador não encontrado' });
            }
            return res.status(500).json({
                erro: 'Erro ao atualizar indicador',
                detalhes: error.message
            });
        }
    }

    static async deletarIndicador(req, res) {
        try {
            const { id } = req.params;
            const resultado = await tip_indicadores_service.deletaIndicador(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao deletar indicador:', error);
            if (error.message.includes('não encontrado')) {
                return res.status(404).json({ erro: 'Indicador não encontrado' });
            }
            return res.status(500).json({
                erro: 'Erro ao deletar indicador',
                detalhes: error.message
            });
        }
    }

    static async restaurarIndicador(req, res) {
        try {
            const { id } = req.params;
            const resultado = await tip_indicadores_service.restauraIndicador(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao restaurar indicador:', error);
            if (error.message.includes('não encontrado')) {
                return res.status(404).json({ erro: 'Indicador não encontrado ou não estava deletado' });
            }
            return res.status(500).json({
                erro: 'Erro ao restaurar indicador',
                detalhes: error.message
            });
        }
    }

    static async listarInviabilidades(req, res) {
        try {
            const inviabilidades = await tip_inviabilidades_service.buscaTodasInviabilidades();
            return res.json(inviabilidades);
        } catch (error) {
            console.error('Erro ao listar inviabilidades:', error);
            return res.status(500).json({
                erro: 'Erro ao listar inviabilidades',
                detalhes: error.message
            });
        }
    }

    static async criarInviabilidade(req, res) {
        try {
            const { inviabilidade } = req.body;
            const novaInviabilidade = await tip_inviabilidades_service.criaInviabilidade({ inviabilidade });
            return res.status(201).json({
                mensagem: 'Inviabilidade criada com sucesso',
                inviabilidade: novaInviabilidade
            });
        } catch (error) {
            console.error('Erro ao criar inviabilidade:', error);
            return res.status(500).json({
                erro: 'Erro ao criar inviabilidade',
                detalhes: error.message
            });
        }
    }

    static async atualizarInviabilidade(req, res) {
        try {
            const { id } = req.params;
            const { inviabilidade } = req.body;
            const inviabilidadeAtualizada = await tip_inviabilidades_service.atualizaInviabilidade(id, { inviabilidade });
            return res.json({
                mensagem: 'Inviabilidade atualizada com sucesso',
                inviabilidade: inviabilidadeAtualizada
            });
        } catch (error) {
            console.error('Erro ao atualizar inviabilidade:', error);
            if (error.message.includes('não encontrada')) {
                return res.status(404).json({ erro: 'Inviabilidade não encontrada' });
            }
            return res.status(500).json({
                erro: 'Erro ao atualizar inviabilidade',
                detalhes: error.message
            });
        }
    }

    static async deletarInviabilidade(req, res) {
        try {
            const { id } = req.params;
            const resultado = await tip_inviabilidades_service.deletaInviabilidade(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao deletar inviabilidade:', error);
            if (error.message.includes('não encontrada')) {
                return res.status(404).json({ erro: 'Inviabilidade não encontrada' });
            }
            return res.status(500).json({
                erro: 'Erro ao deletar inviabilidade',
                detalhes: error.message
            });
        }
    }

    static async restaurarInviabilidade(req, res) {
        try {
            const { id } = req.params;
            const resultado = await tip_inviabilidades_service.restauraInviabilidade(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao restaurar inviabilidade:', error);
            if (error.message.includes('não encontrada')) {
                return res.status(404).json({ erro: 'Inviabilidade não encontrada ou não estava deletada' });
            }
            return res.status(500).json({
                erro: 'Erro ao restaurar inviabilidade',
                detalhes: error.message
            });
        }
    }

    // ==================== STATUS ====================

    static async listarStatus(req, res) {
        try {
            const status = await tip_status_service.buscaTodosStatus();
            return res.json(status);
        } catch (error) {
            console.error('Erro ao listar status:', error);
            return res.status(500).json({
                erro: 'Erro ao listar status',
                detalhes: error.message
            });
        }
    }

    static async criarStatus(req, res) {
        try {
            const { status } = req.body;
            const novoStatus = await tip_status_service.criaStatus({ status });
            return res.status(201).json({
                mensagem: 'Status criado com sucesso',
                status: novoStatus
            });
        } catch (error) {
            console.error('Erro ao criar status:', error);
            return res.status(500).json({
                erro: 'Erro ao criar status',
                detalhes: error.message
            });
        }
    }

    static async atualizarStatus(req, res) {
        try {
            const { id } = req.params;
            const { status } = req.body;
            const statusAtualizado = await tip_status_service.atualizaStatus(id, { status });
            return res.json({
                mensagem: 'Status atualizado com sucesso',
                status: statusAtualizado
            });
        } catch (error) {
            console.error('Erro ao atualizar status:', error);
            if (error.message.includes('não encontrado')) {
                return res.status(404).json({ erro: 'Status não encontrado' });
            }
            return res.status(500).json({
                erro: 'Erro ao atualizar status',
                detalhes: error.message
            });
        }
    }

    static async deletarStatus(req, res) {
        try {
            const { id } = req.params;
            const resultado = await tip_status_service.deletaStatus(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao deletar status:', error);
            if (error.message.includes('não encontrado')) {
                return res.status(404).json({ erro: 'Status não encontrado' });
            }
            return res.status(500).json({
                erro: 'Erro ao deletar status',
                detalhes: error.message
            });
        }
    }

    static async restaurarStatus(req, res) {
        try {
            const { id } = req.params;
            const resultado = await tip_status_service.restauraStatus(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao restaurar status:', error);
            if (error.message.includes('não encontrado')) {
                return res.status(404).json({ erro: 'Status não encontrado ou não estava deletado' });
            }
            return res.status(500).json({
                erro: 'Erro ao restaurar status',
                detalhes: error.message
            });
        }
    }

    static async listarTags(req, res) {
        try {
            const tags = await tip_tags_service.buscaTodasTags();
            return res.json(tags);
        } catch (error) {
            console.error('Erro ao listar tags:', error);
            return res.status(500).json({
                erro: 'Erro ao listar tags',
                detalhes: error.message
            });
        }
    }

    static async criarTag(req, res) {
        try {
            const { tag } = req.body;
            const novaTag = await tip_tags_service.criaTag({ tag });
            return res.status(201).json({
                mensagem: 'Tag criada com sucesso',
                tag: novaTag
            });
        } catch (error) {
            console.error('Erro ao criar tag:', error);
            return res.status(500).json({
                erro: 'Erro ao criar tag',
                detalhes: error.message
            });
        }
    }

    static async atualizarTag(req, res) {
        try {
            const { id } = req.params;
            const { tag } = req.body;
            const tagAtualizada = await tip_tags_service.atualizaTag(id, { tag });
            return res.json({
                mensagem: 'Tag atualizada com sucesso',
                tag: tagAtualizada
            });
        } catch (error) {
            console.error('Erro ao atualizar tag:', error);
            if (error.message.includes('não encontrada')) {
                return res.status(404).json({ erro: 'Tag não encontrada' });
            }
            return res.status(500).json({
                erro: 'Erro ao atualizar tag',
                detalhes: error.message
            });
        }
    }

    static async deletarTag(req, res) {
        try {
            const { id } = req.params;
            const resultado = await tip_tags_service.deletaTag(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao deletar tag:', error);
            if (error.message.includes('não encontrada')) {
                return res.status(404).json({ erro: 'Tag não encontrada' });
            }
            return res.status(500).json({
                erro: 'Erro ao deletar tag',
                detalhes: error.message
            });
        }
    }

    static async restaurarTag(req, res) {
        try {
            const { id } = req.params;
            const resultado = await tip_tags_service.restauraTag(id);
            return res.json(resultado);
        } catch (error) {
            console.error('Erro ao restaurar tag:', error);
            if (error.message.includes('não encontrada')) {
                return res.status(404).json({ erro: 'Tag não encontrada ou não estava deletada' });
            }
            return res.status(500).json({
                erro: 'Erro ao restaurar tag',
                detalhes: error.message
            });
        }
    }
}

module.exports = GestaoController;
