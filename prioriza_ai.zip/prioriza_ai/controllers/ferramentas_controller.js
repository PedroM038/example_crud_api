/**
 * @file controllers/ferramentas_controller.js
 * @description Controlador para gerenciar dados de ferramentas via API CESUP.
 * Fornece endpoints para buscar ferramentas disponíveis no sistema.
 * @author Pedro e Rafaela
 */

const FerramentasService = require("../services/ferramentas_service");

const FerramentasCtl = {

    /**
     * Lista todas as ferramentas disponíveis na API CESUP
     * @param {Object} req 
     * @param {Object} res 
     */
    async listarFerramentas(req, res) {
        try {
            const cookies = req.headers.cookie || '';
            const ferramentas = await FerramentasService.buscarTodas(cookies);

            res.json({
                success: true,
                data: ferramentas
            });
        } catch (error) {
            console.error("Erro ao listar ferramentas:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao carregar lista de ferramentas"
            });
        }
    },

    /**
     * Busca uma ferramenta específica por ID
     * @param {Object} req 
     * @param {Object} res 
     */
    async buscarFerramentaPorId(req, res) {
        try {
            const { id } = req.params;

            // Validar ID
            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da ferramenta inválido"
                });
            }

            const cookies = req.headers.cookie || '';
            const ferramenta = await FerramentasService.buscarPorId(id, cookies);

            if (!ferramenta) {
                return res.status(404).json({
                    success: false,
                    message: "Ferramenta não encontrada"
                });
            }

            res.json({
                success: true,
                data: ferramenta
            });
        } catch (error) {
            console.error("Erro ao buscar ferramenta:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao buscar ferramenta"
            });
        }
    },

    /**
     * Limpa o cache de ferramentas e força nova busca na API
     * Útil para atualizar dados após alterações na API CESUP
     * @param {Object} req 
     * @param {Object} res 
     */
    async limparCache(req, res) {
        try {
            FerramentasService.limparCache();
            
            res.json({
                success: true,
                message: "Cache de ferramentas limpo com sucesso"
            });
        } catch (error) {
            console.error("Erro ao limpar cache:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao limpar cache de ferramentas"
            });
        }
    }
};

module.exports = FerramentasCtl;
