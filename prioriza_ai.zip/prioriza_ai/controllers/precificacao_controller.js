/**
 * @file controllers/precificacao_controller.js
 * @description Controlador para gerenciar precificação de demandas.
 * Este controlador é reutilizável para qualquer tipologia (Bug, Defeito, Melhoria).
 * 
 * Endpoints:
 * - GET  /demanda/:id/precificacao → Busca precificação da demanda
 * - PUT  /demanda/:id/precificacao → Atualiza precificação da demanda
 * - GET  /precificacao/opcoes      → Lista opções de precificação (dev e design)
 * 
 * @author Pedro e Rafaela
 */

const DemandaService = require("../services/demandas_service");
const PrecificacaoService = require("../services/precificacao_service");
const TipPrecificacaoDevService = require("../services/tip_precificacao_dev_service");
const TipPrecificacaoDesignService = require("../services/tip_precificacao_design_service");
const LogHistoricoService = require("../services/log_historico_service");
const usuario = require("../models/usuario");

const PrecificacaoCtl = {

    /**
     * Busca a precificação de uma demanda
     * @param {Object} req 
     * @param {Object} res 
     */
    async buscar(req, res) {
        try {
            const { id } = req.params;

            // Validar ID
            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            // Verificar se a demanda existe
            await DemandaService.buscarPorId(id);

            // Buscar precificação
            const precificacao = await PrecificacaoService.buscarPorDemanda(id);

            res.json({
                success: true,
                data: precificacao || null
            });

        } catch (error) {
            console.error("Erro ao buscar precificação:", error);

            if (error.message === 'Demanda não encontrada') {
                return res.status(404).json({
                    success: false,
                    message: error.message
                });
            }

            res.status(500).json({
                success: false,
                message: "Erro ao buscar precificação"
            });
        }
    },

    /**
     * Atualiza a precificação de uma demanda
     * @param {Object} req 
     * @param {Object} res 
     */
    async atualizar(req, res) {
        try {
            const { id } = req.params;
            const { precificacao_dev_id, precificacao_design_id } = req.body;

            // Validar ID
            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            // Verificar se a demanda existe
            await DemandaService.buscarPorId(id);

            // Salvar precificação (upsert)
            const precificacao = await PrecificacaoService.salvar(id, {
                precificacao_dev_id,
                precificacao_design_id
            });

            // Registrar no histórico (não bloqueia resposta)
            const userData = usuario.buscaDadosUsuario(req.session);
            setImmediate(async () => {
                try {
                    await LogHistoricoService.registrar({
                        idDemanda: id,
                        acao: 'Atualizar Precificação',
                        usuario: userData.chave,
                        detalhes: { precificacao_dev_id, precificacao_design_id }
                    });
                } catch (err) {
                    console.error("Erro ao registrar histórico (background):", err);
                }
            });

            res.json({
                success: true,
                message: "Precificação atualizada com sucesso",
                data: precificacao
            });

        } catch (error) {
            console.error("Erro ao atualizar precificação:", error);

            if (error.message === 'Demanda não encontrada') {
                return res.status(404).json({
                    success: false,
                    message: error.message
                });
            }

            res.status(500).json({
                success: false,
                message: "Erro ao atualizar precificação"
            });
        }
    },

    /**
     * Remove a precificação de uma demanda
     * @param {Object} req 
     * @param {Object} res 
     */
    async remover(req, res) {
        try {
            const { id } = req.params;

            // Validar ID
            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            // Verificar se a demanda existe
            await DemandaService.buscarPorId(id);

            // Remover precificação
            const removido = await PrecificacaoService.removerPorDemanda(id);

            if (!removido) {
                return res.status(404).json({
                    success: false,
                    message: "Precificação não encontrada"
                });
            }

            // Registrar no histórico
            const userData = usuario.buscaDadosUsuario(req.session);
            setImmediate(async () => {
                try {
                    await LogHistoricoService.registrar({
                        idDemanda: id,
                        acao: 'Remover Precificação',
                        usuario: userData.chave,
                        detalhes: null
                    });
                } catch (err) {
                    console.error("Erro ao registrar histórico (background):", err);
                }
            });

            res.json({
                success: true,
                message: "Precificação removida com sucesso"
            });

        } catch (error) {
            console.error("Erro ao remover precificação:", error);

            if (error.message === 'Demanda não encontrada') {
                return res.status(404).json({
                    success: false,
                    message: error.message
                });
            }

            res.status(500).json({
                success: false,
                message: "Erro ao remover precificação"
            });
        }
    },

    /**
     * Lista as opções de precificação disponíveis (dev e design)
     * Útil para montar dropdowns no frontend
     * @param {Object} req 
     * @param {Object} res 
     */
    async listarOpcoes(req, res) {
        try {
            const [precificacoesDev, precificacoesDesign] = await Promise.all([
                TipPrecificacaoDevService.buscarTodas(),
                TipPrecificacaoDesignService.buscarTodas()
            ]);

            res.json({
                success: true,
                data: {
                    dev: precificacoesDev,
                    design: precificacoesDesign
                }
            });

        } catch (error) {
            console.error("Erro ao listar opções de precificação:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao listar opções de precificação"
            });
        }
    },

    /**
     * Busca precificação com opções disponíveis (para form de edição)
     * @param {Object} req 
     * @param {Object} res 
     */
    async buscarComOpcoes(req, res) {
        try {
            const { id } = req.params;

            // Validar ID
            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            // Verificar se a demanda existe
            await DemandaService.buscarPorId(id);

            // Buscar tudo em paralelo
            const [precificacao, precificacoesDev, precificacoesDesign] = await Promise.all([
                PrecificacaoService.buscarPorDemanda(id),
                TipPrecificacaoDevService.buscarTodas(),
                TipPrecificacaoDesignService.buscarTodas()
            ]);

            res.json({
                success: true,
                precificacao: precificacao || null,
                opcoes: {
                    dev: precificacoesDev,
                    design: precificacoesDesign
                }
            });

        } catch (error) {
            console.error("Erro ao buscar precificação:", error);

            if (error.message === 'Demanda não encontrada') {
                return res.status(404).json({
                    success: false,
                    message: error.message
                });
            }

            res.status(500).json({
                success: false,
                message: "Erro ao buscar precificação"
            });
        }
    }
};

module.exports = PrecificacaoCtl;
