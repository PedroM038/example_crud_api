/** 
 * @file controllers/bug_defeito_controller.js
 * @description Controlador para gerenciar demandas do tipo Bug/Defeito.
 * Este controlador lida com a edição e visualização de demandas de bug/defeito.
 * Fazemos Bug e Defeito juntos pois possuem os mesmos campos e funcionalidades.
 * 
 * Endpoints granulares:
 * - PUT /:id/dados     → Atualiza semestre, ano
 * - PUT /:id/detalhe   → Atualiza ferramenta, status, atribuição
 * - PUT /:id/motivos   → Sincroniza motivos (N:N)
 * - Precificação       → Ver precificacao_controller.js (reutilizável)
 * 
 * @author Pedro e Rafaela
 */

const BugDefeitoService = require("../services/bug_defeito_service");
const FerramentasService = require("../services/ferramentas_service");
const TipMotivosService = require("../services/tip_motivos_services");
const TipStatusService = require("../services/tip_status_service");
const TipPrecificacaoDevService = require("../services/tip_precificacao_dev_service");
const FuncionariosService = require("../services/funcionarios_service");
const TipEstagiariosService = require("../services/tip_estagiario_service");
const LogHistoricoService = require("../services/log_historico_service");
const usuario = require("../models/usuario");

const BugDefeitoCtl = {

    // ==================== VISUALIZAÇÃO ====================

    /**
     * Exibir dados da demanda Bug/Defeito para visualização.
     * Usado para montar dados para o pdf da demanda.
     * @param {Object} req 
     * @param {Object} res 
     */
    async verDemanda(req, res) {
        try {
            const { id } = req.params;

            // Validar ID
            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            const demanda = await BugDefeitoService.buscarPorId(id);

            if (!demanda) {
                return res.status(404).json({
                    success: false,
                    message: "Demanda não encontrada"
                });
            }

            res.json({
                success: true,
                demanda: demanda
            });

        } catch (error) {
            console.error("Erro ao carregar dados da demanda:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao carregar dados da demanda"
            });
        }
    },

    /**
     * Exibir formulário de edição para Bug/Defeito
     * @param {Object} req 
     * @param {Object} res 
     */
    async editarForm(req, res) {
        try {
            const { id } = req.params;
            const cookies = req.headers.cookie || '';

            // Validar ID
            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            // Buscar demanda e dados para dropdowns em paralelo
            const [
                demanda,
                ferramentas,
                status,
                motivos,
                funcionarios,
                estagiarios,
                precificacoesDev
            ] = await Promise.all([
                BugDefeitoService.buscarPorId(id),
                FerramentasService.buscarTodas(cookies),
                TipStatusService.buscaTodosStatusAtivos(),
                TipMotivosService.buscarAtivos(),
                FuncionariosService.buscarAtan(),
                TipEstagiariosService.buscarPorEquipe('Automação'),
                TipPrecificacaoDevService.buscarTodas()
            ]);

            if (!demanda) {
                return res.status(404).json({
                    success: false,
                    message: "Demanda não encontrada"
                });
            }

            res.json({
                success: true,
                demanda,
                ferramentas,
                status,
                motivos,
                funcionarios,
                estagiarios,
                precificacoesDev
            });

        } catch (error) {
            console.error("Erro ao carregar formulário de edição Bug/Defeito:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao carregar o formulário de edição"
            });
        }
    },

    // ==================== ENDPOINTS EDIÇÃO ====================
    /**
     * Atualiza dados básicos da demanda (semestre, ano)
     * @param {Object} req 
     * @param {Object} res 
     */
    async editarDados(req, res) {
        try {
            const { id } = req.params;
            const { semestre, ano } = req.body;

            // Validar ID
            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            // Verificar se a demanda existe
            const demanda = await BugDefeitoService.buscarPorId(id);
            if (!demanda) {
                return res.status(404).json({
                    success: false,
                    message: "Demanda não encontrada"
                });
            }

            // Atualiza dados básicos
            await BugDefeitoService.editarDados(id, { semestre, ano });

            // Registrar no histórico
            const userData = usuario.buscaDadosUsuario(req.session);
            setImmediate(async () => {
                try {
                    await LogHistoricoService.registrar({
                        idDemanda: id,
                        acao: 'Editar Dados Bug/Defeito',
                        usuario: userData.chave,
                        detalhes: { semestre, ano }
                    });
                } catch (err) {
                    console.error("Erro ao registrar histórico (background):", err);
                }
            });

            res.json({
                success: true,
                message: "Dados atualizados com sucesso"
            });

        } catch (error) {
            console.error("Erro ao editar dados Bug/Defeito:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao atualizar dados"
            });
        }
    },

    /**
     * Atualiza apenas os detalhes específicos de Bug/Defeito
     * (ferramenta, status, atribuição de responsáveis)
     * @param {Object} req 
     * @param {Object} res 
     */
    async editarDetalhe(req, res) {
        try {
            const { id } = req.params;
            const { ferramenta, ferramenta_nome, status, funci_atan, estagiario_atan, estagiario_atan_aux } = req.body;

            // Validar ID
            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            // Verificar se a demanda existe
            const demanda = await BugDefeitoService.buscarPorId(id);
            if (!demanda) {
                return res.status(404).json({
                    success: false,
                    message: "Demanda não encontrada"
                });
            }

            // Atualiza detalhes
            await BugDefeitoService.editarDetalhe(id, {
                ferramenta,
                ferramenta_nome,
                status,
                funci_atan,
                estagiario_atan,
                estagiario_atan_aux
            });

            // Registrar no histórico
            const userData = usuario.buscaDadosUsuario(req.session);
            setImmediate(async () => {
                try {
                    await LogHistoricoService.registrar({
                        idDemanda: id,
                        acao: 'Editar Detalhe Bug/Defeito',
                        usuario: userData.chave,
                        detalhes: { ferramenta, status, funci_atan, estagiario_atan }
                    });
                } catch (err) {
                    console.error("Erro ao registrar histórico (background):", err);
                }
            });

            res.json({
                success: true,
                message: "Detalhes atualizados com sucesso"
            });

        } catch (error) {
            console.error("Erro ao editar detalhe Bug/Defeito:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao atualizar detalhes"
            });
        }
    },

    /**
     * Busca os motivos de uma demanda Bug/Defeito
     * @param {Object} req 
     * @param {Object} res 
     */
    async buscarMotivos(req, res) {
        try {
            const { id } = req.params;

            // Validar ID
            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            const demanda = await BugDefeitoService.buscarPorId(id);
            if (!demanda) {
                return res.status(404).json({
                    success: false,
                    message: "Demanda não encontrada"
                });
            }

            // Busca opções disponíveis também
            const motivosDisponiveis = await TipMotivosService.buscarAtivos();

            res.json({
                success: true,
                motivos: demanda.motivos || [],
                motivosIds: demanda.motivos_ids || [],
                motivosDisponiveis
            });

        } catch (error) {
            console.error("Erro ao buscar motivos:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao buscar motivos"
            });
        }
    },

    /**
     * Sincroniza os motivos de uma demanda Bug/Defeito
     * @param {Object} req 
     * @param {Object} res 
     */
    async sincronizarMotivos(req, res) {
        try {
            const { id } = req.params;
            const { motivos_ids } = req.body;

            // Validar ID
            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            if (!Array.isArray(motivos_ids)) {
                return res.status(400).json({
                    success: false,
                    message: "motivos_ids deve ser um array"
                });
            }

            // Verificar se a demanda existe
            const demanda = await BugDefeitoService.buscarPorId(id);
            if (!demanda) {
                return res.status(404).json({
                    success: false,
                    message: "Demanda não encontrada"
                });
            }

            // Sincroniza motivos
            const resultado = await BugDefeitoService.sincronizarMotivos(id, motivos_ids);

            res.json({
                success: true,
                message: "Motivos atualizados com sucesso",
                resultado
            });

        } catch (error) {
            console.error("Erro ao sincronizar motivos:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao atualizar motivos"
            });
        }
    },

    // ==================== LISTAGEM ====================

    /**
     * Listar todas as demandas Bug/Defeito
     * @param {Object} req 
     * @param {Object} res 
     */
    async listarDemandas(req, res) {
        try {
            const { ano, semestre, status_id } = req.query;

            const filtros = {};
            if (ano) filtros.ano = parseInt(ano);
            if (semestre) filtros.semestre = parseInt(semestre);
            if (status_id) filtros.statusId = parseInt(status_id);

            const demandas = await BugDefeitoService.buscarTodas(filtros);

            res.json({
                success: true,
                data: demandas
            });

        } catch (error) {
            console.error("Erro ao listar demandas Bug/Defeito:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao carregar lista de demandas"
            });
        }
    }
};

module.exports = BugDefeitoCtl;