/** 
 * @file controllers/BugDefeitoCtl.js
 * @description Controlador para gerenciar demandas do tipo Bug/Defeito.
 * Este controlador lida com a edição e visualização de demandas de bug/defeito.
 * Fazemos Bug e Defeito juntos pois possuem os mesmos campos e funcionalidades.
 * Caso algum dia seja necessário, podemos separar em dois controladores.
 * @author Pedro e Rafaela
 */

const demandaService = require("../services/demandas_service");
const bugDefeitoService = require("../services/bug_defeito_service");
const ferramentaService = require("../services/ferramentas_service");
const tip_motivos_service = require("../services/tip_motivos_services");
const precificacao_service = require("../services/precificacao_service");
const statusService = require("../services/tip_status_service");
const responsaveisService = require("../services/responsaveis_service");
const historicoService = require("../services/log_historico_service");
const usuario = require("../models/usuario");
const BugDefeitoService = require("../services/bug_defeito_service");

const BugDefeitoCtl = {

    /**
     * Exibir dados da demanda Bug/Defeito para visualização. Usado para montar dados
     * para o pdf da demanda.
     * @param {Object} req 
     * @param {Object} res 
     */
    async verDemanda(req, res) {
        try {
            const { id } = req.params;
            const cookies = req.headers.cookie || '';

            // Buscar dados da demanda (passa cookies para buscar nome da ferramenta via API)
            const demanda = await bugDefeitoService.buscaDemandaPorId(id, cookies);

            if (!demanda) {
                return res.status(404).json({
                    success: false,
                    message: "Demanda não encontrada"
                });
            }

            // Retorna JSON com todos os dados necessários
            res.json({
                success: true,
                demanda: demanda
            });

        } catch (error) {
            console.error("Erro ao carregar dados da demanda:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao carregar dados da demanda"
            });
        }
    },

    /**
     * Exibir formulário de edição para Bug/Defeito
     * @param {Object} req 
     * @param {Object} res 
     */
    async editarForm(req, res) {
        try {
            const { id } = req.params;
            const cookies = req.headers.cookie || '';

            // Buscar detalhes específicos de Bug/Defeito (passa cookies para buscar nome da ferramenta via API)
            const demanda = await bugDefeitoService.buscaDemandaPorId(id, cookies);

            // Buscar dados para os dropdowns (ferramentas agora vem da API CESUP)
            const [todasFerramentas, todosStatus, todosMotivos, funcionariosAtan, todosEstagiarios, todasPrecificacoesDev] = await Promise.all([
                ferramentaService.buscaTodasFerramentas(cookies),
                statusService.buscaTodosStatusAtivos(),
                tip_motivos_service.buscaTodosMotivosAtivos(),
                responsaveisService.buscaFuncionariosAtan(),
                responsaveisService.buscaEstagiariosAtan(),
                precificacao_service.buscaTodasPrecificacoesDev()
            ]);

            // Retorna JSON com todos os dados necessários para o modal
            res.json({
                success: true,
                demanda: demanda,
                ferramentas: todasFerramentas,
                status: todosStatus,
                motivos: todosMotivos,
                funcionarios: funcionariosAtan,
                estagiarios: todosEstagiarios,
                precificacoesDev: todasPrecificacoesDev
            });
        } catch (error) {
            console.error("Erro ao carregar formulário de edição Bug/Defeito:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao carregar o formulário de edição"
            });
        }
    },

    /**
     * Processar edição de demanda Bug/Defeito
     * @param {Object} req 
     * @param {Object} res 
     */
    async editarDemanda(req, res) {
        try {
            const { id } = req.params;
            const dados = req.body;
            const cookies = req.headers.cookie || '';

            // Verificar se a demanda existe e é Bug/Defeito
            const demandaExistente = await demandaService.buscaDemandaPorId(id);

            if (!demandaExistente) {
                return res.status(404).json({
                    success: false,
                    message: "Demanda não encontrada"
                });
            }

            // Editar demanda usando o novo service
            await bugDefeitoService.editaDemanda(id, dados);

            // Buscar dados completos para o histórico (após transação concluída)
            const demandaCompleta = await BugDefeitoService.buscaDemandaPorId(id, cookies);

            // Registrar no histórico de forma assíncrona (não bloqueia a resposta)
            const userData = usuario.buscaDadosUsuario(req.session);
            const acao = `Editar Bug/Defeito`;
            setImmediate(async () => {
                try {
                    await historicoService.registraAcao(id, acao, userData.chave, demandaCompleta);
                } catch (err) {
                    console.error("Erro ao registrar histórico (background):", err);
                }
            });

            res.json({
                success: true,
                message: "Demanda editada com sucesso",
                data: demandaCompleta
            });

        } catch (error) {
            console.error("Erro ao editar demanda Bug/Defeito:", error);
            res.status(500).json({
                success: false,
                message: "Erro interno do servidor ao editar demanda"
            });
        }
    },

    /**
     * Listar todas as demandas Bug/Defeito
     * podemos fazer uma api para esse método
     * @param {Object} req 
     * @param {Object} res 
     */
    async listarDemandas(req, res) {
        try {
            const demandas = await bugDefeitoService.buscaTodasDemandas();

            res.json({
                success: true,
                data: demandas
            });

        } catch (error) {
            console.error("Erro ao listar demandas Bug/Defeito:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao carregar lista de demandas"
            });
        }
    }
};

module.exports = BugDefeitoCtl;