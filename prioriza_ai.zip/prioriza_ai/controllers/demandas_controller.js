/**
 * @file controllers/DemandasCtl.js
 * @description Controlador para gerenciar a página inicial.
 * Inclui a exibição da página inicial, exclusão de demandas e registro no histórico.
 * @author Pedro e Rafaela
 */

const usuario = require("../models/usuario");
const demandas = require("../services/demandas_service");
const historico = require("../services/log_historico_service");
const versao = process.env.VERSAO;

const DemandasController = {

    // Página inicial
    async index(req, res) {
        try {
            const usuarioDados = await usuario.buscaDadosUsuario(req.session);
            console.log(usuarioDados); 
            /**
             * Dados das demandas necessários para a view:
             * - tipologia
             * - numero do GD
             * - ano + semestre
             * - nome da demanda
             * - score de Guthie
             * - prioridade Guthie
             * - prioridade do Comite
             * - status
             */
            const todasDemandas = await demandas.buscaDemandasAtivas();

            // Manda os dados para a view
            res.render("index", {
                usuario: usuarioDados,
                demandaCompleta: todasDemandas,
                versao: versao
            });

        } catch (error) {
            console.error("Erro ao carregar página inicial:", error);
            res.status(500).render("error", {
                message: "Erro ao carregar a página inicial",
                status: 500,
            });
        }
    },

    // Soft delete de uma demanda
    async excluirDemanda(req, res) {
        const { id } = req.params;

        try {
            const idDemanda = await demandas.softDeleteDemanda(id);
            const acao = "Excluir";
            const dadosUsuario = await usuario.buscaDadosUsuario(req.session);
            const matricula = dadosUsuario.chave || "Usuário desconhecido";
            const detalhes = { id_demanda: id };

            await historico.registraAcao(idDemanda, acao, matricula, detalhes);

            res.status(200).json({
                success: true,
                message: "Demanda excluída com sucesso"
            });

        } catch (error) {
            console.error("Erro ao excluir demanda:", error);
            res.status(500).json({
                success: false,
                message: error.message || "Erro ao excluir a demanda"
            });
        }
    },

    // Prepara o form de criação de demanda
    async criarDemandaForm(req, res) {
        try {
            // Retorna JSON com os dados necessários para o modal
            res.json({
                success: true,
                tipologias: [
                    'Bug',
                    'Defeito',
                    'Melhoria',
                    'Tutoria',
                    'Acesso',
                    'Mineração de Dados e ETL',
                ]
            });
        } catch (error) {
            console.error("Erro ao carregar formulário de nova demanda:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao carregar o formulário"
            });
        }
    },

    // Busca demandas priorizadas (tipologia Melhoria com priorizacao_comite = 'Sim')
    async buscarPriorizadas(req, res) {
        try {
            const demandasPriorizadas = await demandas.buscaDemandasPriorizadas();

            res.status(200).json({
                success: true,
                data: demandasPriorizadas
            });
        } catch (error) {
            console.error("Erro ao buscar demandas priorizadas:", error);
            res.status(500).json({
                success: false,
                message: error.message || "Erro ao buscar demandas priorizadas"
            });
        }
    },

    // Busca todas as demandas ativas (para reset do filtro)
    async buscarTodas(req, res) {
        try {
            const todasDemandas = await demandas.buscaDemandasAtivas();

            res.status(200).json({
                success: true,
                data: todasDemandas
            });
        } catch (error) {
            console.error("Erro ao buscar todas as demandas:", error);
            res.status(500).json({
                success: false,
                message: error.message || "Erro ao buscar demandas"
            });
        }
    },

    // Cria nova demanda
    async criarDemanda(req, res) {
        try {
            const novaDemanda = await demandas.criaDemanda(req.body);

            const idNovaDemanda = novaDemanda.id_demanda;
            const acao = "Criar";
            const dadosUsuario = usuario.buscaDadosUsuario(req.session);
            const matricula = dadosUsuario.chave || "Usuário desconhecido";

            await historico.registraAcao(idNovaDemanda, acao, matricula, novaDemanda);

            res.status(201).json({
                success: true,
                message: "Demanda criada com sucesso",
                data: novaDemanda
            });

        } catch (error) {
            console.error("Erro ao criar nova demanda:", error);
            res.status(500).json({
                success: false,
                message: error.message || "Erro ao criar a demanda"
            });
        }
    }
};


module.exports = DemandasController;