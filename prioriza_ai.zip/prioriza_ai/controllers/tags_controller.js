/**
 * @file controllers/tags_controller.js
 * @description Controlador para gerenciar tags de demandas.
 * Reutilizável para Bug/Defeito e Melhoria.
 * @author Pedro e Rafaela
 */

const DemandaService = require("../services/demandas_service");
const TagsService = require("../services/tags_service");
const TipTagsService = require("../services/tip_tags_service");
const LogHistoricoService = require("../services/log_historico_service");
const Usuario = require("../models/usuario");

const TagsController = {

    /**
     * Busca tags de uma demanda
     * GET /api/demandas/:id/tags
     */
    async buscar(req, res) {
        try {
            const { id } = req.params;

            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            // Verificar se demanda existe
            const demandaExiste = await DemandaService.buscarPorId(id);
            if (!demandaExiste) {
                return res.status(404).json({
                    success: false,
                    message: "Demanda não encontrada"
                });
            }

            const tags = await TagsService.buscarPorDemanda(id);

            res.json({
                success: true,
                tags
            });

        } catch (error) {
            console.error("Erro ao buscar tags:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao buscar tags"
            });
        }
    },

    /**
     * Sincroniza tags de uma demanda (adiciona/remove conforme necessário)
     * PUT /api/demandas/:id/tags
     * Body: { tags: [1, 2, 3] } - array de IDs das tags
     */
    async sincronizar(req, res) {
        try {
            const { id } = req.params;
            const { tags } = req.body;

            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            if (!Array.isArray(tags)) {
                return res.status(400).json({
                    success: false,
                    message: "Tags deve ser um array"
                });
            }

            // Verificar se demanda existe
            const demandaExiste = await DemandaService.buscarPorId(id);
            if (!demandaExiste) {
                return res.status(404).json({
                    success: false,
                    message: "Demanda não encontrada"
                });
            }

            const userData = Usuario.buscaDadosUsuario(req.session);

            // Sincronizar tags
            const resultado = await TagsService.sincronizar(id, tags, userData?.chave);

            // Registrar histórico em background
            setImmediate(async () => {
                try {
                    await LogHistoricoService.registrar(
                        id,
                        'Sincronizar Tags',
                        userData.chave,
                        { tags: resultado }
                    );
                } catch (err) {
                    console.error("Erro ao registrar histórico (background):", err);
                }
            });

            res.json({
                success: true,
                message: "Tags sincronizadas com sucesso",
                resultado
            });

        } catch (error) {
            console.error("Erro ao sincronizar tags:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao sincronizar tags"
            });
        }
    },

    /**
     * Busca todas as opções de tags disponíveis
     * GET /api/tags/opcoes
     */
    async buscarOpcoes(req, res) {
        try {
            const tags = await TipTagsService.buscarAtivas();

            res.json({
                success: true,
                tags
            });
        } catch (error) {
            console.error("Erro ao buscar opções de tags:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao buscar opções de tags"
            });
        }
    },

    /**
     * Busca tags de uma demanda com as opções disponíveis
     * GET /api/demandas/:id/tags/completo
     */
    async buscarComOpcoes(req, res) {
        try {
            const { id } = req.params;

            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: "ID da demanda inválido"
                });
            }

            // Verificar se demanda existe
            const demandaExiste = await DemandaService.buscarPorId(id);
            if (!demandaExiste) {
                return res.status(404).json({
                    success: false,
                    message: "Demanda não encontrada"
                });
            }

            // Buscar tags atuais e opções em paralelo
            const [tagsAtuais, opcoes] = await Promise.all([
                TagsService.buscarPorDemanda(id),
                TipTagsService.buscarAtivas()
            ]);

            res.json({
                success: true,
                tagsAtuais,
                opcoes
            });

        } catch (error) {
            console.error("Erro ao buscar tags com opções:", error);
            res.status(500).json({
                success: false,
                message: "Erro ao buscar tags"
            });
        }
    }
};

module.exports = TagsController;
