/**
 * @file server.js
 * @description Ponto de entrada da aplicação - inicializa servidor HTTP/HTTPS
 * @author Pedro
 */

require("dotenv").config({ override: true });

const fs = require("fs");
const https = require("https");

const app = require("./app");
const { closeDatabase } = require("./database");
const { sessionStore } = require("./middlewares");

const PORT = process.env.PORT || 2025;

let server;

const sslKeyPath = "./ssl/server.key";
const sslCertPath = "./ssl/server.cer";

if (!fs.existsSync(sslKeyPath) || !fs.existsSync(sslCertPath)) {
    console.error('❌ Arquivos SSL não encontrados');
    process.exit(1);
}

const credentials = {
    key: fs.readFileSync(sslKeyPath, "utf8"),
    cert: fs.readFileSync(sslCertPath, "utf8")
};

server = https.createServer(credentials, app);

server.listen(PORT, () => {
    console.log(`🚀 HTTPS Server running on port ${PORT}`);
    console.log(`🌐 Access: https://localhost.bb.com.br:${PORT}`);
});

server.keepAliveTimeout = 5000;
server.headersTimeout = 6000;

server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
        console.error(`❌ Porta ${PORT} já está em uso`);
    } else {
        console.error('❌ Erro no servidor:', err);
    }
    process.exit(1);
});

// Graceful shutdown
async function gracefulShutdown(signal) {
    console.log(`${signal} recebido, fechando servidor...`);

    server.close(async () => {
        await closeDatabase();
        sessionStore?.close?.(() => {
            console.log('Servidor encerrado');
            process.exit(0);
        });
    });
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));