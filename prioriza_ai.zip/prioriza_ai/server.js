/**
 * ================================================================================
    NÃO IMPORTA QUANTOS NÚCLEOS TEM O SEU PROCESSADOR, ELE NUNCA VAI CONSEGUIR
    PROCESSAR A SAUDADE DE UM MOMENTO QUE JÁ DEU TIMEOUT
* ================================================================================
*/

/* 
    @file server.js
    @description O arquivo server.js é o ponto de entrada da aplicação Node.js junto com o app.js.
    Ele configura o servidor Express, gerencia sessões, autenticação e rotas.
    @author Pedro
*/

require("dotenv").config();

const express = require("express");
const path = require("path");
const cookieParser = require("cookie-parser");
const logger = require("morgan");
const flash = require("express-flash");
const routes = require("./routes");

// Importar middlewares customizados
const {
    sessionConfig,
    sessionStore,
    corsConfig,
    securityHeaders,
    captureClientIp,
    autenticaUsuario,
    notFoundHandler,
    errorHandler
} = require("./middlewares");

// importar configuração de banco de dados e inicialização
const { initDatabase, closeDatabase } = require("./database");

const app = express();

// Inicializar banco de dados
initDatabase().then(success => {
    if (success) {
        console.log('🚀 Banco de dados inicializado com sucesso');
    } else {
        console.error('❌ Falha ao inicializar banco de dados');
        process.exit(1);
    }
}).catch(error => {
    console.error('❌ Erro crítico na inicialização:', error);
    process.exit(1);
});

// Configuração de sessão
app.use(sessionConfig);

// Middleware globais
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: false, limit: '10mb' }));
app.use(cookieParser());

// Middleware de logging apenas em desenvolvimento
if (process.env.NODE_ENV !== 'production') {
    app.use(logger("dev"));
}

app.use(flash());

// CORS
app.use(corsConfig);

// Headers de segurança
app.use(securityHeaders);

// Capturar IP do cliente
app.use(captureClientIp);

// Middleware de autenticação
app.use(autenticaUsuario);

// Configuração de views e arquivos estáticos
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");
app.use(express.static(path.join(__dirname, "public"), {
    maxAge: process.env.NODE_ENV === 'production' ? '1d' : 0,
    etag: false
}));

// Rotas centralizadas
app.use("/", routes);

// Tratamento de erros
app.use(notFoundHandler);
app.use(errorHandler);

// Graceful shutdown (encerramento suave)
process.on('SIGTERM', async () => {
    console.log('SIGTERM recebido, fechando servidor...');
    await closeDatabase();
    sessionStore.close(() => {
        console.log('Session store fechado');
        process.exit(0);
    });
});

process.on('SIGINT', async () => {
    console.log('SIGINT recebido, fechando servidor...');
    await closeDatabase();
    sessionStore.close(() => {
        console.log('Session store fechado');
        process.exit(0);
    });
});

module.exports = app;